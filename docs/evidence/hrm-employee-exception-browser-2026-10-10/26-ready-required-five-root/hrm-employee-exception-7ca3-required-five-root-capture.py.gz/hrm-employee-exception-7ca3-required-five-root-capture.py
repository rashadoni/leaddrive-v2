from pathlib import Path
import subprocess,json,gzip,hashlib,re,datetime
head='7ca34739e490fb3ef7d88346e4e83c08cf50b665';tree='6bd9a531f365faf639b847c4d5db13303ac6b951';base='0a6300e7ae19d9435332ab8b4f1c6c9e1d420cac';checked='e3a6c527533072044efa1a289748be0eac51a1d3'
p=Path('/tmp/hrm-employee-exception-7ca3-required-five-root');p.mkdir(exist_ok=True);h=lambda b:hashlib.sha256(b).hexdigest()
params=[('pr-scope',38032037251,114154818821),('static-checks',38032037251,114154901545),('typecheck',38032037251,114154901604),('runner-policy',0,114150722296),('scan',0,114150722140)]
results=[]
for name,run,job in params:
 j=json.loads(subprocess.check_output(['gh','api',f'repos/rashadoni/leaddrive-v2/actions/jobs/{job}']));c=json.loads(subprocess.check_output(['gh','api',f'repos/rashadoni/leaddrive-v2/check-runs/{job}']))
 if run == 0: run = j['run_id']
 assert j['head_sha']==c['head_sha']==head and j['name']==c['name']==name and j['run_id']==run and c['app']['id']==15368
 if j['status']!='completed':results.append({'name':name,'jobId':job,'status':'PENDING_NO_CREDIT'});continue
 assert j['conclusion']==c['conclusion']=='success'
 for n,d in [('job-original',j),('check-original',c)]:
  f=p/f'{name}-{n}.json'
  if not f.exists():f.write_text(json.dumps(d,indent=2)+'\n')
 f=p/f'{name}-whole-log-original.txt.gz'
 if not f.exists():f.write_bytes(gzip.compress(subprocess.check_output(['gh','api',f'repos/rashadoni/leaddrive-v2/actions/jobs/{job}/logs']),mtime=0))
 raw=gzip.decompress(f.read_bytes());lines=raw.decode().splitlines();checkout=[]
 for i,l in enumerate(lines):
  if 'git log -1 --format=%H' in l:checkout.extend(lines[i:i+2])
 shas=re.findall('[a-f0-9]{40}','\n'.join(checkout));assert shas and shas[-1] in [head,checked]
 if shas[-1]!=head:
  cf=p/f'{name}-checked-commit-original.json'
  if not cf.exists():cf.write_bytes(subprocess.check_output(['gh','api',f'repos/rashadoni/leaddrive-v2/git/commits/{shas[-1]}']))
  cd=json.loads(cf.read_bytes());assert cd['tree']['sha']==tree and [x['sha'] for x in cd['parents']]==[base,head]
 assert all(s['conclusion']=='success' for s in j['steps']),[(s['name'],s['conclusion']) for s in j['steps'] if s['conclusion']!='success']
 results.append({'name':name,'jobId':job,'runId':run,'status':'ACTUAL_SUCCESS_FULL_ORIGINAL_RETAINED','bytes':len(raw),'sha256':h(raw),'actualCheckout':shas[-1],'allStepsSuccess':True})
(p/'root-required-five-original-content-review.json').write_text(json.dumps({'head':head,'base':base,'candidate':checked,'tree':tree,'actualRequiredFive':results,'status':'ACTUAL_REQUIRED_FIVE_SUCCESS_SEPARATE_APP15368_ALL_ORIGINAL_LOGS'},indent=2)+'\n')
print(json.dumps(results))
