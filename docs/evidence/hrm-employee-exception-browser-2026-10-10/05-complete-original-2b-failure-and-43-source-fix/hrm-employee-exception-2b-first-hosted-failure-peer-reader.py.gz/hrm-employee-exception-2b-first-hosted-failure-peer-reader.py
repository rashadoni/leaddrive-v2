import subprocess,json,pathlib,hashlib,re,zipfile,datetime
w=pathlib.Path('/mnt/HC_Volume_106454338/codex-alt-data/worktrees/leaddrive-hrm-employee-exception-browser-20261010');p=pathlib.Path('/tmp/hrm-employee-exception-2b-original-employee-failure-peer');head='2b05509eb16ec59b58bdc64d29b515f0ce929615'
def digest(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def fb(q):return {'path':str(q),**digest(q.read_bytes())}
def blob(path):return subprocess.check_output(['git','show',head+':'+path],cwd=w)
job=json.loads((p/'job-api.json').read_text());assert job['run_id']==38024424861 and job['status']=='completed' and job['conclusion']=='failure'
log=(p/'job-original.log').read_bytes();text=re.sub(r'\x1b\[[0-9;]*m','',log.decode())
assert head in text and 'test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"' in text
assert re.search(r'(?m)^\S+ '+head+r'\s*$',text), 'Standalone checkout actual SHA line required'
assert 'workforce-employee-exception-browser-admission.test.ts (30 tests)' in text and re.search(r'Test Files\s+6 passed\s+\(6\)',text) and re.search(r'Tests\s+68 passed\s+\(68\)',text)
assert 'Digest: sha256:7b822b0aac60967beb1ea5e576b8602c94c300a157d187f385ae3e0da199b90a' in text
artifact=next(x for x in json.loads((p/'artifacts-api.json').read_text())['artifacts'] if x['id']==11660052646)
raw=(p/'artifact-original.zip').read_bytes();assert digest(raw)['bytes']==artifact['size_in_bytes'] and artifact['digest']=='sha256:'+digest(raw)['sha256']
with zipfile.ZipFile(p/'artifact-original.zip') as z:
 assert z.testzip() is None
 entries=[{'path':x.filename,'bytes':x.file_size,'crc32':format(x.CRC,'08x'),**{'sha256':hashlib.sha256(z.read(x.filename)).hexdigest()}} for x in z.infolist()]
 receipt=json.loads(z.read('employee-exception-receipt.json'));ctx=json.loads(z.read('workflow-context.json'));failure=json.loads(z.read('workflow-failure.json'))
 assert ctx['headSha']==ctx['ciSha']==head and failure['headSha']==failure['ciSha']==head
assert receipt['status']=='FAIL' and receipt['cleanup']=='PASS' and receipt['sourceHead']==receipt['checkedMergeSha']==head
assert receipt['failure']['name']=='PrismaClientValidationError' and receipt['failure']['sourcePosition']=={'line':240,'column':9}
assert receipt['cases']==[] and receipt['authenticationDiagnostics']==[] and receipt['keyboardFocusDiagnostics']==[] and receipt['nativeZoomDiagnostics']==[] and receipt['nativeCaptureDiagnostics']==[]
assert all(x['status']=='PASS' for x in receipt['cleanupDiagnostics'])
assert len(receipt['sources'])==31
for x in receipt['sources']:assert digest(blob(x['path']))=={'bytes':x['bytes'],'sha256':x['sha256']},x['path']
static=json.loads(pathlib.Path('/tmp/hrm-employee-exception-b082-peer-static-bindings.json').read_text())
assert len(receipt['productionRoutines'])==12
for actual,expected in zip(receipt['productionRoutines'],static['productionRoutineStatements']):
 assert actual['path']==expected['path'] and actual['bytes']==expected['bytes'] and actual['sha256']==expected['sha256']
install=receipt['productionRoutineInstallation'];assert install['status']=='COMMITTED' and install['exactStatements']==11 and install['cycleIndex']=='APPLIED_OUTSIDE_TRANSACTION_VALID_UNIQUE_NULLS_DISTINCT'
for actual,expected in zip(install['constraints'],static['productionCheckFragments']):
 assert actual['name']==expected['name'] and actual['fragmentSha256']==expected['fragment']['sha256'] and actual['executedSha256']==expected['executed']['sha256']
assert len(install['constraints'])==3
source=blob('scripts/workforce-employee-exception-browser-evidence.mjs').decode().splitlines();schema=blob('prisma/schema.prisma').decode()
assert 'await admin.workforceExceptionDecision.create' in source[239] and 'caseRevision' not in source[239]
model=re.search(r'model WorkforceExceptionDecision \{([^}]+)\}',schema).group(1);assert re.search(r'caseRevision\s+Int\s*\n',model)
report={'observedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_FIRST_EMPLOYEE_JOB_FAILURE_PRESERVED_NO_BROWSER_ACCEPTANCE','source':head,'tree':subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=w).decode().strip(),'run':38024424861,'attempt':1,'job':114132109352,'jobUrl':job['html_url'],'runUrl':'https://github.com/rashadoni/leaddrive-v2/actions/runs/38024424861','prUrl':'https://github.com/rashadoni/leaddrive-v2/pull/678','actualJobConclusion':'failure','fullOriginalLog':fb(p/'job-original.log'),'compressedOriginalLog':fb(p/'job-original.log.gz'),'jobAPI':fb(p/'job-api.json'),'artifactAPI':fb(p/'artifacts-api.json'),'artifact':{'id':artifact['id'],'name':artifact['name'],'size':artifact['size_in_bytes'],'digest':artifact['digest'],'originalZIP':fb(p/'artifact-original.zip'),'wholeDigestMatched':True,'crc32AllEntriesMatched':True,'entries':entries},'actualCheckoutFullSHAProved':head,'actualUnitResults':{'newAdmissionTestsPassed':30,'targetedTestFilesPassed':6,'targetedTestsPassed':68,'sharedNativeGuard36':'PENDING separate regression job, not credited here'},'jobSteps':[{'name':s['name'],'conclusion':s['conclusion']} for s in job['steps']],'actualFailure':receipt['failure'],'actualPartialReceiptCounts':{'cases':0,'authenticatedPrincipals':0,'focusChecks':0,'nativeZoomProofs':0,'nativeCaptureDiagnostics':0,'screenshots':0},'actualSourceBindings31':receipt['sources'],'sourceBindingHashesMatchedImmutableHead':True,'actualBoundedSQLInstallation':{'exactTransactionalStatementsCommitted':11,'checkFragmentsReconstructedALTER':install['constraints'],'exactConcurrentOutsideTransactionIndex':install['cycleIndex'],'routineBindings12':receipt['productionRoutines'],'matchedIndependentPreparedSourceHashes':True,'scope':'Disposable hosted PG16 only, no complete historical migration/real restored-copy/production acceptance'},'sourceDiagnosis':{'priority':'P2','file':'scripts/workforce-employee-exception-browser-evidence.mjs','line':240,'observedErrorClass':'PrismaClientValidationError','requiredFieldOmitted':'caseRevision:Int has no schema default','supportedBy':'Actual immutable schema model and exact failing source line; existing classification historical seed includes caseRevision:index+1','qualification':'Raw private error text omitted by design. Missing required Prisma field is independently established; do not claim a retained raw error message or that no other failure can remain','minimalFixSuggested':'Add existing expected seed caseRevision:index+1; retain exact production trigger that allocates/rechecks revisions, same historical actor and timestamps. Do not weaken schema/guards/baseline','reproduction':'Actual hosted failure at required create boundary; no child local Prisma/SQL/browser rerun'},'cleanup':receipt['cleanup'],'actualCleanupDetails':receipt['cleanupDiagnostics'],'limitations':['Fixture seed stopped before authentication/browser scenarios; partial administrative seed writes already occurred, so no zero-business-write claim','No completed employee matrix, ACK/retry/manual14/audit14/historical immutability, 50keyboard, 21native or finalRLS/fingerprints/8rollback acceptance','No failurePNG exists because browser page was never created; do not fabricate pixel evidence','Remaining5 source jobs still running at this checkpoint; no pending PASS, no other-head acceptance','C6-006 PARTIAL, C14-003 PLANNED and C12 PARTIAL remain; no production activation, access/secret change, human AT/device or real operational credit'],'readerErrors':[],'actions':'Read-only whole logs/API/small ZIP and source/hash inspection; no edits, CI rerun/cancel, push, merge or production mutation'}
q=pathlib.Path('/tmp/hrm-employee-exception-hosted-first-failure-peer-review-2b055.json')
with q.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps(fb(q)))
