import subprocess,json,hashlib,re,gzip,pathlib,datetime,yaml
w=pathlib.Path('/mnt/HC_Volume_106454338/codex-alt-data/worktrees/leaddrive-hrm-employee-exception-browser-20261010')
source='b082013287fde961d7c07df8675c5384e3da4f28'; base='93e3644fed0fa5932a0215c09205454b3df6f42c'; initial='5b436eec01b0b405d9807393fb3ccb93d90b783e'
def git(*args): return subprocess.check_output(['git',*args],cwd=w)
def blob(sha,p): return git('show',f'{sha}:{p}')
def digest(b): return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def binding(sha,p): return {'path':p,**digest(blob(sha,p))}
def jobs(raw):
    raw=raw[raw.index(b'\njobs:\n')+len(b'\njobs:\n'):]
    matches=list(re.finditer(rb'^  ([A-Za-z0-9_-]+):\n',raw,re.M))
    return {m.group(1).decode():raw[m.start():matches[i+1].start() if i+1<len(matches) else len(raw)] for i,m in enumerate(matches)}
observedHead=git('rev-parse','HEAD').decode().strip()
assert subprocess.run(['git','merge-base','--is-ancestor',source,observedHead],cwd=w).returncode==0
assert not git('status','--porcelain').strip()
changed=git('diff','--name-only',base,source).decode().splitlines()
owned=[p for p in changed if not p.startswith('docs/')]
assert len(owned)==7 and len(changed)==13
workflow='.github/workflows/workforce-exception-report-browser-evidence.yml'
oldjobs=jobs(blob(base,workflow)); newjobs=jobs(blob(source,workflow))
assert len(oldjobs)==5 and len(newjobs)==6
oldblocks=[]
for name,raw in oldjobs.items():
    assert raw==newjobs[name],name
    oldblocks.append({'job':name,'byteEqualBase':True,**digest(raw)})
parsed=yaml.load(blob(source,workflow),Loader=yaml.BaseLoader)
assert len(parsed['jobs'])==6 and parsed['permissions']=={'contents':'read'}
job=parsed['jobs']['employee-exception-browser']
assert job['runs-on']=='ubuntu-24.04' and job['timeout-minutes']=='35'
assert job['env']['WF_EMPLOYEE_EXCEPTION_BROWSER']=='1'
assert '${{ secrets.' not in json.dumps(job) and 'environment' not in job
initialwf='.github/workflows/workforce-employee-exception-browser-evidence.yml'
initial_job=jobs(blob(initial,initialwf))['employee-exception-browser']; current_job=newjobs['employee-exception-browser']
condition=b"    if: ${{ (github.event_name == 'workflow_dispatch' && inputs.expected_head != '') || (github.event_name == 'pull_request' && !github.event.pull_request.draft) }}\n"
oldcondition=b"    if: ${{ github.event_name != 'pull_request' || !github.event.pull_request.draft }}\n"
assert current_job.replace(condition,oldcondition)==initial_job
native='scripts/workforce-native-browser-zoom.mjs'
oldlines=blob(base,native).splitlines(keepends=True); newlines=blob(source,native).splitlines(keepends=True)
assert len(oldlines)==len(newlines)
changedlines=[i+1 for i,(a,b) in enumerate(zip(oldlines,newlines)) if a!=b]
assert changedlines==[16,17,18]
assert oldlines[:15]==newlines[:15] and oldlines[18:]==newlines[18:]
root=json.loads(pathlib.Path('/tmp/hrm-employee-exception-5b-protected-source-root.json').read_text())
protected=[]; assert len(root['protected'])==20
for item in root['protected']:
    raw=blob(source,item['path']); assert raw==blob(base,item['path'])
    actual=binding(source,item['path']); assert actual['bytes']==item['bytes'] and actual['sha256']==item['sha256']
    protected.append({**actual,'byteEqualBase':True})
extra=['test-baseline.json','typecheck-baseline.json','scripts/ci/check-typecheck-gate.sh','scripts/ci/check-typecheck-baseline.mjs','scripts/check-test-baseline.mjs','scripts/ci/check-github-runner-policy.mjs','.github/workflows/pr-checks.yml','src/proxy.ts','clients/registry.json','docs/DEPLOYMENT.md']
additional=[]
for p in extra:
    assert blob(source,p)==blob(base,p),p
    additional.append({**binding(source,p),'byteEqualBase':True})
for p in ['scripts/ci/fixtures/workforce-employee-exception-browser.sql','scripts/workforce-employee-exception-browser-admission.mjs','src/__tests__/workforce-employee-exception-browser-admission.test.ts',native]: assert blob(source,p)==blob(initial,p),p
guard='src/__tests__/workforce-exception-report-browser-evidence-guard.test.ts'
oldguard=blob(base,guard).decode(); newguard=blob(source,guard).decode()
added='''  it.each([
    "WF_CALENDAR_BROWSER", "WF_MANAGER_TODAY_BROWSER", "WF_EXCEPTION_REPORT_BROWSER", "WF_EXCEPTION_CLASSIFICATION_BROWSER",
  ])("refuses employee exceptions when only %s is opted in", async otherOptIn => {
    vi.stubEnv("WF_EMPLOYEE_EXCEPTION_BROWSER", "0")
    vi.stubEnv(otherOptIn, "1")
    await expect(createNativeZoomContext("http://127.0.0.1:9/", "employee-exceptions")).rejects.toThrow()
    expect(nativeLauncher).not.toHaveBeenCalled()
  })

'''
assert newguard.count(added)==1
assert newguard.replace(added,'').replace('    ["employee-exceptions", "WF_EMPLOYEE_EXCEPTION_BROWSER", "/workforce/exceptions/mine"],\n','')==oldguard
harness=blob(source,'scripts/workforce-employee-exception-browser-evidence.mjs').decode()
variables={'lifecycle': 'prisma/migrations/20260830170000_workforce_exception_case_lifecycle/migration.sql', 'revision':'prisma/migrations/20260927014000_workforce_exception_case_revisions/migration.sql','response':'prisma/migrations/20260830200000_workforce_exception_employee_responses/migration.sql','index':'prisma/migrations/20260928123000_workforce_exception_response_cycle_unique_index/migration.sql'}
statementBindings=[]
for var,start,end in re.findall(r'\[\w+Path, extract\((\w+), "([^"]+)"(?:, "([^"]+)")?\)\]',harness):
    text=blob(source,variables[var]).decode(); end=end.replace('\\n','\n') if end else ';'
    assert text.count(start)==1
    a=text.index(start); b=text.index(end,a); sql=text[a:b+len(end)].encode()
    statementBindings.append({'path':variables[var],'kind':'EXACT_TRANSACTIONAL_STATEMENT','start':start,**digest(sql)})
assert len(statementBindings)==11
response=blob(source,variables['response']).decode()
names=['workforce_exception_employee_responses_client_id_check','workforce_exception_employee_responses_code_check','workforce_exception_employee_responses_request_shape_check']
constraintBindings=[]
for i,name in enumerate(names):
    marker=f'CONSTRAINT "{name}"'; assert response.count(marker)==1
    start=response.index(marker); end=response.index(f'\n  CONSTRAINT "{names[i+1]}"',start) if i<2 else response.index('\n);',start)
    fragment=response[start:end].rstrip().removesuffix(','); sql=f'ALTER TABLE public."workforce_exception_employee_responses" ADD {fragment};'
    constraintBindings.append({'name':name,'path':variables['response'],'kind':'EXACT_CHECK_FRAGMENT_RECONSTRUCTED_ALTER','fragment':digest(fragment.encode()),'executed':digest(sql.encode())})
index=blob(source,variables['index']).decode(); marker='CREATE UNIQUE INDEX CONCURRENTLY "workforce_exception_employee_responses_org_case_revision_key"'
assert index.count(marker)==1
start=index.index(marker); end=index.index(';',start); cycle=index[start:end+1].encode()
statementBindings.append({'path':variables['index'],'kind':'EXACT_STATEMENT_OUTSIDE_TRANSACTION',**digest(cycle)})
sourceList=re.search(r'for \(const path of (\[[^\n]+\])\) \{',harness); assert sourceList
sources=json.loads(sourceList.group(1)); sourceBindings=[binding(source,p) for p in sources]
archive='docs/evidence/hrm-employee-exception-browser-2026-10-10/02-prepared-qualified-two-path-peer-review/'
manifest=json.loads(blob(source,archive+'manifest.json')); archiveBindings=[]
for item in manifest['artifacts']:
    stored=blob(source,archive+item['path']); raw=gzip.decompress(stored)
    assert digest(stored)=={'bytes':item['storedBytes'],'sha256':item['storedSha256']}
    assert digest(raw)=={'bytes':item['originalBytes'],'sha256':item['originalSha256']}
    archiveBindings.append({'path':archive+item['path'],'stored':digest(stored),'original':digest(raw),'originalPreserved':True})
smoke=json.loads(blob(source,'docs/evidence/hrm-employee-exception-browser-2026-10-10/01-pure-admission-smoke.json'))
assert smoke['moduleSha256']==binding(source,'scripts/workforce-employee-exception-browser-admission.mjs')['sha256']
for sha in [base,initial,'973241bacc296b71fe817d1af11187c32e8126af']: assert subprocess.run(['git','merge-base','--is-ancestor',sha,source],cwd=w).returncode==0
assert blob(source,'docs/hrm-employee-exception-browser-session-log-2026-10-10.md').startswith(blob(initial,'docs/hrm-employee-exception-browser-session-log-2026-10-10.md'))
out={'reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_STATIC_BYTE_BINDINGS_ONLY','head':source,'base':base,'initial':initial,'tree':git('rev-parse',source+'^{tree}').decode().strip(),'initialTree':git('rev-parse',initial+'^{tree}').decode().strip(),'clean':True,'changedPaths':[binding(source,p) for p in changed],'ownCodePaths':owned,'sourceBindings':sourceBindings,'sourceBindingCount':len(sourceBindings),'oldWorkflowBlocks':oldblocks,'employeeJob':{'initialEquivalentExceptExplicitCondition':True,**digest(current_job),'runner':'ubuntu-24.04','timeoutMinutes':35},'protected20':protected,'additionalProtected':additional,'nativeMappingOnlyChangedLines':changedlines,'nativeEngineSuffix':digest(b''.join(newlines[18:])),'oldGuardVerbatimPreserved':True,'newGuardExecutionCountExpectedOnly':5,'productionRoutineStatements':statementBindings,'productionCheckFragments':constraintBindings,'originalArchiveBindings':archiveBindings,'pureAdmissionSmokeReportedByRoot':smoke,'baselineGatedKeyCount':len(json.loads(blob(source,'typecheck-baseline.json'))['gated']),'baselineKnownFailingFiles':len(json.loads(blob(source,'test-baseline.json'))['knownFailingFiles']),'runtime':'NOT_RUN'}
path=pathlib.Path('/tmp/hrm-employee-exception-b082-peer-static-bindings.json')
with path.open('x') as f: json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({'path':str(path),**digest(path.read_bytes()),'sourceBindingCount':len(sourceBindings),'oldWorkflowJobCount':len(oldblocks),'protected20':len(protected),'additionalProtected':len(additional),'expectedNewGuardExecutionsOnly':5,'runtime':'NOT_RUN'}))
