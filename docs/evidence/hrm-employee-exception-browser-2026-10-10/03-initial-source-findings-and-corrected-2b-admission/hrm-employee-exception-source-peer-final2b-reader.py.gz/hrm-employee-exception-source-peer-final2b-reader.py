import subprocess,json,pathlib,hashlib,datetime,re
w=pathlib.Path('/mnt/HC_Volume_106454338/codex-alt-data/worktrees/leaddrive-hrm-employee-exception-browser-20261010')
base='93e3644fed0fa5932a0215c09205454b3df6f42c';b082='b082013287fde961d7c07df8675c5384e3da4f28';af75='af75a070fe17a956578c7507f50e253ea5fb7e9a';final='2b05509eb16ec59b58bdc64d29b515f0ce929615'
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
def blob(s,p):return git('show',s+':'+p)
def sha(b):return hashlib.sha256(b).hexdigest()
def fb(p):
 q=pathlib.Path(p);b=q.read_bytes();return {'path':str(q),'bytes':len(b),'sha256':sha(b)}
def sb(s,p):
 raw=blob(s,p);return {'path':p,'bytes':len(raw),'sha256':sha(raw)}
def write(p,x):
 with pathlib.Path(p).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
 return fb(p)
assert git('rev-parse','HEAD').decode().strip()==final and not git('status','--porcelain').strip()
static=json.loads(pathlib.Path('/tmp/hrm-employee-exception-b082-peer-static-bindings.json').read_text());oldreview=json.loads(pathlib.Path('/tmp/hrm-employee-exception-final-source-peer-review-b082.json').read_text())
paths=git('diff','--name-only',b082,final).decode().splitlines()
assert paths==['docs/hrm-employee-exception-browser-session-log-2026-10-10.md','scripts/workforce-employee-exception-browser-evidence.mjs']
assert blob(final,paths[0]).startswith(blob(b082,paths[0]))
for item in static['changedPaths']:
 if item['path'] not in paths:assert blob(final,item['path'])==blob(b082,item['path'])
for item in static['protected20']+static['additionalProtected']:assert blob(final,item['path'])==blob(base,item['path'])
# Bind actual enum and grant schema/constraints; never execute Prisma or SQL.
schema=blob(final,'prisma/schema.prisma').decode()
def enum(name):return re.search(r'enum '+name+r' \{([^}]+)\}',schema).group(1).split()
assert enum('MtmAgentRole')==['ADMIN','MANAGER','SUPERVISOR','AGENT']
assert 'HR_ADMIN' in enum('WorkforceAccessRole') and 'ORGANIZATION' in enum('WorkforceAccessScopeKind')
h=blob(final,paths[1]).decode();previous=blob(af75,paths[1]).decode()
assert 'role: name === "hr" ? "HR" : "AGENT"' in previous
assert 'role: name === "hr" ? "MANAGER" : "AGENT"' in h
assert 'actorUserId: principals.hr.id' in h and 'assert.equal(others.hr.role, "MANAGER")' in h and 'assert.equal(principals.hr.role, "manager")' in h
assert 'actorUserId: principals.employee.id, responseCode: "ACKNOWLEDGED", observedCaseRevision: 1' in h
assert 'contextFor(tenant.principals.hr' not in h and 'contextFor(a.principals.hr' not in h
assert 'role: "HR_ADMIN", scopeKind: "ORGANIZATION"' in h and 'effectiveFrom: new Date("2024-01-01T00:00:00Z")' in h and 'grantedByUserId: principals.admin.id, grantReasonCode: "BROWSER_FIXTURE_ONLY"' in h
fixture=blob(final,'scripts/ci/fixtures/workforce-manager-today-browser.sql').decode()
assert '("role" IN (\'HR_ADMIN\', \'SCHEDULER\') AND "scopeKind" IN (\'ORGANIZATION\', \'TEAM\', \'SITE\'))' in fixture
assert '("scopeKind" = \'ORGANIZATION\' AND "scopeTeamId" IS NULL AND "scopeSiteId" IS NULL AND "scopeAgentId" IS NULL)' in fixture
# User/directory and organization-scoped grant are A-only, seeded before immutable facts.
assert 'for (const name of key === "a" ? ["other", "viewer", "hr"] : [])' in h
assert 'if (key === "a") {\n      const grant = await admin.workforceAccessGrant.create' in h
assert h.index('await admin.workforceAccessGrant.create')<h.index('async function fixedFacts')
changed=git('diff','--name-only',base,final).decode().splitlines();assert len(changed)==13 and len([p for p in changed if not p.startswith('docs/')])==7
workflow='.github/workflows/workforce-exception-report-browser-evidence.yml'; assert sha(blob(final,workflow))=='a57840b8db3f47405fe814fe1f360b3ac35ae7357b09ab42329bc139d4c9ec7e'
for s in [base,b082,af75,'973241bacc296b71fe817d1af11187c32e8126af']:assert subprocess.run(['git','merge-base','--is-ancestor',s,final],cwd=w).returncode==0
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
refusal={'sourceAttempted':af75,'actualCurrentHeadAtGuard':final,'status':'INITIAL_FINAL_REPORT_HEAD_DRIFT_REFUSAL_PRESERVED','originalStderr':'Traceback (most recent call last):\n  File "/tmp/hrm-employee-exception-source-peer-report-writer.py", line 30, in <module>\n    assert git("rev-parse","HEAD").decode().strip()==final and not git("status","--porcelain").strip()\nAssertionError\n','scope':'Read-only report writer, not CI or source execution','reportsActuallyCreatedBeforeRefusal':['/tmp/hrm-employee-exception-source-peer-review-5b.json','/tmp/hrm-employee-exception-final-source-peer-review-b082.json'],'af75AcceptanceReportCreated':False}
r=write('/tmp/hrm-employee-exception-af75-peer-final-head-refusal.json',refusal)
af={'reviewedAtUtc':now,'status':'PREPUBLICATION_SOURCE_ENUM_P2_PRESERVED_NOT_ACCEPTED_RUNTIME_NOTRUN','source':af75,'tree':git('rev-parse',af75+'^{tree}').decode().strip(),'parent':b082,'finding':{'priority':'P2','reportedBy':'root before publication/execution','file':paths[1],'lines':[217,239],'problem':'Prepared provenance correction inserted role HR into MtmAgent; actual immutable schema permits only ADMIN/MANAGER/SUPERVISOR/AGENT. Distinct WorkforceAccessRole HR_ADMIN must not be conflated with directory enum. This would prevent fixture seed reaching browser evidence','actualEnum':enum('MtmAgentRole'),'fixedAt':final,'fix':'Directory MANAGER plus existing separate HR_ADMIN ORGANIZATION-scoped disposable grant, real schema preserved','actualRuntimeFailure':False},'sourceBindings':[sb(af75,p) for p in paths],'headGuardRefusal':r,'limitations':oldreview['limitations']}
afBinding=write('/tmp/hrm-employee-exception-af75-provenance-source-peer-review.json',af)
sourceReceiptBindings=[sb(final,item['path']) for item in static['sourceBindings']]
report={'reviewedAtUtc':now,'status':'ACCEPTED_FINAL_SOURCE_ONLY_NO_REMAINING_P0_P1_P2_RUNTIME_NOTRUN','source':final,'tree':git('rev-parse',final+'^{tree}').decode().strip(),'base':base,'parent':af75,'cleanObserved':True,'worktree':str(w),'branch':git('branch','--show-current').decode().strip(),'origin':git('remote','get-url','origin').decode().strip(),'mainLastRead':base,'initial5BReport':fb('/tmp/hrm-employee-exception-source-peer-review-5b.json'),'fullHistoricalB082Report':fb('/tmp/hrm-employee-exception-final-source-peer-review-b082.json'),'originalAf75EnumFindingReport':afBinding,'changedSourceBindings':[sb(final,p) for p in changed],'ownCodePaths':[p for p in changed if not p.startswith('docs/')],'deltaVsB082Paths':paths,'preparedReview':oldreview['preparedReview'],'finalProvenanceReview':{'crmUserRole':'manager','directoryRole':'MANAGER','actualDirectoryEnum':enum('MtmAgentRole'),'workforceAccessLedgerRole':'HR_ADMIN','scopeKind':'ORGANIZATION','principal':'Distinct A-only enrolled synthetic history principal; no authentication executed for it','grant':'A-only fixture row, granted by synthetic admin, effective2024 before imported2025 history; organization scope nullable scope IDs, valid reason/operation shape, same-tenant foreign keys. Existing inactive/granular-flag semantics preserved, no production access or HR authorization credit','historicalDecisions':'ACK/RESOLVE_NO_CHANGE/REOPEN rows now use distinct principal; administrator-imported history, not live HR decisions','historicalAndNewEmployeeResponses':'Remain existing CRM sales and directory AGENT','factControlSets':'Grant and extra enrolled directory/user seed are created before all12 immutable fingerprints; no later grant/auth write','schemaValidationEvidence':[sb(final,'prisma/schema.prisma'),sb(final,'scripts/ci/fixtures/workforce-manager-today-browser.sql'),sb(final,'prisma/migrations/20260830193000_workforce_access_grants/migration.sql')],'runtime':'NOT_RUN'},'unchanged':{'otherOwnedPathsByteEqualB082':True,'old5WorkflowBlocksByteEqual93E':static['oldWorkflowBlocks'],'workflowSHA256':sha(blob(final,workflow)),'protected20ByteEqual93E':static['protected20'],'additionalProtected10ByteEqual93E':static['additionalProtected'],'nativeEngineByteEqual93EExcept3FixedMappingLines':True,'wholeSharedGuardByteEqualB082Expected36Only':True,'baselines':{'gatedKeys':64,'knownFailingFiles':18,'immutable':True,'executionCredit':False},'productionStatementAndCheckBindingsUnchanged':True,'applicationUIAPISchemaRolesDefaultFlagsDeploySupportUnchanged':True},'productionStatementBindings':static['productionRoutineStatements'],'productionCheckFragmentBindings':static['productionCheckFragments'],'plannedRuntimeSourceReceiptBindings31':sourceReceiptBindings,'sourceReceiptInventoryNotRuntime':True,'nativeReviewQualification':oldreview['nativeQualification'],'expectedRuntimeCountsNotObserved':oldreview['expectedRuntimeCountsNotObserved'],'pureAdmissionSmoke':oldreview['pureNodeSmoke'],'originalPreparedArchiveBindings':static['originalArchiveBindings'],'sourceReviewerFindings':[],'resolvedOriginalP2':oldreview['initialP2Retained'],'preservedReaderErrors':oldreview['readerErrors']+[r],'readerErrorNotes':oldreview['readerErrorNotes']+[{'scope':'Report writer','classification':'HEAD_DRIFT_REFUSAL_NOT_CI','report':r},{'scope':'Read-only schema discovery','classification':'GUESSED_PATH_READ_ERRORS_NOT_CI','paths':['src/lib/workforce/directory-access.ts','src/lib/workforce/access-scope.ts','src/lib/workforce/access-grants.ts'],'correction':'Read actual actor.ts, schema enum/model and unchanged Today fixture grant constraints directly; no source mutation'}],'limitations':oldreview['limitations'],'nextRequired':'Publish frozen2b to draft PR and run all6 hosted source jobs; preserve whole originals and actual failure/repeat results. Actual employee Vitest/PG/browser/native/compiler/build NOT RUN until hosted; no merge or release credit.'}
rb=write('/tmp/hrm-employee-exception-final-source-peer-review-2b055.json',report)
print(json.dumps({'finalReport':rb,'af75OriginalFinding':afBinding,'initialReport':report['initial5BReport'],'b082Report':report['fullHistoricalB082Report'],'source':final,'tree':report['tree'],'status':report['status'],'runtime':'NOT_RUN'},indent=2))
