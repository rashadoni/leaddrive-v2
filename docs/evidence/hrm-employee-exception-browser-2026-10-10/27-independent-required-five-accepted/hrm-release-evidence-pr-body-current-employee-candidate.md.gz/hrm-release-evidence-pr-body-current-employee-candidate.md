Append-only HRM verification and release archive. This draft PR is evidence only and must not be merged into production.

Preserves the original accepted PR608 `973241bacc296b71fe817d1af11187c32e8126af` evidence, the C6-010 acceptance/release, PR672 and PR674 verified releases, and every subsequent employee browser failure, correction and exact-commit repeat.

Current PR678 source `7ca34739e490fb3ef7d88346e4e83c08cf50b665` passed all six source lanes. Candidate `e3a6c527533072044efa1a289748be0eac51a1d3` has the same whole tree and parents `[main 0a6300e7, source]`; all four fresh browser lanes and all five required contexts succeeded. Candidate root and independent content/pixel reviews are preserved through employee phase26. Independent required-five review and normal release are pending.

Original full logs, API metadata, digest/size/CRC checked artifacts, compiler diagnostics, actual pixel samples, source bindings and initially failed evidence readers remain immutable in numbered phases. Historical full compiler/suite errors are retained: strict baselines are unchanged. Skipped jobs receive no execution credit.

Accounting remains 85/161 done, 76 open, weighted 61%. C6-006 and C12 remain partial; C14 remains open. Restored-copy/full-history, physical devices, human AT and operational observations are not replaced by synthetic CI. PR606/609 and validation-only PR646 remain unmerged. Journals record the precise current stopping point and next action.
