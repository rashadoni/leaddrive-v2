from pathlib import Path
import sys,json,gzip,subprocess,re,collections,hashlib,datetime
out=Path(sys.argv[1]);M,H,B=sys.argv[2:5]
s=json.loads((out/'finite-capture-summary.json').read_text());assert s['headSha']==M and s['event']=='push'
j=next(x for x in s['jobs']if x['name']=='typecheck');assert j['conclusion']=='success'
c=json.loads(subprocess.check_output(['gh','api',f"repos/rashadoni/leaddrive-v2/check-runs/{j['id']}"]));assert c['head_sha']==M and c['app']['id']==15368 and c['conclusion']=='success'
(out/'main-typecheck-app-api-original.json').write_text(json.dumps(c,indent=2)+'\n')
b=gzip.decompress((out/f"job-{j['id']}-original.txt.gz").read_bytes());log=re.sub(r'\x1b\[[0-9;]*m','',b.decode());ls=log.splitlines();checkout=[]
for i,l in enumerate(ls):
 if 'git log -1 --format=%H' in l:checkout+=ls[i:i+2]
assert re.findall('[a-f0-9]{40}','\n'.join(checkout))[-1]==M
rx=re.compile(r'^(\S+\.tsx?)\((\d+),(\d+)\):\s*error\s+(TS\d+):')
rows=[]
for l in ls:
 l=re.sub(r'^\d{4}-\d\d-\d\dT[\d:.]+Z\s*','',l).replace('##[error]','');m=rx.match(l)
 if m:rows.append(m.groups())
assert rows
families=collections.Counter(x[3]for x in rows);gate={'TS2339','TS2345','TS2353','TS2322','TS2554','TS2551'};pairs=collections.Counter(x[0]+' '+x[3]for x in rows if x[3]in gate)
baseline=json.loads(subprocess.check_output(['git','show',H+':typecheck-baseline.json']))['gated'];assert dict(pairs)==baseline and len(pairs)==64
assert subprocess.check_output(['git','show',B+':typecheck-baseline.json'])==subprocess.check_output(['git','show',H+':typecheck-baseline.json'])
critical=[x for x in rows if re.fullmatch('TS1[0-9]{3}|TS2307|TS2304|TS2552',x[3])];assert not critical
owned=subprocess.check_output(['git','diff','--name-only',B,H],text=True).splitlines();own=[x for x in rows if x[0]in owned];assert not own
assert 'Typecheck completed (exit 2). No syntax, missing-module or undefined-name errors.'in log
assert f'check-typecheck-baseline: 64 gated pair(s) now, 64 in baseline ({len(rows)} errors total).'in log
r={'status':'ACTUAL_EXACT_MAIN_TYPECHECK_STRICT_SUCCESS_GLOBAL_NONCLEAN','mainSha':M,'sourceSha':H,'baseSha':B,'runId':s['runId'],'jobId':j['id'],'appId':15368,'actualCheckout':M,'actualDiagnosticCount':len(rows),'actualFamilies':dict(sorted(families.items())),'actualFamilyCount':len(families),'actualExit':2,'critical':critical,'ownedDiagnostics':own,'strictPairCountsExactlyUnchanged':64,'globalClean':False,'wholeOriginalLogBytes':len(b),'wholeOriginalLogSha256':hashlib.sha256(b).hexdigest(),'observedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mainStaticSkippedReceivesNoCredit':True,'scope':'Actual main full compiler log independently parsed; source/candidate and production quality suite remain separately bound, no prior diagnostic count imposed'}
p=out/'root-main-typecheck-content-review.json';assert not p.exists();p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k]for k in ['status','mainSha','actualDiagnosticCount','actualFamilyCount','actualExit','strictPairCountsExactlyUnchanged','wholeOriginalLogBytes']}))
