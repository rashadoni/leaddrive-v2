import subprocess,json,datetime,re,sys,urllib.parse
from pathlib import Path
expected=sys.argv[1];run=int(sys.argv[2]);out=Path(sys.argv[3]);assert re.fullmatch('[0-9a-f]{40}',expected)
observations=[]
paths=['/api/v1/workforce/exceptions','/api/v1/workforce/exception-reports','/api/v1/workforce/exceptions/mine']
for path in paths:
 for mode in ['browser-fetch','plain-navigation']:
  url='https://app.leaddrivecrm.org'+path
  command=['curl','-q','--silent','--show-error','--connect-timeout','5','--max-time','12','--resolve','app.leaddrivecrm.org:443:13.140.132.245','--user-agent','Mozilla/5.0','--header','Cache-Control: no-cache','--write-out','\n%{http_code}|%{ssl_verify_result}|%{redirect_url}\n']
  if mode=='browser-fetch':command+=['--header','Sec-Fetch-Mode: cors']
  response=subprocess.check_output(command+[url],timeout=15);assert len(response)<65536
  body,trailer=response.decode().rstrip('\n').rsplit('\n',1);http,tls,redirect=trailer.split('|',2);http=int(http);tls=int(tls);assert tls==0
  if mode=='browser-fetch':
   assert http==401 and redirect==''
   value=json.loads(body);assert value=={'error':'Unauthorized','code':'session_expired'}
   finite={'error':'Unauthorized','code':'session_expired'}
  else:
   assert http==307
   parsed=urllib.parse.urlsplit(redirect)
   assert parsed.scheme=='https' and parsed.netloc=='app.leaddrivecrm.org' and parsed.path=='/login'
   assert urllib.parse.parse_qs(parsed.query)=={'callbackUrl':[path]}
   finite={'sameHostLoginRedirect':True,'callbackPath':path}
  observations.append({'path':path,'method':'GET','mode':mode,'http':http,'tlsVerified':True,'pinnedAddress':'13.140.132.245','value':finite,'observedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
assert not out.exists()
out.write_text(json.dumps({'status':'PASS_ANONYMOUS_HRM_EMPLOYEE_PRIVACY_SMOKE','expectedMain':expected,'deploymentRun':run,'scope':'Existing anonymous GET access contracts including employee own-only discovery; no authenticated employee/HR UI or real outcomes credit, no writes or rollout changes','observations':observations},indent=2)+'\n')
print(json.dumps({'status':'PASS_ANONYMOUS_HRM_EMPLOYEE_PRIVACY_SMOKE','observations':len(observations),'authenticatedHr':'NOT_RUN_NO_APPROVED_SESSION'}))
