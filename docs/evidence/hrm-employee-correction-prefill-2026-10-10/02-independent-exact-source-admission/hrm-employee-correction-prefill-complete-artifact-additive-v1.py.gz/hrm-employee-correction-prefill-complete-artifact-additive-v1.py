from pathlib import Path
import sys, json, subprocess, zipfile, hashlib, struct, re, math, datetime

directory = Path(sys.argv[1]); head = sys.argv[2]
assert re.fullmatch(r'[a-f0-9]{40}', head)
receipt_path = directory / 'root-complete-employee-correction-prefill-content-review.json'
assert not receipt_path.exists()
summary = json.loads((directory / 'employee-terminal-job-root-summary.json').read_text())
assert summary['headSha'] == head and summary['jobConclusion'] == 'success'
r = summary['receipt']
candidate = sys.argv[3] if len(sys.argv) > 3 else head
assert re.fullmatch(r'[a-f0-9]{40}', candidate)
assert r['sourceHead'] == head and r['checkedMergeSha'] == candidate
if candidate != head:
    assert len(sys.argv) == 5
    base = sys.argv[4]
    assert re.fullmatch(r'[a-f0-9]{40}', base)
    actual_parents = subprocess.check_output(['git','rev-list','--parents','-n','1',candidate]).decode().split()[1:]
    assert actual_parents == [base, head]
    assert subprocess.check_output(['git','rev-parse',candidate+'^{tree}']) == subprocess.check_output(['git','rev-parse',head+'^{tree}'])
assert r['status'] == r['cleanup'] == 'PASS' and 'failure' not in r
assert all(x['status'] == 'PASS' for x in r['cleanupDiagnostics'])
def digest(b): return hashlib.sha256(b).hexdigest()
def source(path): return subprocess.check_output(['git', 'show', head + ':' + path])
assert len(r['sources']) == 45 and len({x['path'] for x in r['sources']}) == 45
for item in r['sources']:
    b = source(item['path'])
    assert len(b) == item['bytes'] and digest(b) == item['sha256']
assert r['matrix'] == {'locales':['az','ru','en'], 'widths':[320,768,1440], 'standardExpected':9, 'nativeExpected':3}
expected_cells = {f'{locale}-standard-{width}' for locale in ['az','ru','en'] for width in [320,768,1440]}
expected_cells |= {f'{locale}-native-320' for locale in ['az','ru','en']}
cases = {x['name']:x for x in r['cases']}
assert len(cases) == len(r['cases']) == 15
assert set(cases) == expected_cells | {'injected-load-failure-real-refresh', 'actual-self-boundaries-and-two-positive-tenants', 'actual-cross-tab-logout-and-same-tenant-principal-change'}
assert all(x['status'] == 'PASS' for x in cases.values())
for name in expected_cells:
    x = cases[name]
    assert all(x[k] is True for k in ['ownOnlyMinimizedProjection','reopenedOldResponseNotAcknowledged','keyboardRefreshAndAcknowledgement','exactDayCorrectionNavigation','noShowViewOnly'])
    assert x['nativeZoom'] == ('-native-' in name)
boundary = cases['actual-self-boundaries-and-two-positive-tenants']
assert all(v is True for k,v in boundary.items() if k not in ['name','status'])
assert len(r['authenticationDiagnostics']) == 22
for x in r['authenticationDiagnostics']:
    assert x['csrfStatus'] == x['callbackStatus'] == 200
    if x['mandatoryTotp']:
        assert x['verificationStatus'] == x['sessionUpdateStatus'] == 200
        assert x['verificationWarmupStatus'] == 405 and x['nonceConsumed'] is True
faults = {x['kind']:x for x in r['networkFaultDiagnostics']}
assert len(faults) == len(r['networkFaultDiagnostics']) == 2
assert faults['LOAD_FAILURE'] == {'kind':'LOAD_FAILURE','injected':True,'injectedStatus':503,'realRefreshStatus':200,'recovery':True}
assert faults['COMMITTED_POST_RESPONSE_LOST'] == {'kind':'COMMITTED_POST_RESPONSE_LOST','injected':True,'committedStatus':201,'retryStatus':200,'sameOperation':True,'sameResponse':True,'duplicateRows':0}
assert len(r['keyboardFocusDiagnostics']) == 50
for x in r['keyboardFocusDiagnostics']:
    b,c = x['box'], x['clip']
    assert x['focused'] is True and x['focusVisible'] is True
    assert all(math.isfinite(v) for v in list(b.values()) + list(c.values()))
    assert b['width'] > 0 and b['height'] >= 43
    assert b['left'] >= c['left']-1 and b['right'] <= c['right']+1
    assert b['top'] >= c['top']-1 and b['bottom'] <= c['bottom']+1
    if x['nativeZoom']: assert x['viewport']['width'] == 320
def css_unchanged(x):
    assert x['visualViewportScale'] == 1
    assert x['rootZoom'] in ['1','normal'] and x['bodyZoom'] in ['1','normal']
    assert x['rootTransform'] == x['bodyTransform'] == 'none'
assert len(r['nativeZoomDiagnostics']) == 6
proofs = {(x['locale'],x['phase']):x for x in r['nativeZoomDiagnostics']}
assert set(proofs) == {(l,p) for l in ['az','ru','en'] for p in ['INITIAL','AFTER_CORRECTION_RETURN']}
for x in proofs.values():
    assert x['status'] == 'PASS' and x['method'] == 'BROWSER_TABS_AUTOMATIC_PER_TAB_ZOOM'
    assert x['fixture'] == 'employee-exceptions' and x['factor'] == 2
    assert x['event']['oldFactor'] == 1 and x['event']['newFactor'] == 2
    for settings in [x['settings'],x['event']['settings']]:
        assert settings['mode'] == 'automatic' and settings['scope'] == 'per-tab'
    a,b = x['control'],x['zoomed']
    assert a['width'] == 640 and a['devicePixelRatio'] == 1 and a['height'] >= 800
    assert b['width'] == 320 and b['devicePixelRatio'] == 2 and abs(b['height']*2-a['height']) <= 2
    css_unchanged(a); css_unchanged(b)
    assert x['viewportEmulation'] is False and x['applicationCssChanged'] is False and x['applicationServiceWorkers'] == 0
for locale in ['az','ru','en']:
    initial,returned = proofs[(locale,'INITIAL')],proofs[(locale,'AFTER_CORRECTION_RETURN')]
    assert initial['control'] == returned['control']
    assert returned['originalPhysicalWindowPreserved'] is True
assert len(r['nativeCurrentDiagnostics']) == 30
for x in r['nativeCurrentDiagnostics']:
    assert x['width'] == 320 and x['devicePixelRatio'] == 2; css_unchanged(x)
assert len(r['nativeCaptureDiagnostics']) == 27
assert sum(x['control'] for x in r['nativeCaptureDiagnostics']) == 6
assert len({x['screenshot'] for x in r['nativeCaptureDiagnostics']}) == 27
zip_path = directory / f"artifact-{summary['artifact']['id']}-original.zip"
assert digest(zip_path.read_bytes()) == summary['artifact']['sha256']
pixel_rows = []
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None
    members = z.namelist()
    receipt_members = [n for n in members if n.endswith("employee-exception-receipt.json")]
    assert len(receipt_members) == 1
    member_prefix = receipt_members[0].removesuffix("employee-exception-receipt.json")
    for x in r['nativeCaptureDiagnostics']:
        matches = [n for n in members if n == member_prefix + x['screenshot']]
        assert len(matches) == 1
        b = z.read(matches[0]); assert len(b) == x['original']['bytes'] and digest(b) == x['original']['sha256']
        assert b[:8] == bytes([137,80,78,71,13,10,26,10]) and b[12:16] == b'IHDR'
        width,height = struct.unpack('>II',b[16:24]); assert {'width':width,'height':height} == x['pixels'] == x['controlSurface']
        assert x['status'] == x['cleanup'] == 'PASS' and x['method'] == 'CDP_VISIBLE_SURFACE_NO_CLIP' and x['suppliedClip'] is False
        assert x['before'] == x['after'] and x['layoutBefore'] == x['layoutAfter']
        before = x['before']; assert before['sameFocusedElement'] is True and before['sameScrollNodes'] is True
        assert len(before['scrollContainers']) <= 64 and all(n['connected'] for n in before['scrollContainers'])
        assert before['width'] == (640 if x['control'] else 320)
        assert before['devicePixelRatio'] == (1 if x['control'] else 2)
        assert width == before['width']*before['devicePixelRatio']
        assert abs(height-before['height']*before['devicePixelRatio']) <= before['devicePixelRatio']; css_unchanged(before)
        if x['control']: assert 'control-100' in x['screenshot']
        pixel_rows.append({'path':matches[0],'bytes':len(b),'sha256':digest(b),'control100':x['control'],'pixels':x['pixels']})
    selected = ['az-native-320-ack-focus.png','ru-native-320-final-own-boundary.png','en-native-320-acknowledged.png','az-standard-320-committed-response-lost.png']
    pixels_dir = directory/'original-pixels'; pixels_dir.mkdir()
    for name in selected:
        matches = [n for n in members if n == member_prefix + name]; assert len(matches) == 1
        (pixels_dir/name).write_bytes(z.read(matches[0]))
assert len(r['captureDiagnostics']) >= 42
assert all(x == {'freeTextEmpty':True,'protectedSubjectsAbsent':True} for x in r['captureDiagnostics'])
for x in r['recoveryAlertDiagnostics']:
    assert x['globalAlerts'] <= 16 and x['overflow'] is False
    assert all(a['insideOwnSection'] is False and (a['developmentPortal'] or a['canonicalRouteAnnouncer']) for a in x['alerts'])
installation = r['productionRoutineInstallation']
assert installation['status'] == 'COMMITTED' and installation['exactStatements'] == 11
assert installation['cycleIndex'] == 'APPLIED_OUTSIDE_TRANSACTION_VALID_UNIQUE_NULLS_DISTINCT'
assert len(r['productionRoutines']) == 12 and sum(x['kind']=='EXACT_STATEMENT' for x in r['productionRoutines']) == 11
for x in r['productionRoutines']:
    raw = source(x['path']).decode()
    candidates = re.findall(r'CREATE OR REPLACE FUNCTION .*?\n\$\$;', raw, re.S)
    candidates += re.findall(r'CREATE (?:UNIQUE INDEX CONCURRENTLY|TRIGGER) .*?;', raw, re.S)
    matches = [a.encode() for a in candidates if digest(a.encode()) == x['sha256']]
    assert len(matches) == 1 and len(matches[0]) == x['bytes']
constraints = installation['constraints']; assert len(constraints) == 3
for i,x in enumerate(constraints):
    raw = source(x['path']).decode(); start = raw.index('CONSTRAINT "'+x['name']+'"')
    end = raw.index('\n  CONSTRAINT "'+constraints[i+1]['name']+'"',start) if i<2 else raw.index('\n);',start)
    fragment = raw[start:end].rstrip().removesuffix(',')
    executed = 'ALTER TABLE public."workforce_exception_employee_responses" ADD '+fragment+';'
    assert x['kind'] == 'EXACT_CHECK_FRAGMENT_RECONSTRUCTED_ALTER'
    assert digest(fragment.encode()) == x['fragmentSha256'] and digest(executed.encode()) == x['executedSha256']
db = r['database']
assert db['actualNewResponses'] == db['actualNewAudits'] == 14 and db['historicalResponses'] == 1
assert db['nonownerForcedRls'] is True and db['unscopedRows'] == db['foreignRows'] == 0
assert all(db[k] is True for k in ['populatedResponseAndAuditControlsInTwoTenants','exactAuditLinkAndFiveMetadataKeys','exactProductionResponseImmutability','syntheticAuditGuard'])
assert db['cycleUniqueRollbackSqlState'] == '23505'
assert db['defaultAclReviewed'] is False and db['fullHistoricalReplay'] is False
assert [x['actualSqlState'] for x in r['databaseDiagnostics']] == ['55000']*4+['42501']*2+['23505','23514']
assert all(x['actualSqlState'] == x['expectedSqlState'] and x['rolledBack'] is True for x in r['databaseDiagnostics'])
assert r['fixedFacts']['unchanged'] is True and len(r['fixedFacts']['tables']) == 13
tables = {x['table']:x for x in r['fixedFacts']['tables']}
assert len(tables) == 13 and tables['workforce_exception_cases']['rows'] == 20 and tables['workforce_exception_decisions']['rows'] == 6
assert tables['workforce_shift_templates']['rows'] == tables['workforce_shift_segments']['rows'] == 3
assert tables['historical-response-before-reopened-cycle']['rows'] == 1
assert all(re.fullmatch(r'[a-f0-9]{64}',x['sha256']) for x in tables.values())
# Additive independent exact-source session diagnostic review. All legacy v3 bounds remain.
assert len(r['sessionTransitionDiagnostics']) == 1
transition = r['sessionTransitionDiagnostics'][0]
assert transition['method'] == 'ACTUAL_HEADER_SIGN_OUT_CANONICAL_MFA_AND_PROVIDER_REFRESH'
assert all(transition[k] is True for k in ['sameBrowserContext','sameObservedDocument','loggedOutSessionAbsent','sameTenantDifferentPrincipal','nextEmptyUiObserved','countsAndKnownFactsUnchanged'])
assert all(transition[k] is False for k in ['observedTabNavigationImposed','manualCookieSessionOrBroadcastInjection','overflow'])
assert transition['canonicalSignOutStatus'] == transition['canonicalNextProjectionStatus'] == 200
assert transition['populatedFirstScope'] == 16
assert transition['previousRowsAfterLogout'] == transition['nextProjectionRows'] == transition['employeeLedgerWrites'] == 0
assert transition['immutableFactControlCount'] == 13
assert 'businessWrites' not in transition
assert transition['qualification'] == 'Second existing linked employee has no imported cases; successful own-only API and actual empty UI required, no populated second-scope claim'
observations = transition['observations']; assert 1 < len(observations) <= 512
assert all(set(x) == {'nextPrincipalHeader','previousScopeArticles'} and type(x['nextPrincipalHeader']) is bool and type(x['previousScopeArticles']) is int and 0 <= x['previousScopeArticles'] <= 16 for x in observations)
assert any(x['previousScopeArticles'] == 16 for x in observations)
assert any(x['nextPrincipalHeader'] for x in observations)
assert all(not x['nextPrincipalHeader'] or x['previousScopeArticles'] == 0 for x in observations)
# Additive actual request-form prefill review. Every inherited session/employee assertion above is retained.
prefill = r['correctionPrefillDiagnostics']; assert len(prefill) == 12
assert {x['cell'] for x in prefill} == expected_cells
for x in prefill:
    assert x['locale'] in ['az','ru','en'] and x['cell'].startswith(x['locale']+'-')
    assert x['actualOwnRequestsStatus'] == 200 and x['initialType'] == 'TIME_CORRECTION'
    assert all(x[k] is True for k in ['ownScope','ownOptionsOnly','exactRecordedWorkdaySelected','timeAndReasonInitiallyEmpty','emptySubmitDisabled','typeChangeDisplaysEmptyLeaveDates','returningToCorrectionDiscardsDisplayedPrefill','alternateOwnDaySelectable','responseAuditCountsUnchanged'])
    assert type(x['workdayCount']) is int and 1 < x['workdayCount'] <= 100
    assert x['observedInteractionRequestPosts'] == x['requestsBeforeAndAfter'] == 0
    assert 'requestPosts' not in x
    assert x['requestObserverScope'] == 'Three type/day interactions after initial prefill; persisted requests remain zero, no whole-navigation POST absence claim'
    assert x['qualification'] == 'Read-only form controls and actual own-only GET only; no submitted body/source-link/successful correction or native request-form zoom acceptance'
    viewport = x['actualFormViewport']
    assert set(viewport) == {'width','devicePixelRatio'} and all(math.isfinite(v) and v > 0 for v in viewport.values())
    if '-standard-' in x['cell']: assert viewport['width'] == int(x['cell'].rsplit('-',1)[1])
    # Native form viewport is diagnostic only: return-to-mine native proof remains separately mandatory.
result = {'status':'ACTUAL_EXACT_EMPLOYEE_ARTIFACT_CONTENT_ACCEPTED_PIXELS_EXTRACTED_FOR_VIEW','reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'checkedCandidate':candidate,'wholeCandidateTreeMatchesSource':True,'run':summary['runId'],'job':summary['jobId'],'cases':15,'matrixCells':12,'authentication':22,'focus':50,'nativeProofs':6,'nativeCaptures':27,'control100Captures':6,'native200Captures':21,'nativeCurrentAdmissions':30,'newResponses':14,'newAudits':14,'historicalResponses':1,'fingerprintControlSets':13,'sourceBindings':45,'correctionPrefillCells':12,'correctionPrefillDiagnostics':prefill,'observedInteractionRequestPosts':0,'successfulCorrectionSubmissionAccepted':False,'requestFormNativeZoomAccepted':False,'exactProductionStatementsInTransaction':11,'exactProductionIndexOutsideTransaction':1,'reconstructedCheckFragments':3,'rollbackSqlStates':[x['actualSqlState'] for x in r['databaseDiagnostics']],'originalNativePixels':pixel_rows,'pixelsStillNeedActualView':selected,'sessionTransitionDiagnostic':transition,'legacyV3BoundsPreserved':True,'limits':r['limitations'],'actions':'Read-only current originals and Git source; no tests/reruns/source/production changes'}
receipt_path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','head','run','cases','focus','nativeProofs','nativeCaptures','newResponses','fingerprintControlSets']}))
