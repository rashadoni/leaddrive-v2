from pathlib import Path
import subprocess,json,gzip,datetime,hashlib

H='2e4b711b405eb2629cc25e16ff6fafee6b88ba16'
B='bfe456042a018864fead8be64d5f154911195af0'
C='18f64568ac68dfca227bb1ca73535ae580b19dcc'
p=Path('/tmp/hrm-employee-correction-recovery-2e4b-final-premerge-root')
assert not p.exists();p.mkdir()
def api(path,label):
    raw=subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/'+path])
    (p/(label+'.json.gz')).write_bytes(gzip.compress(raw,mtime=0));return json.loads(raw)
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
assert git('rev-parse','HEAD')==H and git('branch','--show-current')=='codex/hrm-employee-correction-recovery-20261010'
assert git('remote','get-url','origin')=='https://github.com/rashadoni/leaddrive-v2.git'
assert not git('status','--porcelain')
main=api('git/ref/heads/main','main');pr=api('pulls/684','pr684')
ref=api('git/ref/heads/codex/hrm-employee-correction-recovery-20261010','source-ref')
c=api('git/commits/'+C,'candidate');src=api('git/commits/'+H,'source')
assert main['object']['sha']==B and pr['base']['sha']==B and pr['base']['ref']=='main'
assert pr['state']=='open' and not pr['draft'] and not pr['merged'] and pr['head']['sha']==ref['object']['sha']==H
assert pr['merge_commit_sha']==C and pr['mergeable'] is True
assert [x['sha']for x in c['parents']]==[B,H] and c['tree']['sha']==src['tree']['sha']==git('rev-parse',H+'^{tree}')
assert git('rev-list','--parents','-n','1',C).split()[1:]==[B,H]
checks=api('commits/'+H+'/check-runs?per_page=100&filter=latest','latest-checks');assert checks['total_count']==len(checks['check_runs'])
want={'pr-scope':114214913505,'static-checks':114214980027,'typecheck':114214979978,'runner-policy':114210097759,'scan':114210097688}
latest=[]
for name,jid in want.items():
    rows=[x for x in checks['check_runs']if x['name']==name];assert rows
    x=max(rows,key=lambda y:(y['started_at']or'',y['id']))
    assert x['id']==jid and x['head_sha']==H and x['app']['id']==15368 and x['status']=='completed' and x['conclusion']=='success'
    latest.append({'name':name,'id':jid,'app':15368,'actualSuccess':True})
protection=api('branches/main/protection','protection')
assert {(x['context'],x['app_id'])for x in protection['required_status_checks']['checks']}=={(x,15368)for x in want}
assert protection['required_status_checks']['strict'] is False and protection['enforce_admins']['enabled'] is True
assert not protection['allow_force_pushes']['enabled'] and not protection['allow_deletions']['enabled']
assert protection['required_pull_request_reviews']['required_approving_review_count']==0
for n in [606,609,646,663]:
    x=api('pulls/'+str(n),'excluded-pr'+str(n));assert not x['merged']
    if n in [606,609]:assert x['state']=='closed'
    else:assert x['state']=='open' and x['draft']
for n,h in [(589,'33f93325599e883973c4c71c256cce8ad91168b3'),(605,'ec2e7812e81abef94319a58818aeee22e56984df'),(608,'100a381b90a52690899f6a1eded38494eea050e4')]:
    x=api('pulls/'+str(n),'preserved-pr'+str(n));assert x['merged'] and x['head']['sha']==h
for h in ['973241bacc296b71fe817d1af11187c32e8126af','c123556e7a758b7eb5264137dcaf85504b07e471','f3085e5cdf80879bee2e65d06df4e88698afa3e4',B]:
    subprocess.run(['git','merge-base','--is-ancestor',h,H],check=True)
old='docs/evidence/workforce-c12-terminal-973-2026-10-06'
names=git('ls-tree','-r','--name-only','c123556e7a758b7eb5264137dcaf85504b07e471','--',old).splitlines();assert len(names)==28
assert git('ls-tree','-r','--name-only',H,'--',old).splitlines()==names
for f in names:assert subprocess.check_output(['git','show',H+':'+f])==subprocess.check_output(['git','show','c123556e7a758b7eb5264137dcaf85504b07e471:'+f])
for f in ['AGENTS.md','clients/registry.json','docs/DEPLOYMENT.md','test-baseline.json','typecheck-baseline.json']:
    assert subprocess.check_output(['git','show',H+':'+f])==subprocess.check_output(['git','show',B+':'+f])
docs=git('show',B+':docs/DEPLOYMENT.md');registry=git('show',B+':clients/registry.json')
assert '13.140.132.245'in docs and '/opt/leaddrive-v2'in docs and 'deploy.yml'in docs
assert '13.140.132.245'in registry and '/opt/leaddrive-v2'in registry and 'app.leaddrivecrm.org'in registry
proofs=[Path('/tmp/hrm-employee-correction-recovery-2e4b-current-four-final-root/root-current-four-browser-content-review.json'),Path('/tmp/hrm-employee-correction-recovery-2e4b-current-five-final-v2-root/root-required-five-original-content-review.json'),Path('/tmp/hrm-employee-correction-recovery-2e4b-current-ready-checks-final-root/root-ready-typecheck-content-review.json'),Path('/tmp/hrm-employee-correction-recovery-2e4b-source-peer/ready-candidate/exact-684-current-c18-four-browser-peer-review.json'),Path('/tmp/hrm-employee-correction-recovery-2e4b-source-peer/ready-candidate/current-required-five/peer-required-five-current-candidate-content-review.json')]
assert all(x.exists()for x in proofs)
r={'status':'FRESH_HEAD_MATCHED_ORDINARY_684_MERGE_ALLOWED_AFTER_EXACT_SOURCE_CANDIDATE_FIVE_ROOT_PEER_ADMISSION','H':H,'B':B,'C':C,'tree':src['tree']['sha'],'actualNewestFive':latest,'proofs':[{'path':str(x),'sha256':hashlib.sha256(x.read_bytes()).hexdigest()}for x in proofs],'strictActual':False,'old28ArchiveByteequal':True,'excludedNeverMerged':True,'sourceCleanAndFrozen':True,'production':'13.140.132.245:/opt/leaddrive-v2','route':'ordinary reviewed main -> deploy.yml -> immutable SHA artifact -> public smoke','atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(p/'fresh-final-premerge-guard.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k]for k in ['status','H','B','C','tree','atUtc']}))
