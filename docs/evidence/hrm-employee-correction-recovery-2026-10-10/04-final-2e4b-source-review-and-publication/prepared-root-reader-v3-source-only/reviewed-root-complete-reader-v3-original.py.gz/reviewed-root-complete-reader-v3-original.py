from pathlib import Path
import sys,json,subprocess,hashlib,re,datetime,gzip
p=Path(sys.argv[1]);H=sys.argv[2];C=sys.argv[3]if len(sys.argv)>3 else H;B=sys.argv[4]if len(sys.argv)>4 else None
assert re.fullmatch('[a-f0-9]{40}',H)and re.fullmatch('[a-f0-9]{40}',C)
s=json.loads((p/'correction-recovery-terminal-job-root-summary.json').read_text());r=s['receipt']
assert s['headSha']==H and s['jobConclusion']=='success' and r['sourceHead']==H and r['checkedMergeSha']==C
assert r['status']==r['cleanup']=='PASS' and r['version']==1 and not r.get('failure')
assert subprocess.check_output(['git','rev-parse',H+'^{tree}'])==subprocess.check_output(['git','rev-parse',C+'^{tree}'])
if C != H:
 assert B and re.fullmatch('[a-f0-9]{40}',B)
 assert subprocess.check_output(['git','rev-list','--parents','-n','1',C],text=True).split()[1:]==[B,H]
log=gzip.decompress((p/'whole-correction-recovery-job-original.txt.gz').read_bytes()).decode();ls=log.splitlines();bind=[]
for i,l in enumerate(ls):
 if 'git log -1 --format=%H'in l:bind+=ls[i:i+2]
assert re.findall('[a-f0-9]{40}','\n'.join(bind))[-1]==C
job=json.loads(gzip.decompress((p/'job-api-original.json.gz').read_bytes()));run=json.loads(gzip.decompress((p/'run-api-original.json.gz').read_bytes()))
assert run['head_sha']==job['head_sha']==H and job['run_id']==s['runId'] and run['path']=='.github/workflows/workforce-exception-report-browser-evidence.yml'
assert job['name']=='Authenticated employee correction reply-loss recovery browser evidence'
expected_skips=['Preserve non-secret workflow failure receipt']
if C == H:
 assert run['event']=='workflow_dispatch'
else:
 assert run['event']=='pull_request'
 expected_skips.insert(0,'Verify exact authorized source dispatch')
assert [x['name']for x in job['steps']if x['conclusion']=='skipped']==expected_skips
assert all(x['status']=='completed'and(x['conclusion']=='success'or(x['name']in expected_skips and x['conclusion']=='skipped'))for x in job['steps'])
workflow=subprocess.check_output(['git','show',H+':.github/workflows/workforce-exception-report-browser-evidence.yml'],text=True).split('  employee-correction-recovery-browser:')[1]
assert '- name: Preserve non-secret workflow failure receipt\n        if: failure()'in workflow

assert sorted(s['artifact']['members'])==['employee-correction-recovery-receipt.json','workflow-context.json']
harness=subprocess.check_output(['git','show',H+':scripts/workforce-employee-correction-recovery-browser-evidence.mjs'],text=True)
expected_sources=json.loads(re.search(r'const sourcePaths = (\[[^\n]+\])',harness)[1])
assert sorted(expected_sources)==sorted(x['path']for x in r['sources'])and len(expected_sources)==33
sources=r['sources'];assert len(sources)==33 and len({x['path']for x in sources})==33
for x in sources:
 b=subprocess.check_output(['git','show',H+':'+x['path']]);assert x['bytes']==len(b)and x['sha256']==hashlib.sha256(b).hexdigest()
cells={(l,w)for l in['az','ru','en']for w in[320,768,1440]};cases=r['cases'];assert len(cases)==11
matrix=[x for x in cases if 'locale'in x];assert len(matrix)==9 and{(x['locale'],x['width'])for x in matrix}==cells
expected={'committedResponseDeliberatelyLost':True,'actualClientRequestFailed':True,'actualErrorToast':True,'draftPreserved':True,'actualUiRetryStatus':200,'sameUiPayloadAndClientKey':True,'sameUiRequestId':True,'committedRequestAndAuditUnchangedOnUiRetry':True,'actualPostStatus':201,'actualReplayStatus':200,'pending':True,'ownWorkday':True,'actualUiHistory':True,'duplicateRows':0}
for case in matrix:
 assert case['status']=='PASS'
 for name in['linked','unlinked']:
  a=case[name];assert all(a[k]==v for k,v in expected.items());assert a['sourceLinked']==(name=='linked');assert a['immutableRevision']==(0 if name=='linked'else None)
a=next(x for x in cases if x['name']=='second-populated-tenant');assert a['status']=='PASS'and all(a['linked'][k]==v for k,v in expected.items())and a['linked']['sourceLinked']is True and a['linked']['immutableRevision']==0
b=next(x for x in cases if x['name']=='foreign-missing-and-different-day-cases-indistinguishable');assert b['status']=='PASS'and b['actual409']==3 and b['requestsAndAuditUnchanged']is True
for i,a in enumerate(r['authenticationDiagnostics'],1):
 assert a['ordinal']==i and a['csrfStatus']==a['callbackStatus']==a['verificationStatus']==a['sessionUpdateStatus']==200 and a['verificationWarmupStatus']==405 and a['mandatoryTotp']is True and a['nonceConsumed']is True
 assert isinstance(a['pacingWaitMs'],int)and 0<=a['pacingWaitMs']<=600000
assert len(r['authenticationDiagnostics'])==10
states={'IMMUTABLE_CASE_LINK':'55000','IMMUTABLE_CASE_REVISION':'55000','EXACT_LINKED_WORKDAY':'23514','SYNTHETIC_AUDIT_IMMUTABLE':'55000','EXACT_CASE_IMMUTABLE':'55000'}
assert len(r['databaseDiagnostics'])==5 and{x['kind']for x in r['databaseDiagnostics']}==set(states)
for x in r['databaseDiagnostics']:assert x['expectedSqlState']==x['actualSqlState']==states[x['kind']]and x['rolledBack']is True and x['persistedRequestAndAuditFingerprintsUnchanged']is True
b=r['database'];assert b['actualRequests']==b['actualAudits']==19 and b['linkedRequests']==10 and b['unlinkedAfterTypeDayChange']==9
for k in['nonownerForcedRls','twoPopulatedTenants','unchanged']:assert b[k]is True
for k in['unscopedRows','foreignRows','automaticPersonnelDecisions','corrections','employeeResponses']:assert b[k]==0
assert b['defaultAclReviewed']is False and b['fullHistoricalReplay']is False
c=b['actualRoleCatalog'];assert c['forced']==5 and c['owned']==c['memberships']==0 and c['request_insert']is True and c['audit_insert']is True
for k in['request_mutation','audit_mutation','workday_write','decision_write','response_write','correction_write']:assert c[k]is False
facts=b['knownFactControls'];assert len(facts)==11 and len({x['table']for x in facts})==11
for x in facts:assert isinstance(x['rows'],int)and x['rows']>=0 and re.fullmatch('[a-f0-9]{64}',x['sha256'])
assert {x['table']:x['rows']for x in facts}=={'organizations':2,'mtm_agents':2,'mtm_agent_workdays':19,'workforce_exception_cases':19,'workforce_exception_decisions':0,'workforce_employee_team_memberships':0,'workforce_access_grants':0,'workforce_shift_templates':0,'workforce_shift_segments':0,'workforce_time_corrections':0,'workforce_exception_employee_responses':0}
phases=[]
for locale in ['az','ru','en']:
 for width in [320,768,1440]:
  phases += [(f'{locale}-{width}-actual-linked-request-reply-loss-and-ui-retry',True),(f'{locale}-{width}-actual-cleared-source-reply-loss-and-ui-retry',False)]
phases += [('second-positive-tenant',True)]
assert len(r['recoveryDiagnostics'])==19
assert sum(x['linked']is True for x in r['recoveryDiagnostics'])==10 and sum(x['linked']is False for x in r['recoveryDiagnostics'])==9
for i,(x,(phase,linked)) in enumerate(zip(r['recoveryDiagnostics'],phases),1):
 assert x['phase']==phase and x['linked']is linked
 assert x['ordinal']==i and x['requestsBefore']==x['auditsBefore']==i-1
 assert x['realServerStatus']==201 and x['actualUiRetryStatus']==200 and x['handlerFailureClass']is None and x['handlerFailureCode']is None
 assert isinstance(x['phase'],str)and len(x['phase'])<=100 and 'PRIVATE'not in x['phase']
 for field in ['routeAbortCompleted','browserRequestFailed','errorToastObserved','retainedDraftVerified','sameUiBodyAndClientKey','sameUiRequestId','committedRowsUnchanged']:assert x[field]is True
assert len(r['productionRoutines'])==11
for x in r['productionRoutines']:
 text=subprocess.check_output(['git','show',H+':'+x['path']],text=True)
 if x['kind']=='EXACT_STATEMENT':
  matches=[]
  for i in range(len(text)):
   if text.startswith(('CREATE OR REPLACE FUNCTION','CREATE TRIGGER','ALTER TABLE'),i):
    if text.startswith('CREATE OR REPLACE FUNCTION',i):end=text.index('\n$$;',i)+4
    else:end=text.index(';',i)+1
    bb=text[i:end].encode()
    if len(bb)==x['bytes']and hashlib.sha256(bb).hexdigest()==x['sha256']:matches.append(i)
  assert len(matches)==1,(x['path'],x)
 else:
  assert x['kind']=='EXACT_CHECK_FRAGMENT_RECONSTRUCTED_ALTER';start=text.index('ADD CONSTRAINT "'+x['name']+'"');end=text.index(' NOT VALID',start)+len(' NOT VALID');fragment=text[start+4:end]
  assert hashlib.sha256(fragment.encode()).hexdigest()==x['fragmentSha256'];assert hashlib.sha256(('ALTER TABLE public."mtm_hrm_requests" ADD '+fragment+';').encode()).hexdigest()==x['executedSha256']
assert len(r['cleanupDiagnostics'])==13 and len({x['resource']for x in r['cleanupDiagnostics']})==13 and all(x['status']=='PASS'for x in r['cleanupDiagnostics'])
assert len(r['limitations'])==8 and not any(x.endswith('.png')for x in s['artifact']['members'])
assert all(x not in json.dumps(r)for x in['PRIVATE_CORRECTION_RECOVERY_','Fixture!9a-','@example.test','Synthetic correction agent'])
out={'status':'ACTUAL_COMPLETE_SEPARATE_CORRECTION_REPLY_LOSS_RECOVERY_ACCEPTED','sourceHead':H,'checkedCandidate':C,'base':B,'sourceDispatchVerificationSkippedOnPrReceivesNoCredit':C!=H,'failureOnlyReceiptSkippedOnSuccessfulJobReceivesNoCredit':True,'firstCompleteReaderErrorRetained':True,'runId':s['runId'],'jobId':s['jobId'],'actualCases':11,'actualMfaContexts':10,'actualBindings':33,'actualViewports':9,'actualPendingRequestsAndAudits':19,'linked':10,'clearedSource':9,'controlledTransportRecoveryFlows':19,'firstReal201ThenAbortRequestfailedDraftUiRetry200':True,'recoveryDiagnostics':19,'sqlRollbackChecks':5,'forcedRlsTables':5,'factTablesUnchanged':11,'fullHistoricalReplay':False,'defaultAclReviewed':False,'production':False,'nativeFormDeviceHuman':False,'scope':'New independent disposable hosted runtime only; source bindings plus actual PASS assertions. Original seven gates, current-candidate/five and normal release remain separately required.','observedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
f=p/'root-complete-correction-recovery-content-review.json';assert not f.exists();f.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
