from pathlib import Path
import json,gzip,re,hashlib,subprocess,datetime,sys
p=Path(sys.argv[1]);h=sys.argv[2];b=sys.argv[3];s=json.loads((p/'finite-capture-summary.json').read_text());assert len(s['jobs'])==int(sys.argv[4]) and s['conclusion']=='success'and s['headSha']==h and s['event']=='workflow_dispatch'
assert len(s['artifacts'])==int(sys.argv[4])-2
alljobs=[];logs={}
for j in s['jobs']:
 raw=gzip.decompress((p/f"job-{j['id']}-original.txt.gz").read_bytes());assert hashlib.sha256(raw).hexdigest()==j['logSha256'];t=re.sub(r'\x1b\[[0-9;]*m','',raw.decode());lines=t.splitlines();bind=[]
 for i,l in enumerate(lines):
  if 'git log -1 --format=%H'in l:bind+=lines[i:i+2]
 assert re.findall('[a-f0-9]{40}','\n'.join(bind))[-1]==h
 skips=[x['name']for x in j['steps']if x['conclusion']=='skipped'];browser='browser'in j['name'].lower();assert skips==(['Preserve non-secret workflow failure receipt']if browser else [])
 assert j['conclusion']=='success'and all(x['conclusion']=='success'or x['name']in skips for x in j['steps'])
 alljobs.append({'job':j['id'],'name':j['name'],'checkout':h,'actualSuccess':True,'failureOnlyReceiptSkipsNoCredit':skips});logs[j['id']]=t
pg=logs[next(j['id']for j in s['jobs']if j['name']=='Exact WF-C6-010 source and PostgreSQL regressions')];assert re.search(r'Test Files\s+4 passed \(4\)',pg)and re.search(r'Tests\s+44 passed \(44\)',pg)and re.search(r'Tests\s+37 passed \(37\)',pg)
assert 'check-test-baseline: 18 failing file(s), 18 in baseline.'in pg and 'No new failures, and every baseline entry still fails. Gate passed.'in pg
build=logs[next(j['id']for j in s['jobs']if j['name']=='Exact WF-C6-010 isolated production bundle build')];match=next((m for m in re.finditer(r'Generating static pages(?: using [0-9]+ workers?)? \((\d+)/(\d+)\)',build)if m[1]==m[2]),None);assert match and match[1]==match[2];routes=re.findall(r'\s[┌├└]\s+[○ƒ]\s+(\S+)',build);assert len(routes)==len(set(routes))and '/'in routes
for f in ['test-baseline.json','typecheck-baseline.json']:
 assert subprocess.check_output(['git','show',h+':'+f])==subprocess.check_output(['git','show',b+':'+f])==subprocess.check_output(['git','show','973241bacc296b71fe817d1af11187c32e8126af:'+f])
result={'status':'ACTUAL_EXACT_SOURCE_ALL_LANES_ROOT_LOG_CONTENT_ACCEPTED_ARTIFACT_CONTENT_AND_PIXELS_SEPARATE','head':h,'base':b,'run':s['runId'],'jobs':alljobs,'pgAcrossFourFiles':44,'nativeAdmission':37,'strictRegressionFamilies':18,'globalSuiteClean':False,'actualBuildStaticPages':int(match[1]),'actualBuildUniqueRoutes':len(routes),'rootRoutePresent':True,'actualBoundedArtifacts':len(s['artifacts']),'allArtifactDigestSizeCrcValidated':True,'baselinesByteequal973AndCurrentBase':True,'checkedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
f=p/'root-all-lanes-checkout-pg-build-content-review.json';assert not f.exists();f.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='jobs'}))
