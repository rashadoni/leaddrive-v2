import subprocess,pathlib,json,hashlib,re,datetime,os,shutil
W=pathlib.Path('/mnt/HC_Volume_106454338/codex-alt-data/worktrees/leaddrive-hrm-employee-correction-recovery-20261010')
O=pathlib.Path('/tmp/hrm-employee-correction-recovery-be143-source-peer');O.mkdir(exist_ok=True)
H='be14317e82057d85a6675abd92c8c33470f4e593';F='fe948e5f480b0ae06c5448f173463e1ce7523677';M='bfe456042a018864fead8be64d5f154911195af0';I='48e5a47f905589c4257cd8c3430d4bf7e5c8ad70'
def git(*a):return subprocess.check_output(['git',*a],cwd=W)
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,b):(O/n).write_bytes(b)
status=git('status','--porcelain=v1');save('whole-source-status-original.txt',status);assert not status
assert git('rev-parse','HEAD').decode().strip()==H
assert git('branch','--show-current').decode().strip()=='codex/hrm-employee-correction-recovery-20261010'
assert git('remote','get-url','origin').decode().strip()=='https://github.com/rashadoni/leaddrive-v2.git'
assert git('show','-s','--format=%P',H).decode().strip()==I
assert git('show','-s','--format=%P',I).decode().split()==[F,M]
for name,c in [('exact-head',H),('exact-integration',I),('accepted-source-predecessor',F),('actual-current-own-main',M)]:save(name+'-commit-original.txt',git('show','--no-patch','--format=raw',c))
owned=git('diff','--name-only',M,H).decode().splitlines();expected=['.github/workflows/workforce-exception-report-browser-evidence.yml','docs/hrm-employee-correction-recovery-session-log-2026-10-10.md','scripts/workforce-employee-correction-recovery-browser-admission.mjs','scripts/workforce-employee-correction-recovery-browser-admission.test.mjs','scripts/workforce-employee-correction-recovery-browser-evidence.mjs'];assert owned==expected
save('whole-owned-diff-vs-current-main-original.patch',git('diff','--binary',M,H));save('whole-delta-vs-accepted-fe948-original.patch',git('diff','--binary',F,H));save('whole-main-owned-name-list-original.txt',git('diff','--name-only',M,H))
journal=expected[1];assert git('diff','--name-only',F,H).decode().splitlines()==[journal]
oldjournal=git('show',F+':'+journal);newjournal=git('show',H+':'+journal);assert newjournal.startswith(oldjournal)
for path in expected:
 b=git('show',H+':'+path);p=O/'owned-source-originals'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 if path!=journal:assert b==git('show',F+':'+path)
workflow=git('show',H+':'+expected[0]);old=git('show',M+':'+expected[0]);filterline=b'      - "scripts/workforce-employee-correction-recovery-browser-*.mjs"\n';assert workflow.count(filterline)==1
marker=b'\n  employee-correction-recovery-browser:\n';assert workflow.count(marker)==1
prefix=workflow.split(marker)[0].replace(filterline,b'');assert prefix==old
save('reconstructed-whole-protected-seven-workflow-original.yml',prefix)
harness=git('show',H+':'+expected[-1]).decode();sourcepaths=json.loads(re.search(r'const sourcePaths = (\[.*?\])\n',harness).group(1));assert len(sourcepaths)==len(set(sourcepaths))==33
bindings=[];protected=[]
for path in sourcepaths:
 b=git('show',H+':'+path);bindings.append({'path':path,'bytes':len(b),'sha256':sha(b)})
 if path not in expected:
  assert b==git('show',M+':'+path);protected.append(path)
assert len(protected)==29
appended=newjournal[len(oldjournal):].decode()
for needle in ['still running','this entry does not claim its production release is verified','Future publication','planned until hosted execution','unproved cause','one successful same-head','Accounting85DONE/76open/61%'] : assert needle in appended,needle
save('append-only-journal-delta-original.md',newjournal[len(oldjournal):])
resources={'MemAvailableLine':next(x for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')),'diskFreeBytes':shutil.disk_usage(W).free,'memoryPressure':pathlib.Path('/proc/pressure/memory').read_text()}
save('small-readonly-check-resource-original.json',(json.dumps(resources,indent=2)+'\n').encode())
p=subprocess.run(['git','diff','--check',M,H],cwd=W,capture_output=True);save('actual-current-main-diff-check-original.txt',p.stdout+p.stderr);assert p.returncode==0
for prev in ['/tmp/hrm-employee-correction-recovery-fe948-source-peer/exact-fe948-recovery-source-peer-review.json','/tmp/hrm-employee-correction-recovery-280d-source-peer/exact-280d-recovery-source-peer-review.json']:
 b=pathlib.Path(prev).read_bytes();save('preserved-'+pathlib.Path(prev).name,b)
receipt={'status':'ACCEPTED_EXACT_INTEGRATED_SOURCE_ONLY_RUNTIME_NOT_RUN','head':H,'baseCurrentOwnMain':M,'directParent':I,'integrationParents':[F,M],'wholeTree':git('rev-parse',H+'^{tree}').decode().strip(),'reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ownedPaths':owned,'codeAndWorkflowByteEqualAcceptedFe948':True,'onlyDeltaFromFe948':'Append-only 27-line journal with ordinary current-main ancestry integration','wholeTreeOutsideFiveOwnedPathsBytePreserved':True,'oldSevenWholeWorkflowBytePreserved':True,'sourceBindingsPlanned':bindings,'protectedBindingsEqualActualCurrentMain':protected,'journalAppendOnly':True,'journalOwnParentReleasePendingAndPublicationGateExplicit':True,'actualCheapCheck':{'name':'git diff --check actual current main..BE','exit':p.returncode},'unchangedChecksNotRerun':'28 pure tests, three Node syntax and runner54 already run on byte-identical code; integration delta reviewed without repeating unchanged tests','currentOwnParentRelease':'M_BFE normal deploy and own full main compiler still running; no release transfer','runtimeNotRun':['recovery SQL/browser/new eighth job/full source8/current successor candidate/required five/own successor normal release'],'qualifications':['19 controlled real server201/intentional reply abort/error/draft retention/UI200 same complete body-key/id stable hashes remain planned','No real outage, concurrent replay, native request form pixels, private body screenshots, physical devices, human AT, authenticated production HR, defaultACL/full historical migrations/operational acceptance'],'issues':[]}
rp=O/'exact-be143-integrated-recovery-source-peer-review.json';rp.write_text(json.dumps(receipt,indent=2)+'\n')
copy=O/'used-source-reader-original.py';copy.write_bytes(pathlib.Path(__file__).read_bytes())
inv=[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(O.rglob('*')) if p.is_file()]
ip=O/'all-integrated-source-originals-review-inventory.json';ip.write_text(json.dumps(inv,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'head':H,'review':str(rp),'reviewSha256':sha(rp.read_bytes()),'inventory':str(ip),'inventorySha256':sha(ip.read_bytes()),'files':len(inv),'protectedBindingCount':len(protected),'sourceBindingsPlanned':len(bindings)}))
