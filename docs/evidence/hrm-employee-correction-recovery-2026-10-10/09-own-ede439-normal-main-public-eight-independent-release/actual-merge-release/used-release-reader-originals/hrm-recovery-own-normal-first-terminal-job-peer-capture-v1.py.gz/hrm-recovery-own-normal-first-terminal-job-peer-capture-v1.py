from pathlib import Path
import subprocess,json,gzip,re,hashlib,datetime,sys
rid,jid,M,label,out=sys.argv[1:];assert re.fullmatch('[a-f0-9]{40}',M);p=Path(out);assert not p.exists();p.mkdir(parents=True)
def api(ep,name):
 raw=subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/'+ep]);(p/(name+'-whole-original-api.json.gz')).write_bytes(gzip.compress(raw,mtime=0));return json.loads(raw)
r=api('actions/runs/'+rid,'run');j=api('actions/jobs/'+jid,'job');c=api('check-runs/'+jid,'check')
assert r['head_sha']==j['head_sha']==c['head_sha']==M and r['id']==j['run_id']==int(rid) and j['id']==c['id']==int(jid) and c['app']['id']==15368 and r['head_branch']=='main' and r['event']=='push' and r['path']=='.github/workflows/deploy.yml' and r['run_attempt']==1
assert j['status']==c['status']=='completed' and j['conclusion']==c['conclusion'] and j['conclusion']in['success','failure']
raw=subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/actions/jobs/'+jid+'/logs']);(p/(label+'-whole-original-log.txt.gz')).write_bytes(gzip.compress(raw,mtime=0));text=re.sub(r'\x1b\[[0-9;]*m','',raw.decode());lines=[x.split('Z ',1)[-1]for x in text.splitlines()];checkout=[lines[i+1]for i,x in enumerate(lines)if'git log -1 --format=%H'in x];assert checkout==[M]
result={'status':'ACTUAL_CURRENT_OWN_MAIN_FIRST_TERMINAL_ORIGINALS_CAPTURED_CONTENT_SEPARATE','atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main':M,'run':int(rid),'job':int(jid),'actualName':j['name'],'actualConclusion':j['conclusion'],'actualApp':15368,'actualCheckout':M,'logBytes':len(raw),'logSha256':hashlib.sha256(raw).hexdigest(),'wholeFirstTerminalLogPreserved':True,'failedSteps':[x['name']for x in j['steps']if x['conclusion']=='failure'],'skippedSteps':[x['name']for x in j['steps']if x['conclusion']=='skipped'],'fullReleaseCredit':False};f=p/'first-terminal-own-job-original-capture.json';f.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
