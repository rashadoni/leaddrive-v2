from pathlib import Path
import subprocess,sys,json,gzip,datetime,time,hashlib
M,N,K,output=sys.argv[1:];runs={int(N):'.github/workflows/deploy.yml',int(K):'.github/workflows/pr-checks.yml'}
p=Path(output);assert not p.exists();p.mkdir();seen={};logs=set();done=set()
def capture(path,label):
    b=subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/'+path]);(p/(label+'.json.gz')).write_bytes(gzip.compress(b,mtime=0));return json.loads(b)
for tick in range(84):
    for rid,path in runs.items():
        if rid in done:continue
        r=capture(f'actions/runs/{rid}',f'tick-{tick:02d}-run-{rid}');j=capture(f'actions/runs/{rid}/jobs?per_page=100',f'tick-{tick:02d}-jobs-{rid}')
        assert r['head_sha']==M and r['head_branch']=='main' and r['event']=='push' and r['run_attempt']==1 and r['path']==path
        assert len(j['jobs'])==j['total_count']
        for x in j['jobs']:
            state=(x['status'],x['conclusion'])
            if seen.get(x['id'])!=state:
                print(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run':rid,'job':x['id'],'name':x['name'],'status':state[0],'conclusion':state[1]}),flush=True);seen[x['id']]=state
            if x['status']=='completed' and x['conclusion']!='skipped' and x['id']not in logs:
                a=subprocess.run(['gh','api',f"repos/rashadoni/leaddrive-v2/actions/jobs/{x['id']}/logs"],capture_output=True)
                if a.returncode:
                    (p/f"tick-{tick:02d}-job-{x['id']}-first-log-read-error-original.txt").write_bytes(a.stderr);continue
                (p/f"first-terminal-job-{x['id']}-whole-original.txt.gz").write_bytes(gzip.compress(a.stdout,mtime=0));logs.add(x['id']);print(json.dumps({'firstTerminalWholeOriginalPreserved':x['id'],'bytes':len(a.stdout),'sha256':hashlib.sha256(a.stdout).hexdigest(),'conclusion':x['conclusion']}),flush=True)
        if r['status']=='completed' and all(x['conclusion']=='skipped'or x['id']in logs for x in j['jobs']):
            done.add(rid);print(json.dumps({'wholeRunTerminal':rid,'conclusion':r['conclusion'],'attempt':1}),flush=True)
    if done==set(runs):break
    time.sleep(25)
else:raise RuntimeError('BOUNDED_OBSERVER_EXPIRED_NO_RUN_STATUS_ASSUMED')
