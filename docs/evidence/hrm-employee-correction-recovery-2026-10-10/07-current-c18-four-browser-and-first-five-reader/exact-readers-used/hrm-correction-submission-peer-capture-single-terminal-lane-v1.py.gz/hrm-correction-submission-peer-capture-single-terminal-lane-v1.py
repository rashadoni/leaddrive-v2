from pathlib import Path
import sys,json,gzip,hashlib,subprocess,zipfile,datetime
runid=int(sys.argv[1]);jobid=int(sys.argv[2]);head=sys.argv[3];prefix=sys.argv[4];out=Path(sys.argv[5]);assert not out.exists();out.mkdir(parents=True)
def raw(endpoint):return subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/'+endpoint])
def api(endpoint,name):
 b=raw(endpoint);(out/(name+'-api-original.json.gz')).write_bytes(gzip.compress(b,mtime=0));return json.loads(b)
r=api(f'actions/runs/{runid}','run');j=api(f'actions/jobs/{jobid}','job');aa=api(f'actions/runs/{runid}/artifacts?per_page=100','artifacts');assert aa['total_count']==len(aa['artifacts'])
assert r['head_sha']==j['head_sha']==head and j['run_id']==runid and j['status']=='completed'
log=raw(f'actions/jobs/{jobid}/logs');(out/f'job-{jobid}-original.txt.gz').write_bytes(gzip.compress(log,mtime=0))
a=next(x for x in aa['artifacts'] if x['name'].startswith(prefix));assert not a['expired'] and a['workflow_run']['id']==runid and a['workflow_run']['head_sha']==head and a['size_in_bytes']<200000000
p=out/f"artifact-{a['id']}-original.zip"
with p.open('xb')as f:subprocess.run(['gh','api',f"repos/rashadoni/leaddrive-v2/actions/artifacts/{a['id']}/zip"],stdout=f,check=True)
digest=hashlib.file_digest(p.open('rb'),'sha256').hexdigest();assert a['digest']=='sha256:'+digest and p.stat().st_size==a['size_in_bytes']
with zipfile.ZipFile(p)as z:
 assert z.testzip()is None;members=z.namelist();assert len(members)==len(set(members)) and all(not x.startswith('/')and'..'not in Path(x).parts for x in members)
s={'runId':runid,'runAttempt':r['run_attempt'],'headSha':head,'event':r['event'],'workflow':r['path'],'conclusion':'PARTIAL_TERMINAL_LANE_ONLY','jobs':[{'id':jobid,'name':j['name'],'conclusion':j['conclusion'],'steps':[{'name':x['name'],'conclusion':x['conclusion']}for x in j['steps']],'logBytes':len(log),'logSha256':hashlib.sha256(log).hexdigest()}],'artifacts':[{'id':a['id'],'name':a['name'],'bytes':p.stat().st_size,'sha256':digest,'apiDigestMatched':True,'allCRCValidated':True,'members':members}],'observedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Single actual terminal lane only; no entire-run credit.'}
(out/'finite-capture-summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({'out':str(out),'job':jobid,'conclusion':j['conclusion'],'artifact':a['id'],'size':p.stat().st_size}))
