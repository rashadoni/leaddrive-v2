from pathlib import Path
import json,gzip,hashlib,subprocess,re,datetime,sys
H,B,C,number,out=sys.argv[1:]
assert all(re.fullmatch('[a-f0-9]{40}',s) for s in [H,B,C])
p=Path(out);assert not p.exists();p.mkdir(parents=True)
def api(endpoint,label):
 raw=subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/'+endpoint]);(p/(label+'-whole-api-original.json.gz')).write_bytes(gzip.compress(raw,mtime=0));return json.loads(raw)
def digest(b):return hashlib.sha256(b).hexdigest()
pr=api('pulls/'+number,'pr');assert pr['state']=='open' and not pr['draft'] and not pr['merged'] and pr['head']['sha']==H and pr['base']['sha']==B and pr['merge_commit_sha']==C
main=api('git/ref/heads/main','main');assert main['object']['sha']==B
source=api('git/commits/'+H,'source');candidate=api('git/commits/'+C,'candidate');tree=source['tree']['sha'];assert candidate['tree']['sha']==tree and [x['sha'] for x in candidate['parents']]==[B,H]
assert subprocess.check_output(['git','rev-parse',H+'^{tree}'],text=True).strip()==tree
protection=api('branches/main/protection','protection');req=protection['required_status_checks'];contexts=['pr-scope','static-checks','typecheck','runner-policy','scan'];assert set(req['contexts'])==set(contexts) and req['strict'] is False and len(req['checks'])==5 and {x['context']:x['app_id'] for x in req['checks']}==dict.fromkeys(contexts,15368)
checks=[];page=1
while True:
 j=api('commits/'+H+'/check-runs?filter=all&per_page=100&page='+str(page),'checks-page-'+str(page));checks.extend(j['check_runs'])
 if len(j['check_runs'])<100:break
 page+=1;assert page<=10
assert len(checks)==j['total_count']
results=[];type_review=None;static_review=None
for name in contexts:
 matches=[x for x in checks if x['name']==name];assert matches
 selected=max(matches,key=lambda x:(x['started_at'] or '',x['id']))
 assert selected['app']['id']==15368 and selected['head_sha']==H and selected['status']=='completed' and selected['conclusion']=='success',(name,selected)
 job=api('actions/jobs/'+str(selected['id']),name+'-job');check=api('check-runs/'+str(selected['id']),name+'-check');run=api('actions/runs/'+str(job['run_id']),name+'-run')
 assert job['id']==check['id']==selected['id'] and job['head_sha']==check['head_sha']==run['head_sha']==H and job['name']==check['name']==name and check['app']['id']==15368
 assert job['status']==check['status']=='completed' and job['conclusion']==check['conclusion']=='success' and all(x['conclusion']=='success' for x in job['steps'])
 assert run['event']=='pull_request' and run['run_attempt']>=1
 raw=subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/actions/jobs/'+str(job['id'])+'/logs']);(p/(name+'-whole-log-original.txt.gz')).write_bytes(gzip.compress(raw,mtime=0))
 text=re.sub(r'\x1b\[[0-9;]*m','',raw.decode());lines=[x.split('Z ',1)[-1] for x in text.splitlines()];checkout=[lines[i+1] for i,x in enumerate(lines) if 'git log -1 --format=%H' in x];assert checkout==[C],(name,checkout,C)
 row={'name':name,'newestSelectedBeforeAppOrStatusFiltering':True,'allSameNameRecords':[{'id':x['id'],'appId':x['app']['id'],'headSha':x['head_sha'],'startedAt':x['started_at'],'status':x['status'],'conclusion':x['conclusion']} for x in matches],'actualId':job['id'],'actualRun':job['run_id'],'actualCheckout':checkout[0],'allStepsSuccess':True,'rawBytes':len(raw),'rawSha256':digest(raw)}
 if name=='typecheck':
  errors=re.findall(r'error (TS\d+):',text);m=re.search(r'check-typecheck-baseline: (\d+) gated pair\(s\) now, (\d+) in baseline \((\d+) errors total\)',text);assert m and m.group(1)==m.group(2) and int(m.group(3))==len(errors) and len(errors)>0
  assert 'Typecheck completed (exit 2). No syntax, missing-module or undefined-name errors.' in text and 'No new defect-shaped type errors, and the baseline still matches. Gate passed.' in text
  owned=subprocess.check_output(['git','diff','--name-only',B,H],text=True).splitlines();ownederrors=[x for x in lines if 'error TS' in x and any(x.startswith(path+'(') for path in owned)];assert not ownederrors
  type_review={'actualDiagnostics':len(errors),'actualFamilies':len(set(errors)),'actualCompilerExit':2,'strictPairs':int(m.group(1)),'criticalDiagnosticCount':0,'ownedDiagnosticCount':0,'globalStatus':'NONCLEAN','fullLogBytes':len(raw),'fullLogSha256':digest(raw),'rawStandaloneCompilerArtifact':'NOT PROVIDED by unchanged READY workflow; entire original typecheck job log retained, no synthetic raw file claimed'}
 if name=='static-checks':
  m=re.search(r'check-test-baseline: (\d+) failing file\(s\), (\d+) in baseline\.',text);assert m and m.group(1)==m.group(2) and 'No new failures, and every baseline entry still fails. Gate passed.' in text;static_review={'actualStrictFailingFiles':int(m.group(1)),'baselineEntries':int(m.group(2)),'allOldStillFailNoNew':True,'globalStatus':'NONCLEAN'}
 results.append(row)
assert len(results)==5 and type_review and static_review
result={'status':'ACTUAL_READY_NEWEST_REQUIRED_FIVE_AND_COMPLETE_TYPECHECK_INDEPENDENTLY_ACCEPTED','reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pr':int(number),'source':H,'base':B,'candidate':C,'wholeTree':tree,'requiredProtection':req,'actualRequiredFive':results,'actualTypecheck':type_review,'actualStaticStrictSuite':static_review,'scope':'Current exact source checks, actual candidate checkout and parents/tree. All same-name records retained, newest selected without app/success filtering. Read-only evidence capture; no rerun/publication or production mutation.'}
f=p/'peer-required-five-current-candidate-content-review.json';f.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'review':str(f),'sha256':digest(f.read_bytes()),'five':results,'typecheck':type_review,'strictSuite':static_review}))
