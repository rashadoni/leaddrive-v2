from pathlib import Path
import sys,json,zipfile,hashlib,subprocess,struct,math
out=Path(sys.argv[1]);head=sys.argv[2];assert not (out/'root-complete-report-content-review.json').exists()
summary=json.loads((out/'finite-capture-summary.json').read_bytes());assert summary['headSha']==head
reportart=next(a for a in summary['artifacts']if a['name'].startswith('workforce-exception-report-browser-'))
zpath=out/f"artifact-{reportart['id']}-original.zip"
with zipfile.ZipFile(zpath)as z:
 d=json.loads(z.read('exception-report-receipt.json'));assert d['candidateHead']==head and d['status']=='PASS' and d['cleanup']=='PASS'
 actual=d['checkedMergeSha'];c=json.loads(subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/commits/'+actual]));(out/'actual-report-commit-api.json').write_text(json.dumps(c,indent=2)+'\n')
 assert c['commit']['tree']['sha']==subprocess.check_output(['git','rev-parse',head+'^{tree}'],text=True).strip()
 if actual!=head:assert c['parents'][-1]['sha']==head and len(c['parents'])==2
 assert len(d['sources'])==15
 for row in d['sources']:
  b=subprocess.check_output(['git','show',head+':'+row['path']]);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
 expected=set()
 for locale in ['az','ru','en']:
  for width in [320,768,1440]:expected.add(f'standard-100-{locale}-{width}-nonempty')
  expected.add(f'native-200-{locale}-320-nonempty')
  for kind in ['standard-100','native-200']:
   for state in ['empty','unresolved-no-sample','measured-zero']:expected.add(f'{kind}-{locale}-320-{state}')
 cases=d['cases'];assert len(cases)==33 and all(x['status']=='PASS'for x in cases)
 matrix=[x for x in cases if x['name'].startswith(('standard-100-','native-200-'))];assert len(matrix)==30 and {x['name']for x in matrix}==expected
 assert {x['name']for x in cases}-expected=={'denied-team','denied-denied','two-tenant-positive-and-session-header-fence'}
 assert all(x['noFalsePercentages']for x in matrix if not x['name'].endswith('nonempty'))
 assert d['nativeZoomVerdict']=='PASS' and len(d['nativeZoomDiagnostics'])==3 and {x['locale']for x in d['nativeZoomDiagnostics']}=={'az','ru','en'}
 assert all(x['status']=='PASS'and x['factor']==2 and x['method']=='BROWSER_TABS_AUTOMATIC_PER_TAB_ZOOM' and x['fixture']=='exception-report'
  and x['event']['oldFactor']==1 and x['event']['newFactor']==2 and x['settings']['mode']=='automatic'and x['settings']['scope']=='per-tab'
  and x['control']['width']==640 and x['control']['devicePixelRatio']==1 and x['zoomed']['width']==320 and x['zoomed']['devicePixelRatio']==2
  and x['viewportEmulation']is False and x['applicationCssChanged']is False and x['applicationServiceWorkers']==0 for x in d['nativeZoomDiagnostics'])
 captures=d['nativeCaptureDiagnostics'];assert len(captures)==21 and len({x['screenshot']for x in captures})==21
 for x in captures:
  assert x['status']==x['cleanup']=='PASS' and x['method']=='CDP_VISIBLE_SURFACE_NO_CLIP' and x['suppliedClip']is False
  assert x['before']==x['after']and x['layoutBefore']==x['layoutAfter'] and x['pixels']==x['controlSurface']
  b=z.read(x['screenshot']);assert len(b)==x['original']['bytes']and hashlib.sha256(b).hexdigest()==x['original']['sha256']
  assert b[:8]==b'\x89PNG\r\n\x1a\n'and b[12:16]==b'IHDR'
  width,height=struct.unpack('>II',b[16:24]);assert(width,height)==(x['pixels']['width'],x['pixels']['height'])and width==640
  assert x['before']['devicePixelRatio']==(1 if x['control']else 2)
 focus=d['keyboardFocusDiagnostics'];assert len(focus)==54
 for x in focus:
  b=x['box'];c=x['clip'];assert x['focused']and x['focusVisible']and b['width']>0 and b['height']>0
  assert all(isinstance(v,(int,float))and math.isfinite(v)for v in list(b.values())+list(c.values()))
  assert b['left']>=c['left']-1 and b['right']<=c['right']+1 and b['top']>=c['top']-1 and b['bottom']<=c['bottom']+1
 assert len(d['textReflowDiagnostics'])==58
 assert d['textReflowDiagnostics'][-1]['locale']=='en' and d['textReflowDiagnostics'][-1]['width']==768 and d['textReflowDiagnostics'][-1]['nativeZoom'] is False
 assert all(x['overflow']is False and x['failureCount']==0 and x['failures']==[]and 0<x['targets']<=128 and 0<x['fragments']<=1024 and x['textNodes']<=2048 for x in d['textReflowDiagnostics'])
 facts=d['factImmutability'];assert len(facts['tables'])==22 and facts['tenantCount']==2 and all(x['unchanged']and x['sha256']==x['afterSha256']for x in facts['tables'])
 for phase in ['rlsBefore','rlsAfter']:
  assert d[phase]['noBypass']and d[phase]['positiveBothTenants']and all(x['forcedRls']and x['nonowner']and x['unscopedVisible']==0 for x in d[phase]['rows'])
 audit=d['viewAudit'];assert len(audit['results'])==2
 assert all(0<x['observedSuccessful200']<=x['auditedViews']<=x['observedGetAttempts']and x['auditedViews']<=100 and x['metadataWhitelist']and x['everyAuditMatchesKnownAggregate']for x in audit['results'])
 assert len(d['nativeZoomCleanup'])==3 and all(x['status']=='PASS'for x in d['nativeZoomCleanup'])and all(x['status']=='PASS'for x in d['cleanupActions'])
 images=out/'actual-pngs-for-visual-review';assert not images.exists();images.mkdir()
 for n in z.namelist():
  if n.endswith('.png'):(images/n).write_bytes(z.read(n))
 result={'rootReview':'PASS ACTUAL COMPLETE REPORT ARTIFACT; VISUAL REVIEW STILL SEPARATE','sourceHead':head,'actualCheckedCommit':actual,'sameWholeTreeAsSource':True,'runId':summary['runId'],'artifact':reportart,'sources':15,'cases':33,'standardCells':9,'nativeCells':3,'nativeOriginalCaptures':21,'keyboardFocusChecks':54,'textReflowChecks':len(d['textReflowDiagnostics']),'matrixTextReflowChecks':57,'foreignPositiveTextReflowChecks':1,'immutableBusinessTables':22,'audit':audit,'forcedRlsBeforeAfter':True,'nativeProfileAndAllCleanup':'PASS','extractedOriginalPNGs':str(images),'limitations':d['limitations'],'noC12OrWholeC14Acceptance':True,'humanAtProductionHrSessionPhysicalMobileLoadRestore':'NOT RUN'}
 (out/'root-complete-report-content-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['rootReview','sourceHead','actualCheckedCommit','cases','nativeOriginalCaptures','keyboardFocusChecks','textReflowChecks','immutableBusinessTables']}))
