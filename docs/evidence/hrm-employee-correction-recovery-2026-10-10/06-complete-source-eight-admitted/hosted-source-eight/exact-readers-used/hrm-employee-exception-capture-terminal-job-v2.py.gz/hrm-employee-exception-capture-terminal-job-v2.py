from pathlib import Path
import subprocess, sys, json, gzip, hashlib, zipfile, datetime, re

rid, jid = map(int, sys.argv[1:3])
head, directory = sys.argv[3:5]
checked = sys.argv[5] if len(sys.argv) > 5 else head
assert re.fullmatch('[a-f0-9]{40}', checked)
assert re.fullmatch('[a-f0-9]{40}', head)
out = Path(directory)
assert not out.exists()
out.mkdir(parents=True)

def api(path, label):
    raw = subprocess.check_output(['gh', 'api', 'repos/rashadoni/leaddrive-v2/' + path])
    (out / (label + '-api-original.json.gz')).write_bytes(gzip.compress(raw, mtime=0))
    return json.loads(raw)

run = api(f'actions/runs/{rid}', 'run')
job = api(f'actions/jobs/{jid}', 'job')
artifacts = api(f'actions/runs/{rid}/artifacts?per_page=100', 'artifacts')
assert run['head_sha'] == head and job['run_id'] == rid
assert job['status'] == 'completed' and job['conclusion'] in {'success', 'failure'}
assert job['name'] == 'Authenticated employee own-exception browser evidence'
raw = subprocess.check_output(['gh', 'api', f'repos/rashadoni/leaddrive-v2/actions/jobs/{jid}/logs'])
(out / 'whole-employee-job-original.txt.gz').write_bytes(gzip.compress(raw, mtime=0))
matched = [a for a in artifacts['artifacts'] if a['name'] == f"workforce-employee-exception-browser-{checked}-{run['run_attempt']}"]
assert len(matched) == 1
a = matched[0]
assert a['workflow_run']['head_sha'] == head and not a['expired'] and a['size_in_bytes'] < 60_000_000
p = out / f"artifact-{a['id']}-original.zip"
with p.open('xb') as f:
    subprocess.run(['gh', 'api', f"repos/rashadoni/leaddrive-v2/actions/artifacts/{a['id']}/zip"], stdout=f, check=True)
digest = hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
assert p.stat().st_size == a['size_in_bytes'] and a['digest'] == 'sha256:' + digest
with zipfile.ZipFile(p) as z:
    assert z.testzip() is None
    names = z.namelist()
    assert len(names) == len(set(names)) and all(not n.startswith('/') and '..' not in Path(n).parts for n in names)
    name = next(n for n in names if n.endswith('employee-exception-receipt.json'))
    receipt = json.loads(z.read(name))
    assert receipt['sourceHead'] == head and receipt['checkedMergeSha'] == checked
    assert receipt['status'] == ('PASS' if job['conclusion'] == 'success' else 'FAIL')
result = {'observedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'runId': rid, 'jobId': jid,
          'headSha': head, 'runAttempt': run['run_attempt'], 'jobConclusion': job['conclusion'],
          'logBytes': len(raw), 'logSha256': hashlib.sha256(raw).hexdigest(),
          'artifact': {'id': a['id'], 'bytes': p.stat().st_size, 'sha256': digest, 'digestAndCRCValidated': True, 'members': names},
          'receipt': receipt, 'scope': 'Actual exact-head terminal employee job originals only; full content, pixels and other gates reviewed separately.'}
(out / 'employee-terminal-job-root-summary.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'out': str(out), 'head': head, 'run': rid, 'jobConclusion': job['conclusion'], 'logBytes': len(raw),
                  'artifactId': a['id'], 'status': receipt['status'], 'failure': receipt.get('failure'),
                  'completedCases': len(receipt['cases']), 'focus': len(receipt['keyboardFocusDiagnostics']),
                  'nativeCaptures': len(receipt['nativeCaptureDiagnostics'])}))
