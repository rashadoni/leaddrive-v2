from pathlib import Path
import sys,json,zipfile,subprocess,hashlib,re
out=Path(sys.argv[1]);head=sys.argv[2];base=sys.argv[3]
assert re.fullmatch('[a-f0-9]{40}',head) and re.fullmatch('[a-f0-9]{40}',base)
receipt=out/'root-complete-compiler-gate-review.json';assert not receipt.exists()
s=json.loads((out/'finite-capture-summary.json').read_text());assert s['headSha']==head
job=next(j for j in s['jobs']if j['name']=='Exact WF-C6-010 full compiler gates');assert job['conclusion']=='success'
a=next(a for a in s['artifacts']if a['name'].startswith('workforce-outcomes-compiler-'+head+'-'))
with zipfile.ZipFile(out/f"artifact-{a['id']}-original.zip")as z:
 assert sorted(z.namelist())==['tsc-exit-code','tsc-output.log']
 raw=z.read('tsc-output.log');code=z.read('tsc-exit-code')
log=out/'actual-full-tsc-output.log';exitfile=out/'actual-tsc-exit-code';log.write_bytes(raw);exitfile.write_bytes(code)
errors=re.findall(rb'error (TS\d+):',raw);exitcode=int(code);assert len(errors)>0 and exitcode==2
owned=subprocess.check_output(['git','diff','--name-only',base,head],text=True).splitlines()
ownedCount=sum(any(line.startswith((p+'(').encode())for p in owned)and b'error TS'in line for line in raw.splitlines());assert ownedCount==0
readers=[]
for cmd in [['bash','scripts/ci/check-typecheck-gate.sh',str(log),str(exitfile)],['/home/codex-alt/.local/bin/node','scripts/ci/check-typecheck-baseline.mjs',str(log)]]:
 r=subprocess.run(cmd,capture_output=True,text=True);readers.append({'command':cmd,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0
result={'status':'ACTUAL_FULL_RAW_COMPILER_STRICT_GATE_SUCCESS_GLOBAL_NONCLEAN','head':head,'base':base,'run':s['runId'],'job':job,'artifact':a,'rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'actualExit':exitcode,'diagnostics':len(errors),'families':len(set(errors)),'actualGateReaders':readers,'taskOwnedPaths':owned,'taskOwnedDiagnosticCount':0,'globalClean':False,'overallSourceRun':s['conclusion'],'scope':'Actual current-source full compiler and unchanged strict critical/pair-count readers. Observed diagnostic totals, no old-head totals imposed as an invariant; inherited diagnostics retained. No compiler rerun or source/baseline change.'}
receipt.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k]for k in ['status','head','diagnostics','families','taskOwnedDiagnosticCount','rawSha256']}))
