from pathlib import Path
import subprocess,json,sys,re,hashlib,gzip,zipfile,datetime
runid=int(sys.argv[1]);head=sys.argv[2];out=Path(sys.argv[3]);assert re.fullmatch('[a-f0-9]{40}',head)
assert not out.exists();out.mkdir(parents=True)
def raw(path): return subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/'+path])
def save_api(path,label):
 b=raw(path);(out/(label+'-api-original.json.gz')).write_bytes(gzip.compress(b,mtime=0));return json.loads(b)
run=save_api(f'actions/runs/{runid}','run');assert run['head_sha']==head and run['status']=='completed'
jobs=save_api(f'actions/runs/{runid}/jobs?per_page=100','jobs');assert len(jobs['jobs'])==jobs['total_count']
arts=save_api(f'actions/runs/{runid}/artifacts?per_page=100','artifacts');assert len(arts['artifacts'])==arts['total_count']
summary={'runId':runid,'runAttempt':run['run_attempt'],'headSha':head,'event':run['event'],'workflow':run['path'],'conclusion':run['conclusion'],'jobs':[],'artifacts':[],'observedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual completed run originals; no status or execution credit transferred to other heads. Source/merge/artifact content admission is a separate review.'}
for j in jobs['jobs']:
 assert j['status']=='completed'
 row={'id':j['id'],'name':j['name'],'conclusion':j['conclusion'],'steps':[{'name':s['name'],'conclusion':s['conclusion']}for s in j.get('steps',[])]}
 if j['conclusion']!='skipped':
  b=raw(f"actions/jobs/{j['id']}/logs");(out/f"job-{j['id']}-original.txt.gz").write_bytes(gzip.compress(b,mtime=0));row.update(logBytes=len(b),logSha256=hashlib.sha256(b).hexdigest())
 summary['jobs'].append(row)
for a in arts['artifacts']:
 assert not a['expired'] and a['workflow_run']['id']==runid and a['workflow_run']['head_sha']==head
 assert re.fullmatch('sha256:[a-f0-9]{64}',a['digest']) and a['size_in_bytes']<=200_000_000
 p=out/f"artifact-{a['id']}-original.zip"
 with p.open('xb')as f: subprocess.run(['gh','api',f"repos/rashadoni/leaddrive-v2/actions/artifacts/{a['id']}/zip"],stdout=f,check=True)
 digest=hashlib.file_digest(p.open('rb'),'sha256').hexdigest();assert digest==a['digest'].split(':')[1]
 assert p.stat().st_size==a['size_in_bytes']
 with zipfile.ZipFile(p)as z:
  assert z.testzip()is None
  members=z.namelist();assert len(members)==len(set(members)) and all(not x.startswith('/')and'..'not in Path(x).parts for x in members)
 summary['artifacts'].append({'id':a['id'],'name':a['name'],'bytes':p.stat().st_size,'sha256':digest,'apiDigestMatched':True,'allCRCValidated':True,'members':members})
(out/'finite-capture-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'runId':runid,'conclusion':summary['conclusion'],'jobs':[{k:j[k]for k in ['id','name','conclusion']}for j in summary['jobs']],'artifacts':len(summary['artifacts']),'out':str(out)}))
