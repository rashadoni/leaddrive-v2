from pathlib import Path
import subprocess,json,hashlib,zipfile,gzip,struct,re,sys
head,run,job,aid=sys.argv[1:5];assert re.fullmatch('[0-9a-f]{40}',head);assert all(re.fullmatch('[0-9]+',x) for x in [run,job,aid]);w=Path('/mnt/HC_Volume_106454338/codex-alt-data/worktrees/leaddrive-hrm-report-accessibility-20261010');p=Path('/tmp/hrm-report-accessibility-'+head[:3]+'-job-'+job+'-browser-peer');assert not p.exists(), 'original inspection directory exists; preserve and use a separately named supplemental review';p.mkdir()
h=lambda x:hashlib.sha256(x).hexdigest()
def gh(path,name):
 b=subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/'+path]);(p/name).write_bytes(b);return b
runapi=json.loads(gh('actions/runs/'+run,'original-run-api.json'));jobapi=json.loads(gh('actions/jobs/'+job,'original-job-api.json'));api=json.loads(gh('actions/runs/'+run+'/artifacts?per_page=100','original-artifacts-api.json'));artifact=next(x for x in api['artifacts'] if x['id']==int(aid));data=gh('actions/artifacts/'+aid+'/zip','original-artifact-'+aid+'.zip');assert len(data)==artifact['size_in_bytes'] and artifact['workflow_run']['head_sha']==head and artifact['digest']=='sha256:'+h(data);z=zipfile.ZipFile(p/('original-artifact-'+aid+'.zip'));assert z.testzip() is None
log=subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/actions/jobs/'+job+'/logs']);(p/'original-full-log.gz').write_bytes(gzip.compress(log,mtime=0));r=json.loads(z.read('exception-report-receipt.json'));context=json.loads(z.read('workflow-context.json'));tree=subprocess.check_output(['git','show','-s','--format=%T',head],cwd=w,text=True).strip();assert runapi['head_sha']==r['candidateHead']==context['headSha']==head and context['runId']==run and context['productionMutation'] is False
checked=r['checkedMergeSha'];assert context['ciSha']==checked;checkout=[];lines=log.decode().splitlines()
for i,l in enumerate(lines):
 if 'git log -1 --format=%H' in l:checkout.extend(lines[i:i+2])
assert any(checked in x for x in checkout)
if checked!=head:
 commit=json.loads(gh('git/commits/'+checked,'original-checked-commit-api.json'));assert commit['tree']['sha']==tree
else:assert context['ciSha']==head
for x in r['sources']:
 b=subprocess.check_output(['git','show',head+':'+x['path']],cwd=w);assert len(b)==x['bytes'] and h(b)==x['sha256']
assert len({x['path'] for x in r['sources']})==len(r['sources'])==15 and r['harnessSha256']==next(x['sha256'] for x in r['sources'] if x['path']=='scripts/workforce-exception-report-browser-evidence.mjs')
check=json.loads(gh('check-runs/'+job,'original-check-api.json'));assert check['app']['id']==15368 and check['head_sha']==head and check['conclusion']=='success' and jobapi['head_sha']==head;assert jobapi['conclusion']=='success';assert [{'name':x['name'],'conclusion':x['conclusion']} for x in jobapi['steps'] if x['conclusion']!='success']==[{'name':'Preserve non-secret workflow failure receipt','conclusion':'skipped'}]
assert r['status']==r['nativeZoomVerdict']==r['cleanup']=='PASS' and len(r['cases'])==33 and all(x['status']=='PASS' for x in r['cases']);matrix=r['matrix'];assert matrix=={'locales':['az','ru','en'],'widths':[320,768,1440],'standardExpected':9,'nativeExpected':3};expected=set()
for locale in matrix['locales']:
 for width in matrix['widths']:expected.add(f'standard-100-{locale}-{width}-nonempty')
 expected.add(f'native-200-{locale}-320-nonempty')
 for kind in ['standard-100','native-200']:
  for state in ['empty','unresolved-no-sample','measured-zero']:expected.add(f'{kind}-{locale}-320-{state}')
mc=[x for x in r['cases'] if x['name'].startswith(('standard-100-','native-200-'))];assert len(mc)==len(expected)==30 and {x['name'] for x in mc}==expected;assert all(x['noFalsePercentages'] is True for x in mc if not x['name'].endswith('-nonempty'))
assert len(r['nativeZoomDiagnostics'])==3 and {x['locale'] for x in r['nativeZoomDiagnostics']}==set(matrix['locales'])
for proof in r['nativeZoomDiagnostics']:
 assert proof['status']=='PASS' and proof['fixture']=='exception-report' and proof['method']=='BROWSER_TABS_AUTOMATIC_PER_TAB_ZOOM' and proof['factor']==2 and proof['event']['oldFactor']==1 and proof['event']['newFactor']==2 and proof['event']['settings']=={'mode':'automatic','scope':'per-tab'}
 assert proof['control']['width']==640 and proof['control']['devicePixelRatio']==1 and proof['zoomed']['width']==320 and proof['zoomed']['devicePixelRatio']==2 and proof['viewportEmulation'] is proof['applicationCssChanged'] is False and proof['applicationServiceWorkers']==0
 for state in ['control','zoomed']:assert proof[state]['rootZoom']==proof[state]['bodyZoom']=='1' and proof[state]['rootTransform']==proof[state]['bodyTransform']=='none'
assert len(r['nativeCaptureDiagnostics'])>=21
for cap in r['nativeCaptureDiagnostics']:
 raw=z.read(cap['screenshot']);assert len(raw)==cap['original']['bytes'] and h(raw)==cap['original']['sha256'] and raw[:8]==b'\x89PNG\r\n\x1a\n';assert struct.unpack('>II',raw[16:24])==(cap['pixels']['width'],cap['pixels']['height']);assert cap['status']==cap['cleanup']=='PASS' and cap['method']=='CDP_VISIBLE_SURFACE_NO_CLIP' and cap['suppliedClip'] is False
 assert cap['before']==cap['after']
assert len(r['keyboardFocusDiagnostics'])==54
for x in r['keyboardFocusDiagnostics']:
 assert x['focused'] is x['focusVisible'] is True;box=x['box'];clip=x['clip'];assert box['width']>0 and box['height']>0 and box['left']>=clip['left']-1 and box['right']<=clip['right']+1 and box['top']>=clip['top']-1 and box['bottom']<=clip['bottom']+1
assert len(r['textReflowDiagnostics'])==57
for x in r['textReflowDiagnostics']:assert x['targets']<=128 and x['textNodes']<=2048 and x['fragments']<=1024 and x['overflow'] is False and x['failureCount']==0 and x['failures']==[]
facts=r['factImmutability'];assert facts['tenantCount']==2 and len(facts['tables'])==22 and len({x['table'] for x in facts['tables']})==22 and all(x['unchanged'] and x['sha256']==x['afterSha256'] and x['count']<=500 for x in facts['tables'])
for phase in ['rlsBefore','rlsAfter']:
 s=r[phase];assert s['noBypass'] and s['positiveBothTenants'] and len(s['rows'])==5
 for x in s['rows']:assert x['forcedRls'] and x['nonowner'] and x['unscopedVisible']==0 and all(t['rows']>0 and t['foreignVisible']==0 for t in x['positive']) and {t['tenant'] for t in x['positive']}=={'a','b'}
audit=r['viewAudit'];assert audit['appendOnlyAuditPrivilegeOnly'] is True and audit['globallyZeroDatabaseWritesClaimed'] is False and len(audit['results'])==2
for x in audit['results']:assert x['auditedViews']<=100 and x['metadataWhitelist'] and x['everyAuditMatchesKnownAggregate']
assert len(r['nativeZoomCleanup'])==3 and all(x['status']=='PASS' for x in r['nativeZoomCleanup']) and all(x['status']=='PASS' for x in r['cleanupActions'])
report={'status':'ACCEPTED_ACTUAL_BOUNDED_REPORT_MATRIX_ONLY','sourceSha':head,'sourceTree':tree,'checkedSha':checked,'runId':int(run),'jobId':int(job),'url':jobapi['html_url'],'actualCheckoutOriginalLines':checkout,'cases':r['cases'],'sourceBindings':r['sources'],'matrix':matrix,'nativeProofs':r['nativeZoomDiagnostics'],'nativeCaptureOriginalsVerified':len(r['nativeCaptureDiagnostics']),'keyboardFocusChecks':len(r['keyboardFocusDiagnostics']),'textReflowDiagnostics':r['textReflowDiagnostics'],'factImmutability':facts,'rlsBefore':r['rlsBefore'],'rlsAfter':r['rlsAfter'],'viewAudit':audit,'cleanupActions':r['cleanupActions'],'artifact':{'id':int(aid),'bytes':len(data),'sha256':h(data),'apiDigestAndZipCrc':'PASS','originalPath':str(p/('original-artifact-'+aid+'.zip')),'members':[{'path':x.filename,'bytes':x.file_size,'crc32':f'{x.CRC:08x}','sha256':h(z.read(x.filename))} for x in z.infolist()]},'fullLog':{'rawBytes':len(log),'rawSha256':h(log),'originalGzip':str(p/'original-full-log.gz')},'allNormalStepsSuccess':True,'checkAppId':check['app']['id'],'failureOnlyReceiptStepSkippedNotCredited':True,'visualInspection':'PENDING_SEPARATE_ACTUAL_PNG_REVIEW','findingsP0P1P2':[],'limitations':r['limitations'],'originalFailuresNotReclassified':True,'wholeC14C12Closed':False,'peerTestsRepoProdMutations':False}
f=Path('/tmp/hrm-report-accessibility-hosted-browser-peer-review-'+head[:3]+'-job-'+job+'.json');assert not f.exists();f.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'report':str(f),'bytes':f.stat().st_size,'sha256':h(f.read_bytes()),'cases':33,'focus':54,'captures':len(r['nativeCaptureDiagnostics']),'exactBindings':15}))
