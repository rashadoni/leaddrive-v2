element => {
    const targets = element.querySelectorAll("h2, h3, p, dt, dd")
    const result = { targets: targets.length, fragments: 0, textNodes: 0, failures: [], failureCount: 0, overflow: false }
    if (targets.length > 128) return { ...result, overflow: "TARGETS" }
    for (const [ordinal, target] of targets.entries()) {
      const box = target.getBoundingClientRect()
      let left = Math.max(0, box.left), right = Math.min(innerWidth, box.right)
      for (let ancestor = target.parentElement; ancestor; ancestor = ancestor.parentElement) {
        if (["auto", "scroll", "hidden", "clip"].includes(getComputedStyle(ancestor).overflowX)) {
          const bounds = ancestor.getBoundingClientRect()
          left = Math.max(left, bounds.left + ancestor.clientLeft)
          right = Math.min(right, bounds.left + ancestor.clientLeft + ancestor.clientWidth)
        }
      }
      const walker = document.createTreeWalker(target, NodeFilter.SHOW_TEXT)
      for (let node = walker.nextNode(); node; node = walker.nextNode()) {
        if (result.textNodes === 2048) return { ...result, overflow: "TEXT_NODES" }
        result.textNodes++
        if (!node.textContent.trim()) continue
        const range = document.createRange()
        range.selectNodeContents(node)
        for (const fragment of range.getClientRects()) {
          if (result.fragments === 1024) return { ...result, overflow: "FRAGMENTS" }
          result.fragments++
          if (![left, right, fragment.left, fragment.right].every(Number.isFinite)
            || fragment.left < left - 1 || fragment.right > right + 1) {
            result.failureCount++
            if (result.failures.length < 32) result.failures.push({ ordinal, tag: target.tagName, left: fragment.left, right: fragment.right, clipLeft: left, clipRight: right })
          }
        }
      }
    }
    return result
  }