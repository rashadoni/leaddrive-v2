At 320px, the exception report Refresh button extended beyond the usable page width. Back and Refresh now wrap within that width, including native Chrome 200% zoom. Existing sections, actions, roles and recorded-outcome calculations are retained.

Added a hosted report browser matrix for AZ/RU/EN at 320/768/1440px and native Chrome 200%, with real keyboard navigation, bounded text/control reflow checks, tenant/RLS/privacy boundaries and immutable business facts. Native browser admission remains fixed to approved routes.

Verified exact final source `7ba977616a209376cbbb9f9370d005895752cbbe`: [five source lanes](https://github.com/rashadoni/leaddrive-v2/actions/runs/38011318557), [required checks](https://github.com/rashadoni/leaddrive-v2/actions/runs/38011321131), [candidate report](https://github.com/rashadoni/leaddrive-v2/actions/runs/38011321253). All five mandatory GitHub App checks actually succeeded. Source and candidate share the same whole tree.

- Report: 33 cases, 3 native zoom cells/21 original native captures, 54 focus checks, 58 reflow checks (57 matrix + existing foreign-positive case), 22 unchanged business tables; bounded audit, RLS and cleanup passed.
- 27 admission tests, 44 real PostgreSQL tests, original HR classification, calendar and manager regressions passed. Isolated build produced standalone/static outputs.
- Full compiler remains globally nonclean: exit2/1158 diagnostics/35 families, exactly matching all64 unchanged baseline pairs/counts; zero owned/critical errors. All18 strict regression baseline files still fail as recorded. No baseline or gate weakening.

Independent source and complete-artifact review accepted this exact head. Original 39/BF browser/regression failures and corrected reader errors remain in the append-only evidence PR663. The inherited dashboard-manifest trace-copy build warning is preserved; normal production artifact and post-deploy smoke still must be verified. Dev badge overlap is not claimed as complete pixel-occlusion or human assistive-technology acceptance.

This scoped result does not close C12 or the whole C14 acceptance matrix. No production HR decisions, synthetic operational credit, schema/access/secret changes, activation, restore, Support or HRHub document work.
