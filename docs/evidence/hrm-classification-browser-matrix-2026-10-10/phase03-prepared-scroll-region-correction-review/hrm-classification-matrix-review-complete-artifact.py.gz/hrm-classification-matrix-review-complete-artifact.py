from pathlib import Path
import sys,json,zipfile,hashlib,subprocess,struct,math
out=Path(sys.argv[1]);head=sys.argv[2];dest=out/'root-complete-classification-content-review.json';assert not dest.exists()
s=json.loads((out/'finite-capture-summary.json').read_bytes());assert s['headSha']==head
art=next(a for a in s['artifacts'] if a['name'].startswith('workforce-exception-classification-browser-'))
with zipfile.ZipFile(out/f"artifact-{art['id']}-original.zip") as z:
 assert z.testzip() is None
 d=json.loads(z.read('exception-classification-receipt.json'));assert d['candidateHead']==head
 checked=d['checkedMergeSha'];c=json.loads(subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/commits/'+checked]))
 assert c['commit']['tree']['sha']==subprocess.check_output(['git','rev-parse',head+'^{tree}'],text=True).strip()
 if checked!=head:assert len(c['parents'])==2 and c['parents'][-1]['sha']==head
 assert len(d['sources'])==19 and len({x['path'] for x in d['sources']})==19
 for x in d['sources']:
  b=subprocess.check_output(['git','show',head+':'+x['path']]);assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
 assert d['productionRoutineInstallation']['status']=='COMMITTED' and len(d['productionRoutines'])==7
 lifecycle='prisma/migrations/20260830170000_workforce_exception_case_lifecycle/migration.sql'
 revisions='prisma/migrations/20260927014000_workforce_exception_case_revisions/migration.sql'
 statements=[(lifecycle,'CREATE OR REPLACE FUNCTION workforce_reject_exception_case_mutation(','\n$$;'),(lifecycle,'CREATE OR REPLACE FUNCTION workforce_reject_exception_decision_mutation(','\n$$;'),(revisions,'CREATE OR REPLACE FUNCTION workforce_next_exception_compatibility_timestamp(','\n$$;'),(revisions,'CREATE OR REPLACE FUNCTION workforce_assign_exception_decision_revision(','\n$$;'),(lifecycle,'CREATE TRIGGER workforce_exception_cases_append_only',';'),(lifecycle,'CREATE TRIGGER workforce_exception_decisions_append_only',';'),(revisions,'CREATE TRIGGER workforce_exception_decisions_assign_case_revision',';')]
 for x,(path,start,end) in zip(d['productionRoutines'],statements):
  raw=subprocess.check_output(['git','show',head+':'+path]).decode();a=raw.index(start);b=raw.index(end,a);statement=raw[a:b+len(end)].encode()
  assert x['path']==path and x['bytes']==len(statement) and x['sha256']==hashlib.sha256(statement).hexdigest()
 # Failure originals are retained without turning partial counts into PASS.
 if d['status']!='PASS':
  result={'status':'ORIGINAL_FAILURE_RETAINED_NO_ACCEPTANCE','sourceHead':head,'runId':s['runId'],'actualCheckedCommit':checked,'sameWholeTreeAsSource':True,'artifact':art,'failure':d.get('failure'),'completedCases':len(d['cases']),'sources':len(d['sources']),'focusBeforeFailure':d['keyboardFocusDiagnostics'],'privateCaptureRefusalsBeforeFailure':d['privacyCaptureRefusals'],'writesBeforeFailure':d['writeDiagnostics'],'nativeZoomVerdict':d['nativeZoomVerdict'],'cleanup':d['cleanup'],'cleanupDiagnostics':d['cleanupDiagnostics'],'limitations':d['limitations']}
 else:
  assert d['cleanup']=='PASS' and d['nativeZoomVerdict']=='PASS'
  cases=d['cases'];assert len(cases)==20 and all(x['status']=='PASS' for x in cases) and len({x['name'] for x in cases})==20
  wanted={f'standard-100-{l}-{w}' for l in ['az','ru','en'] for w in [320,768,1440]}|{f'native-200-{l}-320' for l in ['az','ru','en']}
  matrix=[x for x in cases if x['name'].startswith(('standard-100-','native-200-'))];assert len(matrix)==12 and {x['name'] for x in matrix}==wanted
  for x in matrix:
   assert x['protectedReasonRequired'] and x['directCallerCaseOrCodeAbsent'] and x['keyboardManualEntryAndSubmit']
   assert x['classificationCode']==('CLASSIFY_FALSE_POSITIVE' if x['locale']=='ru' else 'CLASSIFY_CONFIRMED_EXCEPTION')
   assert x['appealCode']=={'az':'APPEAL_PARTIALLY_UPHELD','ru':'APPEAL_FULLY_UPHELD','en':'APPEAL_REJECTED'}[x['locale']]
  negative={x['name']:x for x in cases if x['name'] not in wanted}
  assert set(negative)=={'exact-replay-and-conflicting-reason-and-stale-revision','denied-hr-without-mandatory-enrolled-mfa','denied-team-manager','denied-tenant-admin','denied-ungranted','denied-foreign-hr','reopen-invalidates-final-classification','live-hr-revocation-with-team-manager-still-effective'}
  assert negative['exact-replay-and-conflicting-reason-and-stale-revision']['auditDeltaOnRetry']==negative['exact-replay-and-conflicting-reason-and-stale-revision']['decisionDeltaOnRetry']==0
  for name,row in negative.items():
   if name.startswith('denied-') or name=='live-hr-revocation-with-team-manager-still-effective':assert row['recordedDelta']==0 and row['writeStatus']==(403 if name=='denied-hr-without-mandatory-enrolled-mfa' else 404)
  assert len(d['authenticationDiagnostics'])==17
  assert all(x['csrfStatus']==x['callbackStatus']==200 for x in d['authenticationDiagnostics'])
  assert len(d['nativeZoomDiagnostics'])==3 and {x['locale'] for x in d['nativeZoomDiagnostics']}=={'az','ru','en'}
  for x in d['nativeZoomDiagnostics']:
   assert x['status']=='PASS' and x['factor']==2 and x['fixture']=='exception-classification' and x['method']=='BROWSER_TABS_AUTOMATIC_PER_TAB_ZOOM'
   assert x['event']['oldFactor']==1 and x['event']['newFactor']==2 and x['settings']['mode']=='automatic' and x['settings']['scope']=='per-tab'
   assert x['control']['width']==640 and x['control']['devicePixelRatio']==1 and x['zoomed']['width']==320 and x['zoomed']['devicePixelRatio']==2
   assert x['viewportEmulation'] is False and x['applicationCssChanged'] is False and x['applicationServiceWorkers']==0
  captures=d['nativeCaptureDiagnostics'];assert len(captures)==21 and len({x['screenshot'] for x in captures})==21
  for x in captures:
   assert x['status']==x['cleanup']=='PASS' and x['method']=='CDP_VISIBLE_SURFACE_NO_CLIP' and x['suppliedClip'] is False
   assert x['before']==x['after'] and x['layoutBefore']==x['layoutAfter'] and x['pixels']==x['controlSurface']
   b=z.read(x['screenshot']);assert len(b)==x['original']['bytes'] and hashlib.sha256(b).hexdigest()==x['original']['sha256']
   assert b[:8]==b'\x89PNG\r\n\x1a\n' and b[12:16]==b'IHDR';width,height=struct.unpack('>II',b[16:24]);assert (width,height)==(x['pixels']['width'],x['pixels']['height']) and width==640
   assert x['before']['devicePixelRatio']==(1 if x['control'] else 2)
  focus=d['keyboardFocusDiagnostics'];assert len(focus)==108
  for x in focus:
   b=x['box'];clip=x['clip'];assert x['focused'] and x['focusVisible'] and b['width']>0 and b['height']>0
   assert all(isinstance(v,(int,float)) and math.isfinite(v) for v in list(b.values())+list(clip.values()))
   assert b['left']>=clip['left']-1 and b['right']<=clip['right']+1
   if x['tableRegion']:assert b['bottom']>clip['top'] and b['top']<clip['bottom']
   else:assert b['top']>=clip['top']-1 and b['bottom']<=clip['bottom']+1
  assert sum(bool(x['tableRegion']) for x in focus)==12
  refusal=d['privacyCaptureRefusals'];assert len(refusal)==48
  assert all(x['status']=='PASS' and x['screenshotSinkInvoked'] is False and x['rawReasonRetained'] is False for x in refusal)
  for l,w,native in [(l,w,False) for l in ['az','ru','en'] for w in [320,768,1440]]+[(l,320,True) for l in ['az','ru','en']]:
   rows=[x for x in refusal if (x['locale'],x['width'],x['nativeZoom'])==(l,w,native)];assert len(rows)==4 and sorted(x['kind'] for x in rows)==['COMPLETE_REASON','COMPLETE_REASON','PARTIAL_REASON','PARTIAL_REASON']
  db=d['database'];assert db['actualNewDecisionCount']==db['actualAuditCount']==24
  assert db['nonownerForcedRls'] and db['populatedTwoTenantDecisionControls'] and db['unscopedRows']==db['foreignRows']==0 and db['exactActorReasonAndAuditLink'] and db['exactProductionDecisionImmutability'] and db['syntheticAuditGuard']
  facts=d['fixedFacts'];assert facts['unchanged'] and len(facts['tables'])==8 and all(x['rows']<=100 for x in facts['tables'])
  assert facts['phase']=='after-twenty-four-ui-appends-before-intentional-fixture-revocation'
  assert all(x['status']=='PASS' for x in d['cleanupDiagnostics'])
  result={'status':'PASS_ACTUAL_COMPLETE_ARTIFACT_VISUAL_REVIEW_SEPARATE','sourceHead':head,'runId':s['runId'],'actualCheckedCommit':checked,'sameWholeTreeAsSource':True,'artifact':art,'cases':20,'matrixCells':12,'actualNewManualWrites':24,'linkedImmutableAudits':24,'sourceBindings':19,'exactMigrationExtracts':7,'focusChecks':108,'tableRegionIntersections':12,'fullyBoundedIndividualControls':96,'nativeCells':3,'nativeOriginalCaptures':21,'privateReasonCaptureRefusals':48,'immutableBusinessTables':8,'allCleanup':'PASS','limitations':d['limitations'],'wholeC14OrC12Acceptance':False,'humanPhysicalOperationalAcceptance':'NOT RUN'}
 imageout=out/'classification-original-pngs-for-visual-review';assert not imageout.exists();imageout.mkdir()
 for n in z.namelist():
  if n.endswith('.png'):
   b=z.read(n);assert b[:8]==b'\x89PNG\r\n\x1a\n';target=imageout/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 result['originalImagesExtracted']=str(imageout)
 dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','sourceHead','runId','actualCheckedCommit']}))
