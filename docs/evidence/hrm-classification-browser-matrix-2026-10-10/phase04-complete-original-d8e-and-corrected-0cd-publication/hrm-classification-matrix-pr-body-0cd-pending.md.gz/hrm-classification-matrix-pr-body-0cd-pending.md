Expand manual HR recording browser coverage from three diagonal cells to AZ/RU/EN×320/768/1440 and real native Chrome200%. Fresh cases exercise real keyboard manual entry, mandatory MFA, opaque tokens, required private reasons, exact replay/conflict/stale behavior, original denial/reopen/live-revocation controls, immutable facts and linked audits. Production decisions/roles/calculations/CASE_RECORDED_AT remain unchanged.

Every capture rejects any nonempty private reason, including partial keyboard input. The runtime tests that admission without calling a screenshot sink with protected values.

First exact-source D8E run38013716710 completed with four actual SUCCESS lanes (report, guard31/PG44/strict18 regressions, full compiler, bundle build) and HR browser FAILURE before cases/focus/writes. Original complete APIs/logs/ZIPs and safe PNG remain in evidence PR663. Broad named-region selection was the source diagnosis: named section and its nested scroll viewport share a label.

Current `0cd2866a83b0b3e95bba24cd22f02ad037da1a62` targets the unique keyboard-focusable scrolling div and retains exact translated accessible-name/tabindex/table assertions plus finite selector-count diagnostics. Independent review accepted this narrow delta; all geometry/privacy/write/DB gates are unchanged. The original safe Error's exact cause remains inference until actual selector counts from the new run.

Fresh hosted verification pending. Expected31 guards/20 cases/24manual writes+24linked audits/108focus/3native cells+21original captures/48partial-full private-capture refusals are not reported PASS. Full strict64 compiler pairs/counts and18-file test baselines remain unchanged; global code is nonclean.

Continuation of released [PR672](https://github.com/rashadoni/leaddrive-v2/pull/672), preserving589→605→608 ancestry. No C12/whole-C14 task closure or operational/human HR credit, production activation/restore/data/access/secrets, Support or HRHub document work.
