from pathlib import Path
import subprocess,json,hashlib,zipfile,gzip,struct,re,math,datetime
from collections import Counter
head='a1617f62aba38adc8af8905ecf36093b483e2ae2';run=38016788152;job=114108723307;aid=11656862823
w=Path('/mnt/HC_Volume_106454338/codex-alt-data/worktrees/leaddrive-hrm-classification-browser-matrix-20261010');out=Path('/tmp/hrm-classification-matrix-a161-completed-hr-peer');out.mkdir(exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest()
def get(path,name):
 f=out/name
 if not f.exists():f.write_bytes(subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/'+path]))
 return f.read_bytes()
def source(path):return subprocess.check_output(['git','show',head+':'+path],cwd=w)
def require(v,label):
 if not v:raise AssertionError(label)
runraw=get(f'actions/runs/{run}','original-run-api.json');jobraw=get(f'actions/jobs/{job}','original-job-api.json');checkraw=get(f'check-runs/{job}','original-check-api.json');araw=get(f'actions/artifacts/{aid}','original-artifact-api.json')
ra,ja,ca,aa=[json.loads(b) for b in [runraw,jobraw,checkraw,araw]]
require(ra['head_sha']==ja['head_sha']==ca['head_sha']==aa['workflow_run']['head_sha']==head,'all API source bindings')
require(ra['run_attempt']==1 and ra['event']=='workflow_dispatch' and ja['run_id']==run,'actual dispatch attempt/run')
require(ja['status']=='completed' and ja['conclusion']==ca['conclusion']=='success' and ca['app']['id']==15368,'actual completed job App15368')
require([{'name':s['name'],'conclusion':s['conclusion']} for s in ja['steps'] if s['conclusion']!='success']==[{'name':'Preserve non-secret workflow failure receipt','conclusion':'skipped'}],'all blocking steps pass')
zipraw=get(f'actions/artifacts/{aid}/zip',f'original-artifact-{aid}.zip');require(len(zipraw)==aa['size_in_bytes'] and aa['digest']=='sha256:'+h(zipraw),'API digest ZIP length')
logpath=out/'original-full-log.gz'
if not logpath.exists():logpath.write_bytes(gzip.compress(subprocess.check_output(['gh','api',f'repos/rashadoni/leaddrive-v2/actions/jobs/{job}/logs']),mtime=0))
log=gzip.decompress(logpath.read_bytes());text=log.decode();lines=text.splitlines();checkout=[]
for i,l in enumerate(lines):
 if 'git log -1 --format=%H' in l:checkout.extend(lines[i:i+2])
require(any(head in l for l in checkout),'standalone checkout actual head')
tree=subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=w,text=True).strip()
with zipfile.ZipFile(out/f'original-artifact-{aid}.zip') as z:
 require(z.testzip() is None,'CRC')
 for n in z.namelist():require(not n.startswith('/') and '..' not in Path(n).parts,'safe member path')
 raw=z.read('exception-classification-receipt.json');d=json.loads(raw);context=json.loads(z.read('workflow-context.json'))
 require(d['candidateHead']==d['checkedMergeSha']==context['headSha']==context['ciSha']==head,'exact standalone receipt/context')
 require(context['runId']==str(run) and context['runAttempt']=='1' and context['productionMutation'] is False,'isolated workflow context')
 require(d['status']==d['nativeZoomVerdict']==d['cleanup']=='PASS','actual receipt pass')
 require(len(d['sources'])==19 and len({s['path'] for s in d['sources']})==19,'19 sources')
 for s in d['sources']:
  b=source(s['path']);require(len(b)==s['bytes'] and h(b)==s['sha256'],'source '+s['path'])
 lp='prisma/migrations/20260830170000_workforce_exception_case_lifecycle/migration.sql';rp='prisma/migrations/20260927014000_workforce_exception_case_revisions/migration.sql'
 specs=[(lp,'CREATE OR REPLACE FUNCTION workforce_reject_exception_case_mutation(','\n$$;'),(lp,'CREATE OR REPLACE FUNCTION workforce_reject_exception_decision_mutation(','\n$$;'),(rp,'CREATE OR REPLACE FUNCTION workforce_next_exception_compatibility_timestamp(','\n$$;'),(rp,'CREATE OR REPLACE FUNCTION workforce_assign_exception_decision_revision(','\n$$;'),(lp,'CREATE TRIGGER workforce_exception_cases_append_only',';'),(lp,'CREATE TRIGGER workforce_exception_decisions_append_only',';'),(rp,'CREATE TRIGGER workforce_exception_decisions_assign_case_revision',';')]
 require(len(d['productionRoutines'])==7 and d['productionRoutineInstallation']['status']=='COMMITTED','7 fixture production migration statements')
 for s,(path,start,end) in zip(d['productionRoutines'],specs):
  full=source(path).decode();a=full.index(start);b=full.index(end,a);statement=full[a:b+len(end)].encode();require(s['path']==path and s['bytes']==len(statement) and s['sha256']==h(statement),'exact migration extract')
 cells={(l,v,False) for l in ['az','ru','en'] for v in [320,768,1440]}|{(l,320,True) for l in ['az','ru','en']}
 expected={('native-200-' if native else 'standard-100-')+l+'-'+str(v) for l,v,native in cells}
 require(d['matrix']=={'locales':['az','ru','en'],'widths':[320,768,1440],'standardExpected':9,'nativeExpected':3},'matrix declaration')
 cases=d['cases'];require(len(cases)==20 and len({s['name'] for s in cases})==20 and all(s['status']=='PASS' for s in cases),'20 distinct actual cases')
 matrix=[s for s in cases if s['name'] in expected];require(len(matrix)==12 and {s['name'] for s in matrix}==expected,'actual all12 matrix cells')
 for s in matrix:
  require(s['protectedReasonRequired'] and s['directCallerCaseOrCodeAbsent'] and s['keyboardManualEntryAndSubmit'],'real guarded manual cell')
  require(s['classificationCode']==('CLASSIFY_FALSE_POSITIVE' if s['locale']=='ru' else 'CLASSIFY_CONFIRMED_EXCEPTION'),'classification code')
  require(s['appealCode']=={'az':'APPEAL_PARTIALLY_UPHELD','ru':'APPEAL_FULLY_UPHELD','en':'APPEAL_REJECTED'}[s['locale']],'separate three appeal outcomes')
 extra={s['name']:s for s in cases if s['name'] not in expected};require(set(extra)=={'exact-replay-and-conflicting-reason-and-stale-revision','denied-hr-without-mandatory-enrolled-mfa','denied-team-manager','denied-tenant-admin','denied-ungranted','denied-foreign-hr','reopen-invalidates-final-classification','live-hr-revocation-with-team-manager-still-effective'},'preserved8 othercases')
 require(extra['exact-replay-and-conflicting-reason-and-stale-revision']['auditDeltaOnRetry']==extra['exact-replay-and-conflicting-reason-and-stale-revision']['decisionDeltaOnRetry']==0,'replay no audit/decision delta')
 for name,s in extra.items():
  if name.startswith('denied-') or name=='live-hr-revocation-with-team-manager-still-effective':require(s['recordedDelta']==0 and s['writeStatus']==(403 if name=='denied-hr-without-mandatory-enrolled-mfa' else 404),'actual denial '+name)
 regions=d['queueRegionDiagnostics'];require(len(regions)==12 and {(s['locale'],s['width'],s['nativeZoom']) for s in regions}==cells,'unique12 queue diagnostics')
 for s in regions:require(s['namedRegionCount']==2 and s['scrollableRegionCount']==s['tableCount']==1 and s['translatedLabelMatches'] and s['tabindex']=='0','real unique scrollregion, two named regions')
 focus=d['keyboardFocusDiagnostics'];require(len(focus)==108 and Counter((s['locale'],s['width'],s['nativeZoom']) for s in focus)==Counter({c:9 for c in cells}),'108 focus=9 eachcell')
 for s in focus:
  b=s['box'];clip=s['clip'];require(s['focused'] and s['focusVisible'] and b['width']>0 and b['height']>0,'real focused visible control')
  require(all(type(v) in [int,float] and math.isfinite(v) for v in list(b.values())+list(clip.values())),'finite focus bounds')
  require(b['left']>=clip['left']-1 and b['right']<=clip['right']+1,'horizontal bounded')
  require(b['bottom']>clip['top'] and b['top']<clip['bottom'] if s['tableRegion'] else b['top']>=clip['top']-1 and b['bottom']<=clip['bottom']+1,'vertical intersection/fullcontrol')
 require(sum(s['tableRegion'] for s in focus)==12,'12 intersections96fullcontrols')
 corrected=[s for s in focus if s['locale']=='az' and s['width']==320 and not s['nativeZoom'] and s['phase']=='CLASSIFY_CONFIRMED_EXCEPTION-empty-submit'];require(len(corrected)==1,'specific old94px failure control')
 refusals=d['privacyCaptureRefusals'];require(len(refusals)==48,'48private refusal admissions')
 require(all(s['status']=='PASS' and s['screenshotSinkInvoked'] is False and s['rawReasonRetained'] is False for s in refusals),'no screenshot sink or retained rawreason')
 for c in cells:
  rows=[s for s in refusals if (s['locale'],s['width'],s['nativeZoom'])==c];require(len(rows)==4 and Counter(s['kind'] for s in rows)==Counter({'PARTIAL_REASON':2,'COMPLETE_REASON':2}),'partial/complete perbothdecisions eachcell')
 proofs=d['nativeZoomDiagnostics'];require(len(proofs)==3 and {s['locale'] for s in proofs}=={'az','ru','en'},'3nativeproofs')
 for p in proofs:
  require(p['status']=='PASS' and p['factor']==2 and p['fixture']=='exception-classification' and p['method']=='BROWSER_TABS_AUTOMATIC_PER_TAB_ZOOM','native admitted fixture')
  require(p['event']['oldFactor']==1 and p['event']['newFactor']==2 and p['event']['settings']=={'mode':'automatic','scope':'per-tab'} and p['settings']['mode']=='automatic' and p['settings']['scope']=='per-tab','Chrome event/settings')
  require(p['control']['width']==640 and p['control']['devicePixelRatio']==1 and p['zoomed']['width']==320 and p['zoomed']['devicePixelRatio']==2,'native viewport/DPR')
  require(p['viewportEmulation'] is p['applicationCssChanged'] is False and p['applicationServiceWorkers']==0,'no emulation/css/SW')
  for state in ['control','zoomed']:require(p[state]['rootZoom']==p[state]['bodyZoom']=='1' and p[state]['rootTransform']==p[state]['bodyTransform']=='none','unchanged app CSS')
 captures=d['nativeCaptureDiagnostics'];require(len(captures)==21 and len({s['screenshot'] for s in captures})==21,'21uniqueoriginalcaptures')
 captureNames=set()
 for c in captures:
  b=z.read(c['screenshot']);require(len(b)==c['original']['bytes'] and h(b)==c['original']['sha256'],'originalpnghash')
  require(b[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('>II',b[16:24])==(c['pixels']['width'],c['pixels']['height']),'originalPNGdimensions')
  require(c['status']==c['cleanup']=='PASS' and c['method']=='CDP_VISIBLE_SURFACE_NO_CLIP' and c['suppliedClip'] is False,'no clipped capture')
  require(c['before']==c['after'] and c['layoutBefore']==c['layoutAfter'] and c['pixels']==c['controlSurface'] and c['pixels']['width']==640,'capture no focus/layout/scroll mutation')
  require(c['before']['devicePixelRatio']==(1 if c['control'] else 2),'native orcontrolcapture')
  captureNames.add(c['screenshot'])
 auth=d['authenticationDiagnostics'];require(len(auth)==17 and len({s['ordinal'] for s in auth})==17,'17authenticatedprincipals')
 require(all(s['csrfStatus']==s['callbackStatus']==200 for s in auth),'all17 credential signins200')
 enrolled=[s for s in auth if s['mandatoryTotp']];weak=[s for s in auth if not s['mandatoryTotp']]
 require(len(enrolled)==16 and len(weak)==1 and weak[0]['ordinal']==13 and weak[0]['verificationStatus'] is weak[0]['sessionUpdateStatus'] is weak[0]['nonceConsumed'] is None,'intentional weak HR fixture denied403 separately')
 require(all(s['verificationStatus']==s['sessionUpdateStatus']==200 and s['nonceConsumed'] and s['verificationWarmupStatus']==405 for s in enrolled),'16actualMFAconsumednonce; warmupGET405')
 writes=d['writeDiagnostics'];manual=[s for s in writes if s['stage'].startswith(('standard-100-','native-200-')) and s['decisionCode'] is not None];require(len(manual)==24 and all(s['status']==201 and s['success'] and s['jsonObject'] for s in manual),'24actualmanualwrites201')
 db=d['database'];require(db=={'nonownerForcedRls':True,'populatedTwoTenantDecisionControls':True,'unscopedRows':0,'foreignRows':0,'actualNewDecisionCount':24,'actualAuditCount':24,'exactActorReasonAndAuditLink':True,'exactProductionDecisionImmutability':True,'syntheticAuditGuard':True},'actualforcednonownerRLS24decision+exactauditproof')
 facts=d['fixedFacts'];require(facts['phase']=='after-twenty-four-ui-appends-before-intentional-fixture-revocation' and facts['unchanged'] and len(facts['tables'])==8,'8businessfactunchanged prefixture-revocation')
 require({s['table'] for s in facts['tables']}=={'workforce_exception_cases','mtm_agents','mtm_agent_workdays','workforce_employee_team_memberships','workforce_access_grants','mtm_hrm_requests','workforce_time_corrections','workforce_exception_employee_responses'} and all(s['rows']<=100 and re.fullmatch('[a-f0-9]{64}',s['sha256']) for s in facts['tables']),'boundedfactfingerprints')
 cleanup=d['cleanupDiagnostics'];require(all(s['status']=='PASS' for s in cleanup) and {s['resource'] for s in cleanup}>={'native-profile-1','native-profile-2','native-profile-3','browser','app-prisma','admin-prisma'},'allresourcecleanupinclnative')
 images=out/'original-pngs';images.mkdir(exist_ok=True)
 members=[]
 for i in z.infolist():
  b=z.read(i.filename);members.append({'path':i.filename,'bytes':len(b),'crc32':f'{i.CRC:08x}','sha256':h(b)})
  if i.filename.endswith('.png'):
   f=images/i.filename;f.parent.mkdir(exist_ok=True,parents=True)
   if not f.exists():f.write_bytes(b)
 for unsafe in [b'PRIVATE_CLASSIF_',b'password',b'cookie',b'authorization',b'otpauth://']:
  require(unsafe.lower() not in raw.lower(),'no protectedreceipt marker '+str(unsafe))
 report={'status':'ACCEPTED_ACTUAL_BOUNDARY_MATRIX_AND_SOURCE_BINDINGS_VISUAL_REVIEW_SEPARATE','sourceHead':head,'sourceTree':tree,'baseMain':'bf643689a14bc0c2ef981270f7bc0b955b2d76b5','checkedSha':d['checkedMergeSha'],'runId':run,'attempt':1,'jobId':job,'url':ja['html_url'],'checkAppId':15368,'actualCheckoutOriginalLines':checkout,'allRequiredJobStepsSuccess':True,'failureOnlyReceiptSkippedNotCredited':True,'artifact':{'id':aid,'name':aa['name'],'bytes':len(zipraw),'sha256':h(zipraw),'apiDigestAndCrc':'PASS','path':str(out/f'original-artifact-{aid}.zip'),'members':members},'fullOriginalLog':{'bytes':len(log),'sha256':h(log),'gzipPath':str(logpath)},'originalApiFiles':[{'path':str(out/n),'bytes':len(b),'sha256':h(b)} for n,b in [('original-run-api.json',runraw),('original-job-api.json',jobraw),('original-check-api.json',checkraw),('original-artifact-api.json',araw)]],'sourceBindings':d['sources'],'exactProductionMigrationExtracts':d['productionRoutines'],'actualCases':cases,'matrixCells':12,'actualManualWrites':24,'linkedImmutableAudits':24,'keyboardChecks':108,'tableIntersections':12,'fullyBoundedControls':96,'queueRegionDiagnostics':regions,'old94PixelFailureControlCurrentActual':corrected[0],'nativeProofs':proofs,'nativeOriginalCaptureCount':21,'privateReasonRefusals':48,'rawPrivateReasonRetained':False,'database':db,'fixedFacts':facts,'cleanup':cleanup,'visualInspection':'PENDING_SEPARATE_ACTUAL_ORIGINAL_PNG_REVIEW','originalImages':str(images),'authWarmupMethodNotAllowed405NotReclassified':True,'actualEnrolledMfaPrincipals':16,'intentionalUnenrolledHrFixtureDenied403':True,'manualRetriesDistinctFromNewWrites':True,'preservedInitialReaderError':'/tmp/hrm-classification-matrix-a161-peer-reader-correction.json','limitations':d['limitations'],'findingsP0P1P2':[],'peerAuthorshipQualified':'Helper and guard authored by this reviewer; their code independently reviewed by root at SHA58aa503a7220965d1c0370a60ac4af2b7230b3d988d6eef3402c48780fcb9e14. Hosted actual evidence inspected independently.','overallRunAcceptance':'NOT_ACCEPTED_REGRESSION_FAILURE_RETAINED_COMPILER_PENDING','wholeC12C14Closed':False,'realHRProductionSessionAndHumanAT':'NOT_RUN','peerRepoProductionMutations':False}
 dest=Path('/tmp/hrm-classification-matrix-hosted-peer-review-a161.json');require(not dest.exists(),'immutable reportdest');dest.write_text(json.dumps(report,indent=2)+'\n');b=dest.read_bytes();print(json.dumps({'report':str(dest),'bytes':len(b),'sha256':h(b),'status':report['status'],'cases':20,'focus':108,'native':3,'captures':21,'writesAudits':24,'privateRefusals':48,'oldFailCurrentBounds':corrected[0]}))
