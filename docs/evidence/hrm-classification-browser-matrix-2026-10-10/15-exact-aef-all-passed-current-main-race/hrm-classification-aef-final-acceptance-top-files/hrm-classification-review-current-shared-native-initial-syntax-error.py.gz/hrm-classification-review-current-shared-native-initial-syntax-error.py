from pathlib import Path
import json,zipfile,subprocess,hashlib,struct,gzip,sys
out=Path(sys.argv[1]);kind=sys.argv[2];head=sys.argv[3];base=sys.argv[4]
assert kind in ['calendar','manager'];dest=out/'root-complete-shared-native-content-review.json';assert not dest.exists()
s=json.loads((out/'finite-capture-summary.json').read_text());assert s['headSha']==head and s['conclusion']=='success';a=s['artifacts'][0]
fixture='calendar'if kind=='calendar'else'manager-today';expectedCases=15 if kind=='calendar'else9;expectedBindings=31 if kind=='calendar'else58;expectedCaptures=33 if kind=='calendar'else27
with zipfile.ZipFile(out/f"artifact-{a['id']}-original.zip")as z:
 d=json.loads(z.read('receipt.json'if kind=='calendar'else'manager-today-receipt.json'));c=json.loads(z.read('workflow-context.json'))
 assert d['candidateHead']==c['headSha']==head and c['ciSha']==d['checkedMergeSha'] and str(c['runId'])==str(s['runId']) and c['productionMutation']is False
 commit=json.loads(subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/commits/'+d['checkedMergeSha']]));assert [p['sha']for p in commit['parents']]==[base,head]
 assert commit['commit']['tree']['sha']==subprocess.check_output(['git','rev-parse',head+'^{tree}'],text=True).strip()
 assert d['status']==d['nativeZoomVerdict']=='PASS'and len(d['cases'])==expectedCases and all(x['status']=='PASS'for x in d['cases'])
 assert len(d['sourceBindings'])==expectedBindings and len({x['path']for x in d['sourceBindings']})==expectedBindings
 for x in d['sourceBindings']:
  b=subprocess.check_output(['git','show',head+':'+x['path']]);assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256']
 assert len(d['nativeZoomDiagnostics'])==3 and {x['locale']for x in d['nativeZoomDiagnostics']}=={'az','ru','en'}
 for x in d['nativeZoomDiagnostics']:
  assert x['status']=='PASS'and x['fixture']==fixture and x['factor']==2 and x['method']=='BROWSER_TABS_AUTOMATIC_PER_TAB_ZOOM'
  assert x['event']['oldFactor']==1 and x['event']['newFactor']==2 and x['event']['settings']=={'mode':'automatic','scope':'per-tab'}
  assert x['control']['width']==640 and x['control']['devicePixelRatio']==1 and x['zoomed']['width']==320 and x['zoomed']['devicePixelRatio']==2
  assert x['viewportEmulation']is False and x['applicationCssChanged']is False and x['applicationServiceWorkers']==0
 assert len(d['nativeCaptureDiagnostics'])==expectedCaptures
 for x in d['nativeCaptureDiagnostics']:
  assert x['status']==x['cleanup']=='PASS' and x['method']=='CDP_VISIBLE_SURFACE_NO_CLIP'and x['suppliedClip']is False
  assert x['before']==x['after']and x['layoutBefore']==x['layoutAfter']and x['pixels']==x['controlSurface']
  b=z.read(x['screenshot']);assert len(b)==x['original']['bytes']and hashlib.sha256(b).hexdigest()==x['original']['sha256']and b[:8]==b'\x89PNG\r\n\x1a\n'
  assert struct.unpack('>II',b[16:24])==(x['pixels']['width'],x['pixels']['height'])
 assert all(x['status']=='PASS'for x in d['focusGeometryDiagnostics'])
 if kind=='manager':
  assert d['cleanup']==d['factImmutability']['status']=='PASS' and len(d['factImmutability']['tables'])==20 and all(x['unchanged']for x in d['factImmutability']['tables'])and all(x['status']=='PASS'for x in d['cleanupActions'])
 else:assert all(x['status']=='PASS'for x in d['nativeZoomCleanup'])and d['contrastVerdict']=='PASS'
 job=s['jobs'][0];raw=subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/check-runs/'+str(job['id'])]);check=json.loads(raw);assert check['head_sha']==head and check['app']['id']==15368 and check['conclusion']=='success';(out/'actual-check-api-original.json.gz').write_bytes(gzip.compress(raw,mtime=0))
 images=out/'original-native-pngs-for-visual-review';assert not images.exists();images.mkdir()
 for locale in ['az','ru','en']:
  n='native-zoom-'+locale+'-observed-200.png';(images/n).write_bytes(z.read(n))
 result={'status':'PASS_ACTUAL_CURRENT_CANDIDATE_SHARED_NATIVE_ARTIFACT_VISUAL_SEPARATE','kind':kind,'head':head,'base':base,'run':s['runId'],'candidate':commit['sha'],'candidateParents':[base,head],'wholeTreeMatchesFinalSource':True,'actualApp':15368,'artifact':a,'cases':expectedCases,'sourceBindings':expectedBindings,'nativeCells':3,'nativeOriginalCaptures':expectedCaptures,'focusGeometryChecks':len(d['focusGeometryDiagnostics']),'allNativePixelHashesAndLayoutInvariance':True,'cleanup':'PASS','businessFactTablesUnchanged':20 if kind=='manager'else None,'limitations':d['limitations'],'wholeC12C14Acceptance':False,'visualSamples':'PENDING_NEW_ORIGINALS'}
 dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['status','kind','cases','nativeOriginalCaptures','candidate']}))
