import os,sys,subprocess,json
from pathlib import Path
root=Path(__file__).parent;results=[]
for zoom in ['1','2']:
    for locale in ['en','ru','az']:
        code=subprocess.run(['/usr/bin/python3',str(root/'supervisor.py')],env={**os.environ,'WF_AT_LOCALE':locale,'WF_AT_ZOOM':zoom}).returncode
        run=Path((root/'latest-run.txt').read_text())
        receipt=json.loads((run/'at-receipt.json').read_text()) if (run/'at-receipt.json').exists() else {}
        row={'locale':locale,'zoom':zoom,'run':str(run),'exit':code,'status':receipt.get('status','NO_RECEIPT')};results.append(row)
        (root/'final-matrix.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'matrixCompleted':row}),flush=True)
        if code or receipt.get('status')!='ACTUAL_AT_READING_OBSERVED':sys.exit(1)
