import json,hashlib,zipfile,datetime,shutil
from pathlib import Path
root=Path(__file__).parent;work=Path('/workspace/hrm-c8-completion-20261006');audit=Path('/tmp/hrm-c8-new-isolation');evidence=work/'docs/evidence/workforce-c8-pagination-2026-10-06'
matrix=json.loads((root/'final-matrix.json').read_text());assert len(matrix)==6
manifest=json.loads((root/'source-manifest.json').read_text());assert len(manifest)==8817
for row in manifest:
    for source in [root/'source',work]:assert hashlib.sha256((source/row['path']).read_bytes()).hexdigest()==row['sha256'],str(source/row['path'])
scenarios=[]
for row in matrix:
    d=Path(row['run']);r=json.loads((d/'at-receipt.json').read_text());assert r['status']=='ACTUAL_AT_READING_OBSERVED' and len(r['assertions'])==9 and all(x['pass'] for x in r['assertions'])
    assert (d/'source-manifest.json').read_bytes()==(root/'source-manifest.json').read_bytes()
    assert json.loads((d/'executed-script-hashes-before.json').read_text())==json.loads((d/'executed-script-hashes-after.json').read_text())
    spoken=[json.loads(x) for x in (d/'orca-presentations.jsonl').read_text().splitlines()];done={json.loads(x)['time'] for x in (d/'orca-dispatch-completed.jsonl').read_text().splitlines()};assert all(x['time'] in done for x in spoken)
    cleanup=json.loads((d/'cleanup.json').read_text());assert len(cleanup)==7 and all(isinstance(x['exit'],int) for x in cleanup)
    if row['zoom']=='2':assert r['nativeZoom']['factor']==2 and r['nativeZoom']['after']['scale']==1
    scenarios.append({'locale':row['locale'],'zoom':int(row['zoom']),'run':d.name,'checks':r['assertions'],'actualSpeechEvents':len(spoken),'allDispatchesReturned':True,'focus':r['pagination']['retainedControl'],'automaticResultSpeech':[x['text'] for x in r['pagination']['automaticResultSpeech']],'nativeZoom':r.get('nativeZoom'),'ownChildrenReaped':len(cleanup)})
old=Path('/tmp/hrm-c8-isolated-at-c4kelii3/c8-isolated-orca-receipts.zip');assert hashlib.sha256(old.read_bytes()).hexdigest()=='c199f0f6328c6e774fef6af4933e6b1044bfbc7111e1e21eafd10eefea2fa6c7';assert (evidence/'prior-orca-178-files.zip').read_bytes()==old.read_bytes()
summary={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_BOUNDED_C8_PAGINATION_AND_SCOPE_CANDIDATE_NOT_WHOLE_C8','checksPassed':54,'scenarios':scenarios,'totalActualSpeechEvents':sum(x['actualSpeechEvents'] for x in scenarios),'sourceManifestSha256':hashlib.sha256((root/'source-manifest.json').read_bytes()).hexdigest(),'sourceCount':8817,'workingAndRuntimeSourceMatch':True,'incidentalTsconfigExcluded':True,'auth':'actual CSRF/credentials/session; scoped non-superuser synthetic fixture','AT':'Chromium151 -> real AT-SPI -> Orca48.1 -> real speech-dispatcher/espeak-ng; observation calls original speak unchanged','audio':'ALSA null; no human listening, pronunciation or audio recording claim','isolation':'private D-Bus/Xvfb displayfd/Xauthority/XDG/profile each run, retained owned child handles only','prior178ArchiveSha256':hashlib.sha256(old.read_bytes()).hexdigest(),'negativeHistory':['initial independent8PASS2FAIL; counts corrected then independent14PASS','first fixed AT retainedfocus outsideviewport; conditional nearest scroll correction','run-xj34tq0s excluded from final proof because copying had not reported completion before launch','full local TypeScript diagnostics blocked by default4GiB Node heap OOM'],'limits':['Development bundle, not production build','Synthetic seeded work-time facts, not accepted physical START or presence','Real denied-session and same-page live-session transition AT not run here','No whole-page WCAG/contrast/Android/physical/load/pilot acceptance','No new exact-head hosted build or full CI acceptance at this checkpoint','No merge/deploy/production activation'],'ledger':'WF-C8-002 PARTIAL;83/161DONE,78open,weighted60% unchanged'}
(root/'fixed-at-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(evidence/'actual-orca-summary.json').write_bytes((root/'fixed-at-summary.json').read_bytes())
allow=['at-receipt.json','supervisor-events.json','cleanup.json','orca-presentations.jsonl','orca-dispatch-completed.jsonl','executed-script-hashes-before.json','executed-script-hashes-after.json','source-manifest.json','safe-error-categories.json','orca-own-thread-stacks.json','backend-check.json','app-ready.json','app-failure.json','source-freeze-disqualification.json']
files=[]
for d in sorted(root.glob('run-*')):
    if not d.is_dir():continue
    for name in allow:
        if (d/name).is_file():files.append(d/name)
    files.extend(p for p in (d/'changed-source-snapshots').rglob('*') if p.is_file())
for name in ['source-manifest.json','probe-origin.json','fixture-adaptation.json','final-source-freeze-check.json','final-matrix.json','fixed-at-summary.json','supervisor.py','observer.py','probe.mjs','next.cjs','backend-check.py','inspect-atspi.py','run-final-matrix.py','finalize-fixed.py']:
    files.append(root/name)
files.append(root/'source/scripts/c8-local-fixture.mjs')
entries=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files];(root/'fixed-receipt-manifest.json').write_text(json.dumps(entries,indent=2)+'\n');files.append(root/'fixed-receipt-manifest.json')
archive=evidence/'fixed-orca-receipts.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.relative_to(root))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in entries:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
proof={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files),'allMembersReadBackAndHashed':True,'old178ArchiveUnchanged':True};(audit/'fixed-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'checks':54,'speechEvents':summary['totalActualSpeechEvents'],**proof},indent=2))
