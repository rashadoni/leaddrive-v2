import os,json,time,runpy,sys,threading,traceback
from pathlib import Path
from orca import orca,speech,orca_platform,speechdispatcherfactory
orca_platform.datadir=os.environ['WF_AT_PREFIX']+'/usr/share'
orca_platform.tablesdir=os.environ['WF_AT_PREFIX']+'/usr/share/liblouis/tables'
target=Path(os.environ['WF_AT_OUTPUT'])/'orca-presentations.jsonl'
original=speechdispatcherfactory.SpeechServer.speak
def observed(self,text=None,acss=None,interrupt=True):
    stamp=time.monotonic()
    if text:
        with target.open('a') as f:f.write(json.dumps({'time':stamp,'text':text,'origin':'actual Orca SpeechServer.speak','server':self._id},ensure_ascii=False)+'\n')
    result=original(self,text,acss,interrupt)
    with (target.parent/'orca-dispatch-completed.jsonl').open('a') as f:f.write(json.dumps({'time':stamp,'completed':True})+'\n')
    return result
speechdispatcherfactory.SpeechServer.speak=observed
def own_diagnostic():
    frames={str(k):[{'file':Path(x.filename).name,'function':x.name,'line':x.lineno} for x in traceback.extract_stack(v)] for k,v in sys._current_frames().items()}
    (target.parent/'orca-own-thread-stacks.json').write_text(json.dumps(frames,indent=2))
    timer=threading.Timer(5,own_diagnostic);timer.daemon=True;timer.start()
own_diagnostic()
runpy.run_path(os.environ['WF_AT_PREFIX']+'/usr/bin/orca',run_name='__main__')
