import os,sys,json,time,subprocess,tempfile,socket,secrets,hashlib,select
from pathlib import Path
root=Path(__file__).parent;prefix=Path('/tmp/hrm-c8-at-stack/prefix')
if '--inner' not in sys.argv:
    run=Path(tempfile.mkdtemp(prefix='run-',dir=root));os.chmod(run,0o700)
    env={**os.environ,'WF_AT_ROOT':str(root),'WF_AT_OUTPUT':str(run),'WF_AT_PREFIX':str(prefix),'WF_LOCAL_C8_AT':'1','GITHUB_ACTIONS':'false','CI':'false','NODE_ENV':'development'}
    for key,sub in [('XDG_RUNTIME_DIR','runtime'),('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_DATA_HOME','data')]:
        (run/sub).mkdir(mode=0o700);env[key]=str(run/sub)
    env.update({'LD_LIBRARY_PATH':str(prefix/'usr/lib/x86_64-linux-gnu'),'GI_TYPELIB_PATH':str(prefix/'usr/lib/x86_64-linux-gnu/girepository-1.0'),'PYTHONPATH':str(prefix/'usr/lib/python3/dist-packages'),'XDG_DATA_DIRS':str(prefix/'usr/share')+':/usr/share','GSETTINGS_BACKEND':'memory','NO_AT_BRIDGE':'0','GTK_MODULES':str(prefix/'usr/lib/x86_64-linux-gnu/gtk-2.0/modules/libatk-bridge.so'),'ESPEAK_DATA_PATH':str(prefix/'usr/lib/x86_64-linux-gnu/espeak-ng-data'),'PATH':str(prefix/'usr/bin')+':'+os.environ['PATH'],'NEXT_TELEMETRY_DISABLED':'1'})
    for key in ['DISPLAY','WAYLAND_DISPLAY','DBUS_SESSION_BUS_ADDRESS','DBUS_STARTER_ADDRESS']:env.pop(key,None)
    db=json.load(open('/tmp/hrm-c8-db-env.json'))
    for key in ['ADMIN_DATABASE_URL','DATABASE_URL','DIRECT_URL','EVENT_PLATFORM_TEST_DATABASE_URL','NEXTAUTH_SECRET','AUTH_SECRET','TENANT_PII_MASTER_KEY','AUTH_TRUST_HOST']:
        if key in db:env[key]=db[key]
    env['EVENT_PLATFORM_TEST_DATABASE_URL']=env['ADMIN_DATABASE_URL']
    s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close();env['WF_AT_PORT']=str(port)
    for key in ['NEXTAUTH_URL','AUTH_URL','APP_URL','WF_MANAGER_TODAY_BROWSER_BASE_URL']:env[key]='http://localhost:'+str(port)
    files=[p for p in root.iterdir() if p.suffix in ['.py','.mjs','.cjs']]+[root/'source/scripts/c8-local-fixture.mjs']
    (run/'executed-script-hashes-before.json').write_text(json.dumps({str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
    (run/'source-manifest.json').write_bytes((root/'source-manifest.json').read_bytes())
    (root/'latest-run.txt').write_text(str(run))
    print(json.dumps({'event':'START','run':str(run),'port':port}),flush=True)
    r=subprocess.run(['dbus-run-session','--','/usr/bin/python3',str(root/'supervisor.py'),'--inner'],env=env,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True)
    print(r.stdout[-5000:],flush=True)
    (run/'executed-script-hashes-after.json').write_text(json.dumps({str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
    sys.exit(r.returncode)
env=dict(os.environ);run=Path(env['WF_AT_OUTPUT']);procs=[];events=[]
env['SPEECHD_PLUGIN_DIR']=str(prefix/'usr/lib/x86_64-linux-gnu/speech-dispatcher')
def event(stage,**kwargs):
    item={'stage':stage,'at':time.time(),**kwargs};events.append(item);(run/'supervisor-events.json').write_text(json.dumps(events,indent=2));print(json.dumps(item),flush=True)
def start(label,args,**kwargs):
    p=subprocess.Popen(args,env=env,cwd=root/'source',stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,**kwargs);procs.append((label,p));return p
def alive_wait(p,seconds):
    until=time.monotonic()+seconds
    while time.monotonic()<until:
        assert p.poll() is None,'OWN_CHILD_EXIT_'+str(p.returncode);time.sleep(.1)
try:
    auth=run/'xauthority';cookie=secrets.token_hex(16);env['XAUTHORITY']=str(auth)
    subprocess.run(['xauth','-f',str(auth),'add',':0','.',cookie],env=env,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    r,w=os.pipe();x=start('xvfb',[str(prefix/'usr/bin/Xvfb'),'-displayfd',str(w),'-screen','0','1440x1000x24','-nolisten','tcp','-auth',str(auth)],pass_fds=(w,));os.close(w)
    assert select.select([r],[],[],10)[0],'XVFB_DISPLAYFD_TIMEOUT'
    display=os.read(r,64).decode().strip();os.close(r);assert display.isdigit(),'INVALID_DISPLAYFD'
    env['DISPLAY']=':'+display
    subprocess.run(['xauth','-f',str(auth),'add',env['DISPLAY'],'.',cookie],env=env,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    # Update only this dbus-run-session bus so its AT-SPI service sees our new display.
    subprocess.run(['dbus-update-activation-environment','DISPLAY','XAUTHORITY','XDG_RUNTIME_DIR','XDG_CONFIG_HOME'],env=env,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    alive_wait(x,.5);wm=start('window-manager',['/usr/bin/xfwm4','--sm-client-disable','--compositor=off']);alive_wait(wm,1)
    cfg=run/'speech';cfg.mkdir();(cfg/'speechd.conf').write_text('LogLevel 0\nLogDir "'+str(run)+'"\nDefaultModule espeak-ng\nAudioOutputMethod "alsa"\nAudioALSADevice "null"\nAddModule "espeak-ng" "'+str(prefix/'usr/lib/speech-dispatcher-modules/sd_espeak-ng')+'" "'+str(prefix/'etc/speech-dispatcher/modules/espeak-ng.conf')+'"\n')
    sock=str(run/'speech.sock');env['SPEECHD_ADDRESS']='unix_socket:'+sock
    sd=start('speech-dispatcher',[str(prefix/'usr/bin/speech-dispatcher'),'-s','-C',str(cfg),'-S',sock,'-P',str(run/'speech.pid'),'-m',str(prefix/'usr/lib/speech-dispatcher-modules'),'-t','0']);alive_wait(sd,1)
    backend=start('speech-backend-check',['/usr/bin/python3',str(root/'backend-check.py')]);assert backend.wait(timeout=20)==0,'BACKEND_CHECK_EXIT'
    event('PRIVATE_AT_STACK_READY',display=env['DISPLAY'])
    if not (root/'fixture-private.json').exists():
        fixture=start('fixture',['node',str(root/'source/scripts/c8-local-fixture.mjs')]);code=fixture.wait(timeout=90);assert code==0,'FIXTURE_EXIT_'+str(code)
    event('SYNTHETIC_FIXTURE_READY')
    app=start('next',['node',str(root/'next.cjs')]);deadline=time.monotonic()+120
    while not (run/'app-ready.json').exists():
        assert app.poll() is None,'NEXT_EXIT_'+str(app.returncode);assert time.monotonic()<deadline,'NEXT_READY_TIMEOUT';time.sleep(.2)
    event('FROZEN_COPY_APP_READY')
    orca=start('orca',['/usr/bin/python3',str(root/'observer.py'),'--user-prefs',str(run/'orca'),'--disable','braille,sound']);alive_wait(orca,3)
    probe=start('browser-probe',['node',str(root/'probe.mjs')]);code=probe.wait(timeout=240)
    event('PROBE_FINISHED',exit=code,orcaAlive=orca.poll() is None)
    assert code==0,'PROBE_EXIT_'+str(code)
except Exception as e:
    event('FAIL',errorType=type(e).__name__,detail=str(e) if isinstance(e,AssertionError) else 'setup or owned child operation failed')
    sys.exitcode=1
finally:
    cleanup=[]
    for label,p in reversed(procs):
        if p.poll() is None:p.terminate()
        try:p.wait(timeout=8)
        except subprocess.TimeoutExpired:p.kill();p.wait(timeout=5)
        cleanup.append({'label':label,'pid':p.pid,'exit':p.returncode,'ownership':'retained Popen handle created by this supervisor'})
    (run/'cleanup.json').write_text(json.dumps(cleanup,indent=2));event('OWN_CHILDREN_REAPED',count=len(cleanup))
sys.exit(getattr(sys,'exitcode',0))
