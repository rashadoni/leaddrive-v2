import gi,json
gi.require_version('Atspi','2.0')
from gi.repository import Atspi
rows=[]
def visit(node,depth=0):
    if len(rows)>=1800 or depth>35:return
    try:
        node.clear_cache();role=node.get_role_name();name=node.get_name();count=node.get_child_count()
        rows.append({'depth':depth,'role':role,'name':name,'focused':node.get_state_set().contains(Atspi.StateType.FOCUSED),'children':count})
        for i in range(min(count,60)):visit(node.get_child_at_index(i),depth+1)
    except Exception:pass
visit(Atspi.get_desktop(0));print(json.dumps(rows,ensure_ascii=False))
