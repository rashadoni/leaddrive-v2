import assert from 'node:assert/strict';
import {randomUUID,createHash} from 'node:crypto';
import {writeFile} from 'node:fs/promises';
import {createJiti} from 'jiti';
import bcrypt from 'bcryptjs';
import {makeRlsTestPrisma} from './_rls.mjs';
assert.equal(process.env.WF_LOCAL_C8_AT,'1');
assert.notEqual(process.env.NODE_ENV,'production');
assert.notEqual(process.env.GITHUB_ACTIONS,'true');
const target=new URL(process.env.ADMIN_DATABASE_URL);
assert.equal(target.protocol,'postgresql:');assert.equal(target.hostname,'127.0.0.1');assert.equal(target.port,'55439');
assert.equal(target.pathname,'/workforce_manager_today_browser');assert.equal(target.username,'postgres');
assert.equal(process.env.EVENT_PLATFORM_TEST_DATABASE_URL,process.env.ADMIN_DATABASE_URL);
const admin=makeRlsTestPrisma(target.href);
const suffix=randomUUID().replaceAll('-','').slice(0,12),password=`Fixture!9a-${randomUUID()}`;
const date=new Date().toISOString().slice(0,10),workDate=new Date(`${date}T00:00:00.000Z`);
const earlier=days=>new Date(workDate.getTime()-days*86400000);
const currentDate=()=>assert.equal(new Date().toISOString().slice(0,10),date);
const receipts={environment:'isolated cloud Linux; local disposable fixture; not GitHub Actions',date};
const factTables = [
  "mtm_teams", "mtm_agents", "mtm_settings", "mtm_work_calendar_days", "workforce_policies",
  "workforce_employee_team_memberships", "mtm_agent_workdays", "mtm_agent_workday_events",
  "workforce_access_grants", "workforce_access_grant_revocations",
  "workforce_shift_templates", "workforce_shift_segments", "workforce_shift_assignments",
  "workforce_shift_default_assignments", "workforce_shift_team_default_assignments",
  "workforce_policy_snapshots", "workforce_shift_snapshots", "workforce_workday_schedule_snapshots",
  "workforce_exception_cases", "workforce_exception_decisions",
]
async function facts(organizationIds) {
  const result = []
  for (const table of factTables) {
    assert.match(table, /^[a-z_]+$/)
    // Identifiers are fixed above; only synthetic tenant ids are parameters.
    const rows = await admin.$queryRawUnsafe(`SELECT row_to_json(fact) AS document FROM public."${table}" AS fact WHERE "organizationId" IN ($1, $2) ORDER BY id LIMIT 501`, ...organizationIds)
    assert.ok(rows.length <= 500, "Fixture fact snapshot must remain bounded")
    result.push({ table, count: rows.length, sha256: createHash("sha256").update(JSON.stringify(rows.map(row => row.document))).digest("hex") })
  }
  return result
}
async function seedCurrentSnapshotWorkdays({ organization, issuer, employees, template, jiti }) {
  const { workforcePolicyDefinitionHash } = await jiti.import("../src/lib/workforce/policy-definition.ts")
  const { writeWorkforceSnapshotsInTransaction } = await jiti.import("../src/lib/workforce/snapshot-writer.ts")
  const { verifyWorkforceTimesheetScheduleSnapshot } = await jiti.import("../src/lib/workforce/timesheet-schedule-snapshot.ts")
  const definition = { expectedWorkSeconds: 28_800, lateGraceSeconds: 0, undertimeToleranceSeconds: 0, overtimeThresholdSeconds: 0, longPauseThresholdSeconds: null }
  const policy = await admin.workforcePolicy.create({ data: {
    organizationId: organization.id, teamId: null, version: 1, status: "ACTIVE",
    name: "Today disposable calculation fixture", effectiveFrom: earlier(2), effectiveTo: null,
    definition, definitionHash: workforcePolicyDefinitionHash(definition), provenance: "TENANT_ADMIN",
    createdByUserId: issuer.id, activatedByUserId: issuer.id, activatedAt: earlier(2), createdAt: earlier(3),
  } })
  const startedAt = new Date(Math.max(workDate.getTime(), Date.now() - 300_000))
  const stateAt = new Date()
  const currentWorkdays = new Map()
  const proofs = []
  for (const [offset, status] of ["STARTED", "PAUSED", "COMPLETED"].entries()) {
    currentDate()
    const employee = employees[6 + offset]
    const created = await admin.$transaction(async tx => {
      const workday = await tx.mtmAgentWorkday.create({ data: {
        organizationId: organization.id, agentId: employee.id, workDate, status, startedAt,
        pausedAt: status === "PAUSED" ? stateAt : null,
        completedAt: status === "COMPLETED" ? stateAt : null, totalPausedSeconds: 0,
      } })
      // Pass the fenced admin transaction. The global application client is
      // intentionally read-only and must never be used for fixture seeding.
      const snapshot = await writeWorkforceSnapshotsInTransaction(tx, {
        organizationId: organization.id, workdayId: workday.id, resolutionAt: stateAt,
      })
      assert.equal(snapshot.kind, "created")
      const replay = await writeWorkforceSnapshotsInTransaction(tx, {
        organizationId: organization.id, workdayId: workday.id, resolutionAt: stateAt,
      })
      assert.deepEqual(replay, { ...snapshot, kind: "already_present" })
      const [policySnapshot, shiftSnapshot, scheduleSnapshot, membership] = await Promise.all([
        tx.workforcePolicySnapshot.findUniqueOrThrow({ where: { id: snapshot.policySnapshotId } }),
        tx.workforceShiftSnapshot.findUniqueOrThrow({ where: { id: snapshot.shiftSnapshotId } }),
        tx.workforceWorkdayScheduleSnapshot.findUniqueOrThrow({ where: { id: snapshot.scheduleSnapshotId } }),
        tx.workforceEmployeeTeamMembership.findFirstOrThrow({ where: { organizationId: organization.id, agentId: employee.id, effectiveAt: { lte: workday.startedAt } }, orderBy: [{ effectiveAt: "desc" }, { id: "desc" }] }),
      ])
      assert.equal(policySnapshot.policyId, policy.id)
      assert.equal(shiftSnapshot.templateId, template.id)
      for (const row of [policySnapshot, shiftSnapshot, scheduleSnapshot]) {
        assert.equal(row.organizationId, organization.id)
        assert.equal(row.workdayId, workday.id)
        assert.equal(row.agentId, employee.id)
        assert.equal(row.workDate.toISOString(), workDate.toISOString())
      }
      assert.equal(scheduleSnapshot.schemaVersion, 2)
      assert.deepEqual(scheduleSnapshot.calendarSnapshot.teamMembership, { id: membership.id, teamId: membership.teamId })
      assert.equal(shiftSnapshot.plannedStartAt.toISOString(), `${date}T00:00:00.000Z`)
      assert.equal(shiftSnapshot.plannedEndAt.toISOString(), `${date}T23:59:00.000Z`)
      const verified = verifyWorkforceTimesheetScheduleSnapshot({
        snapshot: scheduleSnapshot, workDate: date, policySnapshotId: policySnapshot.id,
        policyDefinitionHash: policySnapshot.definitionHash, shiftSnapshotId: shiftSnapshot.id,
        shiftDefinitionHash: shiftSnapshot.definitionHash, shiftDefinition: shiftSnapshot.definition,
      })
      assert.equal(verified.scheduleSnapshotId, scheduleSnapshot.id)
      assert.equal(verified.calendarState, "SCHEDULED")
      assert.equal(verified.segmentCount, 1)
      assert.deepEqual(verified.segmentModes, ["REMOTE"])
      return { workday, snapshot, shiftSnapshot }
    }, { maxWait: 5_000, timeout: 30_000 })
    currentWorkdays.set(employee.id, {
      status, workday: { id: created.workday.id, startedAt: created.workday.startedAt.toISOString(), pausedAt: created.workday.pausedAt?.toISOString() ?? null, completedAt: created.workday.completedAt?.toISOString() ?? null },
      plan: { state: "ASSIGNED", source: "IMMUTABLE_WORKDAY_SNAPSHOT", templateName: template.name, timezone: "UTC", plannedStartAt: created.shiftSnapshot.plannedStartAt.toISOString(), plannedEndAt: created.shiftSnapshot.plannedEndAt.toISOString() },
      snapshotIds: created.snapshot,
    })
    proofs.push({ ordinal: offset + 1, status, sourceHelperCreatedTriplet: true, replayAlreadyPresent: true, schemaVersion: 2, historicalMembershipLinked: true, canonicalScheduleHashVerified: true, frozenUtcPlanVerified: true, remoteSegmentCount: 1 })
  }
  receipts.positiveCurrentSnapshots = {
    status: "PASS", states: proofs, adminFixtureSeedOnly: true,
    actualAcceptedStartEventWorkflowTested: false, physicalPresenceInferred: false,
    historicalTemplateDisplayNameImmutabilityTested: false,
  }
  currentDate()
  return currentWorkdays
}

async function seedSnapshotlessCurrentWorkday({ organization, employees, template }) {
  currentDate()
  const employee = employees[9]
  const startedAt = new Date(Math.max(workDate.getTime(), Date.now() - 300_000))
  const workday = await admin.$transaction(async tx => {
    const assignment = await tx.workforceShiftAssignment.findFirstOrThrow({ where: {
      organizationId: organization.id, agentId: employee.id, templateId: template.id,
      effectiveFrom: { lte: workDate }, effectiveTo: null,
    } })
    assert.equal(assignment.templateId, template.id)
    // Deliberately omit the snapshot writer. An existing synthetic workday
    // must never acquire a reconstructed plan from this live assignment.
    const created = await tx.mtmAgentWorkday.create({ data: {
      organizationId: organization.id, agentId: employee.id, workDate,
      status: "STARTED", startedAt, totalPausedSeconds: 0,
    } })
    for (const delegate of [tx.workforcePolicySnapshot, tx.workforceShiftSnapshot, tx.workforceWorkdayScheduleSnapshot]) {
      assert.equal(await delegate.count({ where: { organizationId: organization.id, workdayId: created.id } }), 0)
    }
    return created
  }, { maxWait: 5_000, timeout: 30_000 })
  receipts.missingCurrentSnapshot = {
    status: "PASS", syntheticStartedWorkday: true, currentPublishedAssignmentExists: true,
    allThreeSnapshotRowsAbsent: true, actualAcceptedStartEventWorkflowTested: false,
    physicalPresenceInferred: false, adminFixtureSeedOnly: true,
  }
  currentDate()
  return { employeeId: employee.id, workday: {
    id: workday.id, startedAt: workday.startedAt.toISOString(), pausedAt: null, completedAt: null,
  } }
}

async function proveCurrentSnapshotDatabaseGuards(fixture) {
  const organizationId = fixture.organization.id
  const organizationIds = [organizationId, fixture.foreign.id]
  const before = await facts(organizationIds)
  const reference = fixture.currentWorkdays.get(fixture.employees[6].id)
  const snapshotTables = [
    ["workforce_policy_snapshots", reference.snapshotIds.policySnapshotId],
    ["workforce_shift_snapshots", reference.snapshotIds.shiftSnapshotId],
    ["workforce_workday_schedule_snapshots", reference.snapshotIds.scheduleSnapshotId],
  ]
  const counts = before.filter(row => snapshotTables.some(([table]) => table === row.table))
  assert.equal(counts.length, 3)
  assert.ok(counts.every(row => row.count === 3))
  const workdaysBefore = before.find(row => row.table === "mtm_agent_workdays").count
  assert.equal(workdaysBefore, 5)
  const results = []
  async function rejectsAndRollsBack(name, code, attempt) {
    currentDate()
    let staged = false
    let postgresCode
    try {
      await admin.$transaction(async tx => {
        // This separate, vacant employee/date is inserted first in every
        // negative transaction. The following database error must roll it back.
        const workday = await tx.mtmAgentWorkday.create({ data: {
          organizationId, agentId: fixture.employees[10].id, workDate,
          status: "STARTED", startedAt: new Date(), totalPausedSeconds: 0,
        } })
        assert.equal(await tx.mtmAgentWorkday.count({ where: { organizationId } }), workdaysBefore + 1)
        staged = true
        await attempt(tx, workday)
      }, { maxWait: 5_000, timeout: 30_000 })
    } catch (error) {
      if (error?.code !== "P2010") throw error
      postgresCode = error.meta?.code
    }
    assert.equal(staged, true)
    assert.equal(postgresCode, code)
    const after = await facts(organizationIds)
    assert.deepEqual(after, before, "Snapshot guard rejection must roll back every captured fixture fact")
    results.push({ name, status: "PASS", postgresCode, stagedFactCreatedBeforeError: true, stagedWorkdayCount: workdaysBefore + 1, committedWorkdayCountAfter: workdaysBefore, allFactHashesAndCountsRestored: true })
  }
  for (const [table, id] of snapshotTables) {
    assert.ok(["workforce_policy_snapshots", "workforce_shift_snapshots", "workforce_workday_schedule_snapshots"].includes(table))
    await rejectsAndRollsBack(`${table}-UPDATE`, "55000", tx => tx.$executeRawUnsafe(`UPDATE public."${table}" SET "resolvedAt" = "resolvedAt" WHERE "organizationId" = $1 AND id = $2`, organizationId, id))
    await rejectsAndRollsBack(`${table}-DELETE`, "55000", tx => tx.$executeRawUnsafe(`DELETE FROM public."${table}" WHERE "organizationId" = $1 AND id = $2`, organizationId, id))
  }
  await rejectsAndRollsBack("policy-workday-employee-link", "23514", (tx, staged) => tx.$executeRawUnsafe(
    `INSERT INTO public.workforce_policy_snapshots (id,"organizationId","policyId","workdayId","agentId","workDate","policyVersion",definition,"definitionHash","expectedWorkSeconds","lateGraceSeconds","undertimeToleranceSeconds","overtimeThresholdSeconds","longPauseThresholdSeconds","resolvedAt","createdAt") SELECT $1,"organizationId","policyId",$2,"agentId","workDate","policyVersion",definition,"definitionHash","expectedWorkSeconds","lateGraceSeconds","undertimeToleranceSeconds","overtimeThresholdSeconds","longPauseThresholdSeconds","resolvedAt","createdAt" FROM public.workforce_policy_snapshots WHERE "organizationId"=$3 AND id=$4`,
    randomUUID(), staged.id, organizationId, reference.snapshotIds.policySnapshotId,
  ))
  await rejectsAndRollsBack("shift-workday-employee-link", "23514", (tx, staged) => tx.$executeRawUnsafe(
    `INSERT INTO public.workforce_shift_snapshots (id,"organizationId","templateId","assignmentId","defaultAssignmentId","teamDefaultAssignmentId","workdayId","agentId","workDate","templateVersion",timezone,definition,"definitionHash","plannedStartAt","plannedEndAt","resolvedAt","createdAt") SELECT $1,"organizationId","templateId","assignmentId","defaultAssignmentId","teamDefaultAssignmentId",$2,"agentId","workDate","templateVersion",timezone,definition,"definitionHash","plannedStartAt","plannedEndAt","resolvedAt","createdAt" FROM public.workforce_shift_snapshots WHERE "organizationId"=$3 AND id=$4`,
    randomUUID(), staged.id, organizationId, reference.snapshotIds.shiftSnapshotId,
  ))
  await rejectsAndRollsBack("schedule-cross-workday-snapshot-links", "23514", (tx, staged) => tx.$executeRawUnsafe(
    `INSERT INTO public.workforce_workday_schedule_snapshots (id,"organizationId","workdayId","agentId","workDate","policySnapshotId","shiftSnapshotId","schemaVersion","calendarState","calendarSnapshot",segments,sites,"snapshotHash","resolvedAt","createdAt") SELECT $1,"organizationId",$2,$3,"workDate","policySnapshotId","shiftSnapshotId","schemaVersion","calendarState","calendarSnapshot",segments,sites,"snapshotHash","resolvedAt","createdAt" FROM public.workforce_workday_schedule_snapshots WHERE "organizationId"=$4 AND id=$5`,
    randomUUID(), staged.id, staged.agentId, organizationId, reference.snapshotIds.scheduleSnapshotId,
  ))
  await rejectsAndRollsBack("schedule-v2-historical-membership", "23514", tx => tx.$executeRawUnsafe(
    `INSERT INTO public.workforce_workday_schedule_snapshots (id,"organizationId","workdayId","agentId","workDate","policySnapshotId","shiftSnapshotId","schemaVersion","calendarState","calendarSnapshot",segments,sites,"snapshotHash","resolvedAt","createdAt") SELECT $1,"organizationId","workdayId","agentId","workDate","policySnapshotId","shiftSnapshotId","schemaVersion","calendarState",jsonb_set("calendarSnapshot",'{teamMembership}','{"id":null,"teamId":null}'::jsonb,false),segments,sites,"snapshotHash","resolvedAt","createdAt" FROM public.workforce_workday_schedule_snapshots WHERE "organizationId"=$2 AND id=$3`,
    randomUUID(), organizationId, reference.snapshotIds.scheduleSnapshotId,
  ))
  assert.equal(results.length, 10)
  receipts.snapshotDatabaseGuards = { status: "PASS", role: "postgres", disposableAdminTransactionsOnly: true, productionMigrationsChanged: false, appWritePrivilegesAdded: false, exactNamedGuardScopeOnly: true, results }
}

async function seed() {
  currentDate()
  const passwordHash = await bcrypt.hash(password, 4)
  const organizations = []
  for (const key of ["a", "b"]) organizations.push(await admin.organization.create({ data: {
    name: `Today browser fixture ${key}`, slug: `wf-today-${suffix}-${key}`, plan: "enterprise",
    modules: { "workforce-hrm": true }, features: ["workforce-hrm", "workforce-granular-access-v1"], settings: {},
  } }))
  const [organization, foreign] = organizations
  const people = []
  for (const [key, role] of [["issuer", "admin"], ["manager", "manager"], ["approver", "manager"], ["denied", "manager"]]) {
    const user = await admin.user.create({ data: {
      organizationId: organization.id, email: `today-${suffix}-${key}@example.test`,
      name: `Today fixture ${key}`, passwordHash, role, require2fa: false, totpEnabled: false, smsAuthEnabled: false, preferredLanguage: "en",
    } })
    people.push({ ...user, key, slug: organization.slug })
  }
  const [issuer, manager, approver, denied] = people
  const team = await admin.mtmTeam.create({ data: { organizationId: organization.id, name: "Today authorized team", code: `TODAY-A-${suffix}`, isActive: true } })
  const otherTeam = await admin.mtmTeam.create({ data: { organizationId: organization.id, name: "Today out-of-scope team", code: `TODAY-B-${suffix}`, isActive: true } })
  const foreignTeam = await admin.mtmTeam.create({ data: { organizationId: foreign.id, name: "Today foreign team", code: `TODAY-F-${suffix}`, isActive: true } })
  await admin.mtmSetting.create({ data: { organizationId: organization.id, key: "timezone", value: "UTC" } })
  const employees = []
  for (let ordinal = 1; ordinal <= 26; ordinal++) {
    const number = String(ordinal).padStart(3, "0")
    employees.push(await admin.mtmAgent.create({ data: {
      id: `wf_today_${suffix}_${number}`, organizationId: organization.id, teamId: team.id,
      name: `Today Employee ${String(ordinal).padStart(2, "0")}`, role: "AGENT", status: "ACTIVE", userId: null,
    } }))
  }
  const sentinels = []
  for (const [key, org, selectedTeam, status] of [["inactive", organization, team, "INACTIVE"], ["outscope", organization, otherTeam, "ACTIVE"], ["foreign", foreign, foreignTeam, "ACTIVE"]]) {
    sentinels.push(await admin.mtmAgent.create({ data: {
      id: `wf_today_${suffix}_000_${key}`, organizationId: org.id, teamId: selectedTeam.id,
      name: `EXCLUDED ${key} fixture ${suffix}`, role: "AGENT", status, userId: null,
    } }))
  }
  for (const [principal, role] of [[manager, "TEAM_MANAGER"], [approver, "TIME_APPROVER"]]) {
    await admin.workforceAccessGrant.create({ data: {
      organizationId: organization.id, principalUserId: principal.id, role, scopeKind: "TEAM", scopeTeamId: team.id,
      scopeSiteId: null, scopeAgentId: null, effectiveFrom: earlier(2), effectiveUntil: null,
      operationId: `today-${suffix}-${principal.key}`, grantedByUserId: issuer.id, grantReasonCode: "BROWSER_FIXTURE_ONLY",
    } })
  }
  const jiti = createJiti(import.meta.url, { alias: { "@": new URL("../src", import.meta.url).pathname } })
  const { workforceShiftDefinitionHash } = await jiti.import("../src/lib/workforce/shift-definition.ts")
  const { createWorkforceExceptionCaseDraft } = await jiti.import("../src/lib/workforce/exception-case-ledger.ts")
  const definition = { startTime: "00:00", endTime: "23:59", timezone: "UTC", daysOfWeek: [1, 2, 3, 4, 5, 6, 7] }
  const template = await admin.workforceShiftTemplate.create({ data: {
    organizationId: organization.id, teamId: null, code: `TODAY-${suffix}`, isDefault: false, version: 1,
    status: "DRAFT", name: "Today published UTC fixture", timezone: "UTC", definition,
    definitionHash: workforceShiftDefinitionHash(definition), provenance: "TENANT_ADMIN", createdByUserId: issuer.id, createdAt: earlier(3),
  } })
  const segment = await admin.workforceShiftSegment.create({ data: {
    organizationId: organization.id, templateId: template.id, sequence: 1, mode: "REMOTE", siteId: null,
    startTime: "00:00", endTime: "23:59", lateGraceSeconds: 0,
  } })
  await admin.workforceShiftTemplate.update({ where: { id: template.id }, data: { status: "ACTIVE", activatedByUserId: issuer.id, activatedAt: earlier(2) } })
  for (const [index, employee] of employees.entries()) {
    await admin.workforceEmployeeTeamMembership.create({ data: { organizationId: organization.id, agentId: employee.id, teamId: team.id, effectiveAt: earlier(2), source: "BROWSER_FIXTURE_BASELINE" } })
    if (index !== 4) await admin.workforceShiftAssignment.create({ data: { organizationId: organization.id, agentId: employee.id, templateId: template.id, effectiveFrom: earlier(2), effectiveTo: null, assignedByUserId: issuer.id } })
  }
  await admin.mtmWorkCalendarDay.create({ data: { organizationId: organization.id, date: workDate, kind: "EXCEPTION_WORKDAY", source: "ADMIN", name: "Today fixture working date", teamId: null, agentId: null } })
  for (const [index, kind, source] of [[3, "COMPANY_HOLIDAY", "WORKFORCE_LEAVE"], [5, "PUBLIC_HOLIDAY", "ADMIN"]]) {
    await admin.mtmWorkCalendarDay.create({ data: { organizationId: organization.id, date: workDate, kind, source, name: "Today excused fixture", teamId: null, agentId: employees[index].id } })
  }
  const draft = createWorkforceExceptionCaseDraft({ organizationId: organization.id, agentId: employees[1].id, kind: "NO_SHOW", detectorVersion: "workforce-no-show-v1", links: { segmentId: segment.id, expectedWorkDate: date } })
  await admin.workforceExceptionCase.create({ data: {
    organizationId: draft.organizationId, agentId: draft.agentId, kind: draft.kind,
    detectorVersion: draft.detectorVersion, deduplicationKey: draft.deduplicationKey,
    workdayId: null, workdayEventId: null, evidenceId: null, segmentId: draft.links.segmentId, expectedWorkDate: workDate,
  } })
  await admin.mtmAgentWorkday.create({ data: { organizationId: organization.id, agentId: employees[2].id, workDate: earlier(1), status: "STARTED", startedAt: new Date(earlier(1).getTime() + 8 * 3_600_000), totalPausedSeconds: 0 } })
  const currentWorkdays = await seedCurrentSnapshotWorkdays({ organization, issuer, employees, template, jiti })
  const snapshotlessCurrentWorkday = await seedSnapshotlessCurrentWorkday({ organization, employees, template })
  const fixture = { organizations, organization, foreign, manager, approver, denied, employees, sentinels, template, currentWorkdays, snapshotlessCurrentWorkday }
  await proveCurrentSnapshotDatabaseGuards(fixture)
  currentDate()
  return fixture
}


try {
const [identity]=await admin.$queryRawUnsafe('SELECT current_database() AS database,current_user AS role');
assert.equal(identity.database,'workforce_manager_today_browser');assert.equal(identity.role,'postgres');
const f=await seed();
await writeFile(process.env.WF_AT_ROOT+'/fixture-private.json',JSON.stringify({password,manager:f.manager,approver:f.approver,denied:f.denied,employees:f.employees.map(x=>({id:x.id,name:x.name})),sentinels:f.sentinels.map(x=>({id:x.id,name:x.name}))}),{mode:0o600,flag:'wx'});
await writeFile(process.env.WF_AT_ROOT+'/fixture-receipt.json',JSON.stringify({...receipts,status:'PASS',employees:f.employees.length,sentinels:f.sentinels.length,actualStartEventTested:false},null,2));
} finally {await admin.$disconnect()}
