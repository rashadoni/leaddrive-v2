import os,json,time
from pathlib import Path
import speechd
out=Path(os.environ['WF_AT_OUTPUT'])/'backend-check.json'
result={'backend':'actual Speech Dispatcher espeak-ng','audio':'ALSA null device; no audio listening claim','commands':[]}
client=speechd.SSIPClient('c8-isolated-at-backend-check')
try:
    result['modules']=client.list_output_modules();out.write_text(json.dumps(result,indent=2))
    for text in ['AT backend check one.','AT backend check two.','AT backend check three.','AT backend check four.']:
        client.speak(text);result['commands'].append({'literal':text,'returned':True});out.write_text(json.dumps(result,indent=2));time.sleep(.25)
    result['status']='PASS';out.write_text(json.dumps(result,indent=2))
finally:client.close()
