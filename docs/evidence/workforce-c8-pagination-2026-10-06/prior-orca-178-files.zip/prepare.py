import json,hashlib,shutil
from pathlib import Path
root=Path(__file__).parent
src=root/'source'
h=(src/'scripts/workforce-manager-today-browser-evidence.mjs').read_text()
functions=h[h.index('async function seedCurrentSnapshotWorkdays'):h.index('async function checkedRead')]
prefix='''import assert from 'node:assert/strict';
import {randomUUID,createHash} from 'node:crypto';
import {writeFile} from 'node:fs/promises';
import {createJiti} from 'jiti';
import bcrypt from 'bcryptjs';
import {makeRlsTestPrisma} from './_rls.mjs';
assert.equal(process.env.WF_LOCAL_C8_AT,'1');
assert.notEqual(process.env.NODE_ENV,'production');
assert.notEqual(process.env.GITHUB_ACTIONS,'true');
const target=new URL(process.env.ADMIN_DATABASE_URL);
assert.equal(target.protocol,'postgresql:');assert.equal(target.hostname,'127.0.0.1');assert.equal(target.port,'55439');
assert.equal(target.pathname,'/workforce_manager_today_browser');assert.equal(target.username,'postgres');
assert.equal(process.env.EVENT_PLATFORM_TEST_DATABASE_URL,process.env.ADMIN_DATABASE_URL);
const admin=makeRlsTestPrisma(target.href);
const suffix=randomUUID().replaceAll('-','').slice(0,12),password=`Fixture!9a-${randomUUID()}`;
const date=new Date().toISOString().slice(0,10),workDate=new Date(`${date}T00:00:00.000Z`);
const earlier=days=>new Date(workDate.getTime()-days*86400000);
const currentDate=()=>assert.equal(new Date().toISOString().slice(0,10),date);
const receipts={environment:'isolated cloud Linux; local disposable fixture; not GitHub Actions',date};
'''
facts=h[h.index('const factTables ='):h.index('async function copy(locale)')]
suffix='''
try {
const [identity]=await admin.$queryRawUnsafe('SELECT current_database() AS database,current_user AS role');
assert.equal(identity.database,'workforce_manager_today_browser');assert.equal(identity.role,'postgres');
const f=await seed();
await writeFile(process.env.WF_AT_ROOT+'/fixture-private.json',JSON.stringify({password,manager:f.manager,approver:f.approver,denied:f.denied,employees:f.employees.map(x=>({id:x.id,name:x.name})),sentinels:f.sentinels.map(x=>({id:x.id,name:x.name}))}),{mode:0o600,flag:'wx'});
await writeFile(process.env.WF_AT_ROOT+'/fixture-receipt.json',JSON.stringify({...receipts,status:'PASS',employees:f.employees.length,sentinels:f.sentinels.length,actualStartEventTested:false},null,2));
} finally {await admin.$disconnect()}
'''
(src/'scripts/c8-local-fixture.mjs').write_text(prefix+facts+functions+suffix)
(root/'fixture-adaptation.json').write_text(json.dumps({'source':'scripts/workforce-manager-today-browser-evidence.mjs','sourceSha256':hashlib.sha256(h.encode()).hexdigest(),'extractedFunctionsSha256':hashlib.sha256(functions.encode()).hexdigest(),'changes':'New local-only runner and explicit DB fence; original hosted harness unchanged. Canonical seed and snapshot/guard helpers copied verbatim.'},indent=2))
observer='''import os,json,time,runpy
from pathlib import Path
from orca import orca,speech,orca_platform,speechdispatcherfactory
orca_platform.datadir=os.environ['WF_AT_PREFIX']+'/usr/share'
orca_platform.tablesdir=os.environ['WF_AT_PREFIX']+'/usr/share/liblouis/tables'
target=Path(os.environ['WF_AT_OUTPUT'])/'orca-presentations.jsonl'
original=speechdispatcherfactory.SpeechServer.speak
def observed(self,text=None,acss=None,interrupt=True):
    stamp=time.monotonic()
    if text:
        with target.open('a') as f:f.write(json.dumps({'time':stamp,'text':text,'origin':'actual Orca SpeechServer.speak','server':self._id},ensure_ascii=False)+'\\n')
    result=original(self,text,acss,interrupt)
    with (target.parent/'orca-dispatch-completed.jsonl').open('a') as f:f.write(json.dumps({'time':stamp,'completed':True})+'\\n')
    return result
speechdispatcherfactory.SpeechServer.speak=observed
runpy.run_path(os.environ['WF_AT_PREFIX']+'/usr/bin/orca',run_name='__main__')
'''
(root/'observer.py').write_text(observer)
nextjs='''const {createRequire}=require('node:module');const {writeFileSync}=require('node:fs');const http=require('node:http');
const root=process.env.WF_AT_ROOT,dir=root+'/source',req=createRequire(dir+'/package.json');
(async()=>{const load=req('next/dist/server/config').default;const {PHASE_DEVELOPMENT_SERVER}=req('next/constants');const conf=await load(PHASE_DEVELOPMENT_SERVER,dir);conf.distDir='.next-isolated-at';const port=Number(process.env.WF_AT_PORT);const app=req('next')({dev:true,dir,conf,hostname:'localhost',port});await app.prepare();const server=http.createServer(app.getRequestHandler());server.listen(port,'127.0.0.1',()=>writeFileSync(process.env.WF_AT_OUTPUT+'/app-ready.json',JSON.stringify({status:'READY',origin:'http://localhost:'+port,pid:process.pid})));process.on('SIGTERM',()=>server.close(()=>app.close().then(()=>process.exit())));})().catch(e=>{writeFileSync(process.env.WF_AT_OUTPUT+'/app-failure.json',JSON.stringify({errorType:e.name}));process.exit(1)});
'''
(root/'next.cjs').write_text(nextjs)
print(json.dumps({'prepared':True,'root':str(root)}))
