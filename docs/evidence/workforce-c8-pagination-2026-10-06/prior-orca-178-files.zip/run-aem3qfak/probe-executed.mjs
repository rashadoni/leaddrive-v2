import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
const root=process.env.WF_AT_ROOT,output=process.env.WF_AT_OUTPUT,origin='http://localhost:'+process.env.WF_AT_PORT;
const require=createRequire(root+'/source/package.json'),{chromium}=require('playwright');
const f=JSON.parse(await readFile(root+'/fixture-private.json','utf8'));
const context=await chromium.launchPersistentContext(output+'/chromium-profile',{headless:false,executablePath:'/usr/bin/chromium',baseURL:origin,viewport:{width:1380,height:900},args:['--force-renderer-accessibility','--no-sandbox','--disable-dev-shm-usage']});
const receipt={environment:'Actual Orca on isolated cloud Linux; frozen source copy; local fixture, not hosted CI',status:'RUNNING',browser:context.browser()?.version(),actions:[],assertions:[],limitations:['Synthetic fixture','Development bundle','No production activation','SpeechServer events, not human listening or audio recording']};
const write=()=>writeFile(output+'/at-receipt.json',JSON.stringify(receipt,null,2));
const keys=(...args)=>execFileSync('xdotool',args,{encoding:'utf8',timeout:10000});
let stage='auth';
try {
 await context.addCookies([{name:'NEXT_LOCALE',value:'en',url:origin}]);
 const csrf=await context.request.get('/api/auth/csrf',{timeout:120000});assert.equal(csrf.status(),200);
 const auth=await context.request.post('/api/auth/callback/credentials',{timeout:120000,headers:{'X-Auth-Return-Redirect':'1'},form:{csrfToken:(await csrf.json()).csrfToken,email:f.manager.email,password:f.password,organizationSlug:f.manager.slug,callbackUrl:origin+'/workforce'}});assert.equal(auth.status(),200);
 const session=await context.request.get('/api/auth/session');const user=(await session.json()).user;assert.equal(user.id,f.manager.id);assert.equal(user.organizationId,f.manager.organizationId);receipt.authentication='Actual credentials, CSRF and session; no mock';
 stage='page';const page=context.pages()[0];page.setDefaultTimeout(120000);
 const api=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/v1/workforce/today');
 await page.goto(origin+'/workforce',{waitUntil:'domcontentloaded',timeout:120000});const response=await api;assert.equal(response.status(),200);const payload=await response.json();assert.equal(payload.data.people.length,25);receipt.api={status:response.status(),people:payload.data.people.length};
 await page.locator('section[aria-labelledby="workforce-manager-today-list"] article').first().waitFor();
 stage='native-focus';await page.bringToFront();await page.waitForTimeout(1200);
 const wins=keys('search','--onlyvisible','--class','chromium').trim().split('\n');const title=await page.title();const window=wins.find(id=>keys('getwindowname',id).includes(title));assert.ok(window);
 keys('windowactivate','--sync',window);keys('windowfocus','--sync',window);
 const body=await page.locator('section[aria-labelledby="workforce-manager-today-list"]').boundingBox();
 // Native physical click into the real document, not programmatic DOM focus.
 const pos=keys('getwindowgeometry','--shell',window);const screen=Object.fromEntries(pos.trim().split('\n').map(x=>x.split('=')));
 keys('mousemove','--window',window,String(Math.round(body.x+40)),String(Math.min(600,Math.round(body.y+120+85)))) ;keys('click','1');await page.waitForTimeout(1000);
 stage='orca-reading';
 const action=async(name,seq,wait=650)=>{receipt.actions.push({name,at:Date.now()});keys('key','--clearmodifiers',...seq);await page.waitForTimeout(wait);await write()};
 await action('document-start',['ctrl+Home'],1200);
 for(let i=0;i<8;i++)await action('next-heading-'+i,['h']);
 await action('read-current-line',['KP_Insert+Up'],1000);
 await action('document-start-again',['ctrl+Home'],700);
 for(let i=0;i<95;i++)await action('next-line-'+i,['Down'],100);
 const speech=(await readFile(output+'/orca-presentations.jsonl','utf8').catch(()=>'' )).trim().split('\n').filter(Boolean).map(JSON.parse);
 receipt.actualOrcaPresentations=speech;
 receipt.domFocusedTag=await page.evaluate(()=>document.activeElement?.tagName);receipt.url=new URL(page.url()).pathname;
 const spoken=speech.map(x=>x.text).join('\n');receipt.assertions.push({name:'actual-Orca-employee-name',pass:spoken.includes('Today Employee')},{name:'actual-Orca-absence-state',pass:spoken.includes('No-show')||spoken.includes('Not started')||spoken.includes('Scheduled')});
 receipt.status=receipt.assertions.every(x=>x.pass)?'ACTUAL_AT_READING_OBSERVED':'AT_READING_NOT_ESTABLISHED';
} catch(e){receipt.status='FAIL';receipt.failure={stage,type:e.name,code:e.code??null};}
finally {await write();await context.close();}
