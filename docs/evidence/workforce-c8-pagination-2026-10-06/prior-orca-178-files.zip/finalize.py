import json,hashlib,datetime,zipfile,stat
from pathlib import Path
root=Path(__file__).parent;source=Path('/workspace/hrm-c7-completion')
manifest=json.loads((root/'source-manifest.json').read_text())
changed=[];mode_changed=[];copy_changed=[]
for row in manifest:
    p=source/row['path']
    if hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:changed.append(row['path'])
    if 'mode' in row and bool(p.stat().st_mode&0o111)!=(row['mode']=='100755'):mode_changed.append(row['path'])
    if hashlib.sha256((root/'source'/row['path']).read_bytes()).hexdigest()!=row['sha256']:copy_changed.append(row['path'])
assert not changed and not mode_changed
assert copy_changed==['tsconfig.json']
old=Path('/tmp/hrm-c8-at-probe.mjs');assert hashlib.sha256(old.read_bytes()).hexdigest()=='0a5979aea9397a618fcd9eb91c2cda2d198f3f76f7fa75a134fa3aada00331fd'
selected={'en':'run-85ygi5fi','ru':'run-aezmfqme','az':'run-de90k9wv'}
scenarios=[]
for locale,name in selected.items():
    d=root/name;r=json.loads((d/'at-receipt.json').read_text());assert r['status']=='ACTUAL_AT_READING_OBSERVED';assert len(r['assertions'])==6 and all(x['pass'] for x in r['assertions'])
    spoken=[json.loads(x) for x in (d/'orca-presentations.jsonl').read_text().splitlines()]
    done=[json.loads(x) for x in (d/'orca-dispatch-completed.jsonl').read_text().splitlines()]
    completed={x['time'] for x in done if x['completed']};assert all(x['time'] in completed for x in spoken)
    before=json.loads((d/'executed-script-hashes-before.json').read_text());after=json.loads((d/'executed-script-hashes-after.json').read_text());assert before==after
    cleanup=json.loads((d/'cleanup.json').read_text());assert all(isinstance(x['exit'],int) for x in cleanup)
    p=r['pagination']
    scenarios.append({'locale':locale,'run':name,'status':'PASS_BOUNDED_AT_READING_AND_NATIVE_PAGINATION','checks':r['assertions'],'actualSpeechEvents':len(spoken),'allSpeechDispatchesReturned':True,'absentEmployeeSpeech':r['absentEmployeeSpeech'],'rowsBefore':25,'rowsAfter':p['rows'],'focusAfterLoad':p['focusAfter'],'automaticResultSpeech':[x['text'] for x in p['automaticResultSpeech']],'ownedProcessesReaped':len(cleanup),'scriptsUnchangedDuringRun':True})
summary={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_ORCA_EN_RU_AZ_BOUNDED_PROOF_COMPLETE_WHOLE_C8_PARTIAL','sourceBaseHead':'a856a9e533c4f3cec6f2313e69f5be0d5b4d4226','sourceIntegration':'includes previously verified main601 plus uncommitted independently reviewed C8 wrapper/test; excludes later main602','sourceManifestSha256':hashlib.sha256((root/'source-manifest.json').read_bytes()).hexdigest(),'sourceFiles':len(manifest),'sourceOriginalChanges':changed,'sourceOriginalModeChanges':mode_changed,'copyGeneratedOnlyChanges':copy_changed,'unknownOldProbeUnchanged':True,'unknownOldProbeAuthorship':'UNRESOLVED; no new claim','scenarios':scenarios,'checksPassed':sum(len(x['checks']) for x in scenarios),'testEnvironment':{'browser':'Chromium 151.0.7922.173','screenReader':'Orca 48.1','speechDispatcher':'actual espeak-ng module; SPEECHD_PLUGIN_DIR points at verified scratch extraction','audio':'ALSA null; no human listening, pronunciation or recorded-audio claim','backendControl':'four actual SSIP speak commands return before browser run','app':'actual candidate app via Next standard startServer/Turbopack, development mode on frozen copy','auth':'actual CSRF/credentials/session and non-superuser fixture app role; synthetic seeded facts','isolation':'new private dbus-run-session, displayfd Xvfb/Xauthority, fresh XDG dirs and Chromium profile each run; only retained child handles managed','security':'No CSP, browser policy, production credentials or repository permissions changed'},'remaining':{'pagination':'After last-page button removal DOM focus is BODY. Actual Orca announces loading but no completion/count announcement was observed before further keys. Employee26 is reachable using native Ctrl+End then Up/Down. This does not establish automatic result announcement or intentional focus recovery.','notRunHere':['real denied-session AT','real same-org live session transition AT','whole C8 responsive/native200/contrast suite','new exact-commit CI/build','whole C8 independent final acceptance'],'otherObservedLimit':'Shared shell synthetic fixture returned 500 on preferences write; not classified as a C8 product defect or covered by this proof.','ledger':'unchanged:83/161 DONE,78 open,weighted60%;WF-C8-002 PARTIAL'},'nextMinimalStep':'After repository write gate is explicitly lifted, recheck fresh refs and all source hashes; create a separate clean C8 branch/copy from accepted a856 plus latest main (currently9197240, main602 only2MTMpaths); port only the independently reviewed workbench change and regression test, excluding incidental tsconfig; rerun bounded tests/lint and publish a draft checkpoint with these receipts. Keep accepted C7 candidate frozen. Address observed pagination announcement/focus gap as a separately verified bounded follow-up before whole C8 acceptance. No merge/deploy/activation.','remoteRefs':json.loads((root/'fresh-remote-refs.json').read_text())}
(root/'final-at-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
allow=['at-receipt.json','supervisor-events.json','cleanup.json','orca-presentations.jsonl','orca-dispatch-completed.jsonl','executed-script-hashes-before.json','executed-script-hashes-after.json','safe-error-categories.json','orca-own-thread-stacks.json','backend-check.json','app-ready.json','app-failure.json','probe-executed.mjs','next-executed.cjs','supervisor-executed.py','observer-executed.py']
files=[]
for d in sorted(root.glob('run-*')):
    for name in allow:
        p=d/name
        if p.is_file():files.append(p)
for name in ['final-at-summary.json','source-manifest.json','fixture-receipt.json','fixture-adaptation.json','fresh-remote-refs.json','disconnect-checkpoint.json','prepare.py','supervisor.py','observer.py','probe.mjs','next.cjs','inspect-atspi.py','backend-check.py','finalize.py','README.txt']:
    files.append(root/name)
files.append(root/'source/scripts/c8-local-fixture.mjs')
package_manifest=Path('/tmp/hrm-c8-at-stack/package-manifest.json');(root/'verified-package-manifest.json').write_bytes(package_manifest.read_bytes());files.append(root/'verified-package-manifest.json')
entries=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
(root/'receipt-manifest.json').write_text(json.dumps(entries,indent=2)+'\n');files.append(root/'receipt-manifest.json')
archive=root/'c8-isolated-orca-receipts.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.relative_to(root))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for entry in entries:assert hashlib.sha256(z.read(entry['path'])).hexdigest()==entry['sha256']
print(json.dumps({'status':summary['status'],'checksPassed':summary['checksPassed'],'sourceOriginalChanges':changed,'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files)},indent=2))
