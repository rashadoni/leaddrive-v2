Bounded C8 actual Orca proof, 2026-10-06

Read final-at-summary.json first. The immutable source-manifest.json binds the
8817 original files copied before execution. Application source was not edited.
Next generated TypeScript configuration changes only in the disposable copy.
The source repository and old unattributed probe remain unchanged.

Successful final scenarios: EN run-85ygi5fi, RU run-aezmfqme, AZ run-de90k9wv.
Each uses a fresh private D-Bus, Xvfb display allocated by displayfd, Xauthority,
XDG directories, Chromium profile, and a loopback app on the frozen source copy.
Only retained handles for newly created child processes are terminated/reaped.
No existing browser, old probe or unknown process is used or stopped.

Orca processes actual browser accessibility/keyboard events. observer.py records
the actual SpeechServer.speak text and calls the original method unchanged.
The completed receipts show each real dispatch returning. espeak-ng is the real
backend, with its audio plugin path pointing at the verified package extraction.
Audio goes to ALSA null; this is not human listening or pronunciation evidence.
Keyboard input uses xdotool on the private display. DOM is used to observe API,
row count and focused control, never as a substitute for actual Orca speech.

Reproduction in this selected execution environment:
  WF_AT_LOCALE=en python3 /tmp/hrm-c8-isolated-at-c4kelii3/supervisor.py
Use ru or az for the other locale, sequentially after the prior run exits.
Prerequisites: the frozen source copy with copied node_modules; verified packages
at /tmp/hrm-c8-at-stack/prefix; the authorized disposable PostgreSQL fixture at
127.0.0.1:55439; private synthetic environment in /tmp/hrm-c8-db-env.json.
Credentials, private fixture identities/passwords, profiles, Xauthority cookies,
raw app/CI logs, screenshots and private environment files are excluded here.
Do not execute against production or substitute a differently targeted database.
The new fixture helper fences the exact disposable database/roles and copies the
canonical seed/snapshot helpers verbatim; its source hash is in fixture-adaptation.

Original unsuccessful attempts are retained. They include custom bootstrap
ENOENT, a Webpack development EvalError before hydration, and real speech backend
dispatch blocking before the scratch audio plugin directory was configured.
The earlier RU run's control-name snapshot raced actual speech by milliseconds;
its original FAIL is retained. The full actual stream contained that label; the
final probe waits for the real speech event before pressing Enter.

Scope: absent employee identity/state/plan/window/non-presence explanation,
distinct recorded no-show, native load-more activation and reaching employee26.
Not whole C8 acceptance. After button removal focus becomes BODY; no automatic
completion/count announcement was observed. Additional keyboard reading reaches
employee26. Whole C8, denied/live-session AT, contrast/native200 and new exact-head
CI are not claimed. Main advanced to9197240 after the frozen copy was created.

receipt-manifest.json hashes every included evidence/script file. The ZIP was
read back and each recorded SHA256 was checked. No source or remote write occurred.
