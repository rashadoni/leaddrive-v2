import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
const root = process.env.WF_AT_ROOT, output = process.env.WF_AT_OUTPUT;
const origin = 'http://localhost:' + process.env.WF_AT_PORT;
const require = createRequire(root + '/source/package.json');
const { chromium } = require('playwright');
const fixture = JSON.parse(await readFile(root + '/fixture-private.json', 'utf8'));
const locale = process.env.WF_AT_LOCALE || 'ru';
const ui = JSON.parse(await readFile(root + '/source/messages/' + locale + '.json', 'utf8')).workforcePage;
const receipt = { status: 'RUNNING', locale, sourceHead: 'd97e8ba8c276d62a01c1f0de4a3ce7ee15dbb6cd', assertions: [], responses: [], actions: [], audio: 'ALSA null; actual Orca original speak dispatch, no human listening', runtime: 'development; scoped synthetic fixture' };
const save = () => writeFile(output + '/at-receipt.json', JSON.stringify(receipt, null, 2));
const keys = (...args) => execFileSync('xdotool', args, { encoding: 'utf8', timeout: 10000 });
const context = await chromium.launchPersistentContext(output + '/chromium-profile', { headless: false, executablePath: '/usr/bin/chromium', baseURL: origin, viewport: { width: 1380, height: 900 }, args: ['--force-renderer-accessibility', '--no-sandbox', '--disable-dev-shm-usage'] });
const page = context.pages()[0]; page.setDefaultTimeout(60000);
let stage = 'auth';
const speech = async () => (await readFile(output + '/orca-presentations.jsonl', 'utf8').catch(() => '')).split('\n').filter(Boolean).map(JSON.parse);
async function login(actor) {
  const csrf = await context.request.get('/api/auth/csrf', { timeout: 120000 }); assert.equal(csrf.status(), 200);
  const response = await context.request.post('/api/auth/callback/credentials', { timeout: 120000, headers: { 'X-Auth-Return-Redirect': '1' }, form: { csrfToken: (await csrf.json()).csrfToken, email: actor.email, password: fixture.password, organizationSlug: actor.slug, callbackUrl: origin + '/workforce' } });
  assert.equal(response.status(), 200); assert.equal(new URL((await response.json()).url, origin).searchParams.get('error'), null);
  const session = await context.request.get('/api/auth/session'); const user = (await session.json()).user;
  assert.equal(user.id, actor.id); assert.equal(user.organizationId, actor.organizationId);
}
async function action(name, sequence, delay = 150) { receipt.actions.push({ name, at: Date.now() }); keys('key', '--clearmodifiers', ...sequence); await page.waitForTimeout(delay); }
async function nativeFocus() {
  await page.bringToFront(); await page.waitForTimeout(1000);
  const title = await page.title(); const windows = keys('search', '--onlyvisible', '--class', 'chromium').trim().split('\n');
  const window = windows.find(id => keys('getwindowname', id).includes(title)); assert.ok(window);
  keys('windowactivate', '--sync', window); keys('windowfocus', '--sync', window);
  keys('mousemove', '--window', window, '650', '500'); keys('click', '1'); await page.waitForTimeout(500);
}
async function readDocument(name, lines = 75) { const start = (await speech()).length; await action(name + '-stop', ['Escape'], 300); await action(name + '-start', ['ctrl+Home'], 500); for (let i = 0; i < lines; i++) await action(name + '-line-' + i, ['Down'], 80); return (await speech()).slice(start); }
async function keyboardButton(label) {
  await action('tab-start', ['ctrl+Home'], 200);
  for (let i = 0; i < 80; i++) { await action('tab-' + i, ['Tab'], 70); if (await page.evaluate(text => document.activeElement?.textContent?.trim() === text, label)) return; }
  throw new Error('NATIVE_BUTTON_NOT_FOUND');
}
try {
  await context.addCookies([{ name: 'NEXT_LOCALE', value: locale, url: origin }]);
  page.on('response', r => { const u = new URL(r.url()); if (u.origin === origin && u.pathname.startsWith('/api/')) receipt.responses.push({ path: u.pathname, status: r.status() }); });
  await login(fixture.denied);
  stage = 'actual-denied-page';
  const pending = page.waitForResponse(r => new URL(r.url()).pathname === '/api/v1/workforce/today');
  await page.goto('/workforce', { waitUntil: 'domcontentloaded', timeout: 120000 });
  const response = await pending; const payload = await response.json(); assert.equal(response.status(), 403);
  assert.equal(payload.code, 'WORKFORCE_TODAY_READ_ACCESS_REQUIRED');
  const alert = page.getByRole('alert').filter({ hasText: ui.loadFailed }); await alert.waitFor();
  receipt.denial = { status: response.status(), code: payload.code, keys: Object.keys(payload).sort(), alertText: await alert.innerText(), noRoster: await page.locator('section[aria-labelledby="workforce-manager-today-list"]').count() === 0, cacheControl: response.headers()['cache-control'] };
  await nativeFocus();
  stage = 'actual-denied-orca'; receipt.denial.actualSpeech = await readDocument('denied');
  const spoken = receipt.denial.actualSpeech.map(x => x.text).join(' ');
  receipt.assertions.push({ name: 'real-denied-session-403-private-no-store-no-roster', pass: receipt.denial.noRoster && receipt.denial.cacheControl.includes('private') && receipt.denial.cacheControl.includes('no-store') });
  receipt.assertions.push({ name: 'denied-Orca-no-stale-employee-names', pass: !fixture.employees.some(x => spoken.includes(x.name)) });
  receipt.assertions.push({ name: 'localized-denied-heading-and-retry-spoken', pass: spoken.includes(ui.loadFailed) && spoken.includes(ui.tryAgain) });
  receipt.assertions.push({ name: 'denial-detail-is-localized-safe-message', pass: typeof ui.managerReadDenied === 'string' && receipt.denial.alertText.includes(ui.managerReadDenied) && !receipt.denial.alertText.includes(payload.error) });
  stage = 'retry-native-keyboard'; await keyboardButton(ui.tryAgain);
  const retried = page.waitForResponse(r => new URL(r.url()).pathname === '/api/v1/workforce/today'); await action('activate-retry', ['Return'], 500); assert.equal((await retried).status(), 403);
  receipt.assertions.push({ name: 'real-denial-retry-reachable-by-native-keyboard', pass: true });
  receipt.status = receipt.assertions.every(x => x.pass) ? 'PASS' : 'NEGATIVE_REPRODUCED';
} catch (error) { receipt.status = 'FAIL'; receipt.failure = { stage, type: error.name, categories: ['Timeout', 'NATIVE_BUTTON_NOT_FOUND', 'Target closed'].filter(x => error.message.includes(x)) }; }
finally { await save(); await context.close(); }
process.exitCode = receipt.status === 'PASS' ? 0 : 1;
