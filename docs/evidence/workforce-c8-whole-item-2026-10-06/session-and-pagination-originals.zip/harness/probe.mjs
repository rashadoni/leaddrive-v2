import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { sampleTodayContrast } from './contrast-helper.mjs';
const root = process.env.WF_AT_ROOT, output = process.env.WF_AT_OUTPUT;
const origin = 'http://localhost:' + process.env.WF_AT_PORT;
const require = createRequire(root + '/source/package.json');
const { chromium } = require('playwright');
const fixture = JSON.parse(await readFile(root + '/fixture-private.json', 'utf8'));
const locale = process.env.WF_AT_LOCALE || 'ru';
const ui = JSON.parse(await readFile(root + '/source/messages/' + locale + '.json', 'utf8')).workforcePage;
const receipt = { status: 'RUNNING', locale, sourceParent: 'd97e8ba8c276d62a01c1f0de4a3ce7ee15dbb6cd', sourceBinding: 'Uncommitted localized-error candidate; exact full-source manifest copied into this run', assertions: [], responses: [], actions: [], audio: 'ALSA null; actual Orca original speak dispatch, no human listening', runtime: 'development; scoped synthetic fixture' };
const save = () => writeFile(output + '/at-receipt.json', JSON.stringify(receipt, null, 2));
const keys = (...args) => execFileSync('xdotool', args, { encoding: 'utf8', timeout: 10000 });
const context = await chromium.launchPersistentContext(output + '/chromium-profile', { headless: false, executablePath: '/usr/bin/chromium', baseURL: origin, viewport: { width: 1380, height: 900 }, args: ['--force-renderer-accessibility', '--no-sandbox', '--disable-dev-shm-usage'] });
const page = context.pages()[0]; page.setDefaultTimeout(60000);
let stage = 'auth';
const speech = async () => (await readFile(output + '/orca-presentations.jsonl', 'utf8').catch(() => '')).split('\n').filter(Boolean).map(JSON.parse);
async function login(actor) {
  const csrf = await context.request.get('/api/auth/csrf', { timeout: 120000 }); assert.equal(csrf.status(), 200);
  const response = await context.request.post('/api/auth/callback/credentials', { timeout: 120000, headers: { 'X-Auth-Return-Redirect': '1' }, form: { csrfToken: (await csrf.json()).csrfToken, email: actor.email, password: fixture.password, organizationSlug: actor.slug, callbackUrl: origin + '/workforce' } });
  assert.equal(response.status(), 200); assert.equal(new URL((await response.json()).url, origin).searchParams.get('error'), null);
  const session = await context.request.get('/api/auth/session'); const user = (await session.json()).user;
  assert.equal(user.id, actor.id); assert.equal(user.organizationId, actor.organizationId);
}
async function action(name, sequence, delay = 150) { receipt.actions.push({ name, at: Date.now() }); keys('key', '--clearmodifiers', ...sequence); await page.waitForTimeout(delay); }
async function nativeFocus() {
  await page.bringToFront(); await page.waitForTimeout(1000);
  const title = await page.title(); const windows = keys('search', '--onlyvisible', '--class', 'chromium').trim().split('\n');
  const window = windows.find(id => keys('getwindowname', id).includes(title)); assert.ok(window);
  keys('windowactivate', '--sync', window); keys('windowfocus', '--sync', window);
  keys('mousemove', '--window', window, '650', '500'); keys('click', '1'); await page.waitForTimeout(500);
}
async function readDocument(name, lines = 75) { const start = (await speech()).length; await action(name + '-stop', ['Escape'], 300); await action(name + '-start', ['ctrl+Home'], 500); for (let i = 0; i < lines; i++) await action(name + '-line-' + i, ['Down'], 80); return (await speech()).slice(start); }
async function keyboardButton(label) {
  await action('tab-start', ['ctrl+Home'], 200);
  for (let i = 0; i < 80; i++) { await action('tab-' + i, ['Tab'], 70); if (await page.evaluate(text => document.activeElement?.textContent?.trim() === text, label)) return; }
  throw new Error('NATIVE_BUTTON_NOT_FOUND');
}
try {
  await context.addCookies([{ name: 'NEXT_LOCALE', value: locale, url: origin }]);
  page.on('response', r => { const u = new URL(r.url()); if (u.origin === origin && u.pathname.startsWith('/api/')) receipt.responses.push({ path: u.pathname, status: r.status() }); });
  await login(fixture.denied);
  stage = 'actual-denied-page';
  const pending = page.waitForResponse(r => new URL(r.url()).pathname === '/api/v1/workforce/today');
  await page.goto('/workforce', { waitUntil: 'domcontentloaded', timeout: 120000 });
  const response = await pending; const payload = await response.json(); assert.equal(response.status(), 403);
  assert.equal(payload.code, 'WORKFORCE_TODAY_READ_ACCESS_REQUIRED');
  const alert = page.getByRole('alert').filter({ hasText: ui.loadFailed }); await alert.waitFor();
  receipt.denial = { status: response.status(), code: payload.code, keys: Object.keys(payload).sort(), alertText: await alert.innerText(), noRoster: await page.locator('section[aria-labelledby="workforce-manager-today-list"]').count() === 0, cacheControl: response.headers()['cache-control'] };
  await nativeFocus();
  stage = 'actual-denied-orca'; receipt.denial.actualSpeech = await readDocument('denied');
  const spoken = receipt.denial.actualSpeech.map(x => x.text).join(' ');
  receipt.assertions.push({ name: 'real-denied-session-403-private-no-store-no-roster', pass: receipt.denial.noRoster && receipt.denial.cacheControl.includes('private') && receipt.denial.cacheControl.includes('no-store') });
  receipt.assertions.push({ name: 'denied-Orca-no-stale-employee-names', pass: !fixture.employees.some(x => spoken.includes(x.name)) });
  receipt.assertions.push({ name: 'localized-denied-heading-and-retry-spoken', pass: spoken.includes(ui.loadFailed) && spoken.includes(ui.tryAgain) });
  receipt.assertions.push({ name: 'denial-detail-is-localized-safe-message', pass: typeof ui.managerReadDenied === 'string' && receipt.denial.alertText.includes(ui.managerReadDenied) && !receipt.denial.alertText.includes(payload.error) });
  receipt.contrast = [];
  for (const theme of ['light', 'dark']) {
    await page.evaluate(theme => { document.documentElement.classList.toggle('dark', theme === 'dark'); document.documentElement.classList.toggle('light', theme === 'light'); }, theme); await page.waitForTimeout(400);
    receipt.contrast.push(await sampleTodayContrast(page, 'denial-' + theme));
  }
  await page.evaluate(() => { document.documentElement.classList.remove('dark'); document.documentElement.classList.add('light'); });
  stage = 'retry-native-keyboard'; await keyboardButton(ui.tryAgain);
  const retried = page.waitForResponse(r => new URL(r.url()).pathname === '/api/v1/workforce/today'); await action('activate-retry', ['Return'], 500); assert.equal((await retried).status(), 403);
  receipt.assertions.push({ name: 'real-denial-retry-reachable-by-native-keyboard', pass: true });
  if (process.env.WF_AT_SESSION_MATRIX === '1') {
    const broadcastSession = () => page.evaluate(() => { const channel = new BroadcastChannel('next-auth'); channel.postMessage({ event: 'session', data: { trigger: 'getSession' } }); channel.close(); });
    const rows = page.locator('section[aria-labelledby="workforce-manager-today-list"] article');
    stage = 'real-manager-session-recovery';
    await login(fixture.manager);
    const recovered = page.waitForResponse(r => new URL(r.url()).pathname === '/api/v1/workforce/today');
    await broadcastSession(); assert.equal((await recovered).status(), 200); await rows.first().waitFor(); assert.equal(await rows.count(), 25);
    const deferred = () => { let resolve; const promise = new Promise(r => { resolve = r; }); return { promise, resolve }; };
    const oldReady = deferred(), newReady = deferred(), releaseOld = deferred(), releaseNew = deferred();
    let phase = 'old-pagination', controlledFailure = false;
    receipt.transition = { samePage: true, realCredentialsAndBroadcastChannel: true, sameOrg: fixture.manager.organizationId === fixture.approver.organizationId, differentPrincipal: fixture.manager.id !== fixture.approver.id };
    await page.route('**/api/v1/workforce/today**', async route => {
      const cursor = new URL(route.request().url()).searchParams.has('cursor');
      if (cursor && phase === 'old-pagination') {
        phase = 'old-pending'; const actual = await route.fetch(); receipt.transition.oldStatus = actual.status(); oldReady.resolve(); await releaseOld.promise;
        try { await route.fulfill({ response: actual }); receipt.transition.oldRelease = 'fulfilled'; } catch { receipt.transition.oldRelease = 'cancelled-request-not-delivered'; }
        return;
      }
      if (!cursor && (phase === 'new-initial' || phase === 'new-pending')) {
        phase = 'new-pending'; const actual = await route.fetch(); const data = await actual.json(); receipt.transition.newStatus = actual.status(); receipt.transition.newAttendanceOnlyExceptionsNull = data.data.people.every(x => x.exceptions === null); newReady.resolve(); await releaseNew.promise; try { await route.fulfill({ response: actual }); } catch { receipt.transition.cancelledDuplicateNewRequest = true; } return;
      }
      if (controlledFailure) { controlledFailure = false; await route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ error: 'Synthetic private server detail', code: 'synthetic-unavailable' }) }); return; }
      await route.continue();
    });
    stage = 'old-native-pagination-pending'; await keyboardButton(ui.managerLoadMore); await action('old-pagination-enter', ['Return'], 150); await oldReady.promise;
    stage = 'same-page-principal-transition'; await login(fixture.approver); phase = 'new-initial'; await broadcastSession(); await newReady.promise;
    await page.waitForFunction(() => !document.querySelector('section[aria-labelledby="workforce-manager-today-list"]'));
    const pendingSpeech = await readDocument('new-principal-pending', 55); const pendingText = pendingSpeech.map(x => x.text).join(' ');
    receipt.transition.pendingSpeech = pendingSpeech;
    receipt.transition.noOldNamesWhileNewPending = !fixture.employees.some(x => pendingText.includes(x.name)) && await rows.count() === 0;
    releaseOld.resolve(); await page.waitForTimeout(500);
    receipt.transition.oldCompletionDoesNotExposeRowsOrClearNewLoading = await rows.count() === 0 && await page.getByRole('status', { name: ui.loading }).count() === 1;
    releaseNew.resolve(); await rows.first().waitFor(); assert.equal(await rows.count(), 25);
    receipt.transition.newRosterLoadedWithoutStaleAppend = true;
    receipt.assertions.push({ name: 'real-same-org-principal-switch-clears-old-DOM-and-Orca-while-new-request-pending', pass: receipt.transition.sameOrg && receipt.transition.differentPrincipal && receipt.transition.noOldNamesWhileNewPending });
    receipt.assertions.push({ name: 'old-real-pagination-cannot-clear-new-loading-or-append-after-session-switch', pass: receipt.transition.oldCompletionDoesNotExposeRowsOrClearNewLoading && receipt.transition.newRosterLoadedWithoutStaleAppend });
    receipt.assertions.push({ name: 'new-real-attendance-only-session-keeps-exceptions-restricted', pass: receipt.transition.newStatus === 200 && receipt.transition.newAttendanceOnlyExceptionsNull });
    stage = 'controlled-unavailable-response'; phase = 'normal'; controlledFailure = true; await keyboardButton(ui.refresh); await action('refresh-with-controlled-fault', ['Return'], 500);
    const failureAlert = page.getByRole('alert').filter({ hasText: ui.loadFailed }); await failureAlert.waitFor();
    const unavailableSpeech = await readDocument('unavailable', 70); const unavailableText = unavailableSpeech.map(x => x.text).join(' ');
    receipt.unavailable = { controlled503Fixture: true, alertText: await failureAlert.innerText(), actualSpeech: unavailableSpeech };
    receipt.assertions.push({ name: 'controlled-unavailable-error-is-localized-and-no-server-canary-in-DOM-or-Orca', pass: receipt.unavailable.alertText.includes(ui.managerReadUnavailable) && unavailableText.includes(ui.managerReadUnavailable) && !receipt.unavailable.alertText.includes('Synthetic private server detail') && !unavailableText.includes('Synthetic private server detail') });
    stage = 'real-retry-after-controlled-fault'; await keyboardButton(ui.tryAgain); const retryResponse = page.waitForResponse(r => new URL(r.url()).pathname === '/api/v1/workforce/today'); await action('retry-to-real-server', ['Return'], 250); assert.equal((await retryResponse).status(), 200); await rows.first().waitFor();
    receipt.assertions.push({ name: 'native-keyboard-retry-recovers-real-roster-after-controlled-fault', pass: await rows.count() === 25 });
    stage = 'targeted-rendered-contrast';
    await login(fixture.manager); const managerResponse = page.waitForResponse(r => new URL(r.url()).pathname === '/api/v1/workforce/today'); await broadcastSession(); assert.equal((await managerResponse).status(), 200); await rows.first().waitFor();
    for (const theme of ['light', 'dark']) {
      await page.evaluate(theme => { document.documentElement.classList.toggle('dark', theme === 'dark'); document.documentElement.classList.toggle('light', theme === 'light'); }, theme); await page.waitForTimeout(400);
      receipt.contrast.push(await sampleTodayContrast(page, 'manager-' + theme));
    }
    stage = 'narrow-320CSS'; await page.setViewportSize({ width: 320, height: 900 }); await page.waitForTimeout(500);
    receipt.narrow = await page.evaluate(() => ({ width: innerWidth, documentWidth: document.documentElement.scrollWidth, rosterRows: document.querySelectorAll('section[aria-labelledby="workforce-manager-today-list"] article').length, buttons: [...document.querySelectorAll('section[aria-labelledby="workforce-manager-today-list"] button')].map(el => { const r = el.getBoundingClientRect(); return { width: r.width, height: r.height, withinWidth: r.left >= 0 && r.right <= innerWidth }; }) }));
    receipt.assertions.push({ name: '320CSS-no-horizontal-overflow-and-load-control-within-width-min48', pass: receipt.narrow.documentWidth <= receipt.narrow.width && receipt.narrow.rosterRows === 25 && receipt.narrow.buttons.every(x => x.withinWidth && x.height >= 48) });
    await page.unroute('**/api/v1/workforce/today**');
  }
  const checkedContrast = receipt.contrast.flatMap(x => x.samples).filter(x => x.checked);
  receipt.assertions.push({ name: 'sampled-active-text-contrast-light-dark-at-least4.5', pass: checkedContrast.length > 0 && checkedContrast.every(x => x.pass) });
  receipt.contrastSummary = { checked: checkedContrast.length, minimum: Math.min(...checkedContrast.map(x => x.ratio)), failed: checkedContrast.filter(x => !x.pass) };
  receipt.status = receipt.assertions.every(x => x.pass) ? 'PASS' : 'NEGATIVE_REPRODUCED';
} catch (error) { receipt.status = 'FAIL'; receipt.failure = { stage, type: error.name, categories: ['Timeout', 'NATIVE_BUTTON_NOT_FOUND', 'Target closed'].filter(x => error.message.includes(x)) }; }
finally { await save(); await context.close(); }
process.exitCode = receipt.status === 'PASS' ? 0 : 1;
