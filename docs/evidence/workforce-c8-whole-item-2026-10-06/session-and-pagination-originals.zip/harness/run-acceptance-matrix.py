from pathlib import Path
import subprocess,os,json,hashlib
root=Path(__file__).parent;repo=Path('/workspace/hrm-c8-completion-20261006');manifest=json.loads((root/'source-manifest.json').read_text());frozen=hashlib.sha256((root/'source-manifest.json').read_bytes()).hexdigest()
def verify():
 for x in manifest:
  for base in [root/'source',repo]:assert hashlib.sha256((base/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path']
verify();results=[{'kind':'session','locale':'en','zoom':1,'run':'run-i76cy91q','status':'PASS','checks':12,'sourceManifestSha256':frozen}]
cases=[('pagination','en',2),('session','ru',1),('session','az',1),('pagination','en',1),('pagination','ru',1),('pagination','az',1),('pagination','ru',2),('pagination','az',2)]
for kind,locale,zoom in cases:
 verify();env={**os.environ,'WF_AT_LOCALE':locale,'WF_AT_PROBE':'probe.mjs' if kind=='session' else 'pagination-probe.mjs','WF_AT_SESSION_MATRIX':'1' if kind=='session' else '0','WF_AT_ZOOM':str(zoom),'WF_AT_FRACTIONAL':'1' if zoom==2 else '0'}
 print(json.dumps({'start':kind,'locale':locale,'zoom':zoom}),flush=True)
 p=subprocess.run(['/usr/bin/python3',str(root/'supervisor.py')],env=env,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True)
 run=Path((root/'latest-run.txt').read_text().strip());r=json.loads((run/'at-receipt.json').read_text()) if (run/'at-receipt.json').exists() else {'status':'MISSING_RECEIPT','assertions':[]}
 verify();row={'kind':kind,'locale':locale,'zoom':zoom,'run':run.name,'status':r['status'],'exit':p.returncode,'checks':sum(x['pass'] for x in r['assertions']),'assertions':len(r['assertions']),'sourceManifestSha256':frozen};results.append(row);(root/'acceptance-matrix.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 for name in ['probe.mjs','pagination-probe.mjs','contrast-helper.mjs']:(run/('executed-'+name)).write_bytes((root/name).read_bytes())
 assert p.returncode==0 and r['status'] in ['PASS','ACTUAL_AT_READING_OBSERVED'] and all(x['pass'] for x in r['assertions']),row
print(json.dumps({'complete':True,'scenarios':len(results),'assertions':sum(x['checks'] for x in results)}),flush=True)
