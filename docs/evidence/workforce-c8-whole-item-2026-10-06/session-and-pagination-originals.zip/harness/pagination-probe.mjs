import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
const root=process.env.WF_AT_ROOT,output=process.env.WF_AT_OUTPUT,origin='http://localhost:'+process.env.WF_AT_PORT;
const require=createRequire(root+'/source/package.json'),{chromium}=require('playwright');
const f=JSON.parse(await readFile(root+'/fixture-private.json','utf8'));
const locale=process.env.WF_AT_LOCALE||'en';assert.ok(['en','ru','az'].includes(locale));const ui=JSON.parse(await readFile(root+'/source/messages/'+locale+'.json','utf8')).workforcePage;
const context=await chromium.launchPersistentContext(output+'/chromium-profile',{headless:false,executablePath:'/usr/bin/chromium',baseURL:origin,viewport:process.env.WF_AT_FRACTIONAL==='1'?{width:640,height:901}:{width:1380,height:900},args:['--force-renderer-accessibility','--no-sandbox','--disable-dev-shm-usage']});
const receipt={environment:'Actual Orca on isolated cloud Linux; frozen source copy; local fixture, not hosted CI',status:'RUNNING',browser:context.browser()?.version(),actions:[],assertions:[],limitations:['Synthetic fixture','Development bundle','No production activation','SpeechServer events, not human listening or audio recording']};
receipt.locale=locale;
const write=()=>writeFile(output+'/at-receipt.json',JSON.stringify(receipt,null,2));
const keys=(...args)=>execFileSync('xdotool',args,{encoding:'utf8',timeout:10000});
let stage='auth';
try {
 await context.addCookies([{name:'NEXT_LOCALE',value:locale,url:origin}]);
 const csrf=await context.request.get('/api/auth/csrf',{timeout:120000});receipt.csrfStatus=csrf.status();
 if(csrf.status()!==200){const body=await csrf.text();receipt.safeFailureClassification=Object.fromEntries(['Module not found','Cannot find module','PrismaClient','AUTH_SECRET','NEXTAUTH_SECRET','TENANT_PII','SyntaxError','TypeError','ReferenceError','ECONNREFUSED','EACCES','permission denied','Turbopack','webpack'].map(x=>[x,body.includes(x)]));const data=body.match(/<script id="__NEXT_DATA__"[^>]*>(.*?)<\/script>/s)?.[1];if(data){const err=JSON.parse(data).err;receipt.structuredErrorType=err?.name;receipt.safeStackFiles=err?.stack?.split('\n').slice(1,7).map(x=>x.match(/(?:\/|\()([^/ ()]+):\d+:\d+/)?.[1]??'redacted');}}
 await write();assert.equal(csrf.status(),200);
 stage='auth-callback';const auth=await context.request.post('/api/auth/callback/credentials',{timeout:120000,headers:{'X-Auth-Return-Redirect':'1'},form:{csrfToken:(await csrf.json()).csrfToken,email:f.manager.email,password:f.password,organizationSlug:f.manager.slug,callbackUrl:origin+'/workforce'}});receipt.callbackStatus=auth.status();const callback=await auth.json();receipt.callbackError=callback.url?new URL(callback.url,origin).searchParams.get('error'):null;await write();assert.equal(auth.status(),200);
 stage='session';const session=await context.request.get('/api/auth/session');const user=(await session.json()).user;receipt.sessionStatus=session.status();receipt.sessionUserPresent=Boolean(user);await write();assert.equal(user.id,f.manager.id);assert.equal(user.organizationId,f.manager.organizationId);receipt.authentication='Actual credentials, CSRF and session; no mock';
 stage='page';const page=context.pages()[0];page.setDefaultTimeout(120000);receipt.responses=[];receipt.pageErrors=[];
 page.on('response',r=>{const u=new URL(r.url());if(u.origin===origin&&(!u.pathname.startsWith('/_next/')||r.status()>=400)){receipt.responses.push({path:u.pathname,status:r.status()});void write()}});
 page.on('pageerror',e=>{receipt.pageErrors.push({type:e.name,categories:['ChunkLoadError','Hydration','Minified React','NEXTAUTH','fetch','loading CSS','Loading chunk'].filter(x=>e.message.includes(x))});void write()});
 const api=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/v1/workforce/today').then(r=>({response:r}),e=>({error:e.name}));
 const navigation=await page.goto(origin+'/workforce',{waitUntil:'domcontentloaded',timeout:120000});receipt.navigationStatus=navigation.status();receipt.navigationPath=new URL(page.url()).pathname;await write();stage='today-response';const got=await api;assert.ok(got.response,got.error);const response=got.response;assert.equal(response.status(),200);const payload=await response.json();assert.equal(payload.data.people.length,25);receipt.api={status:response.status(),people:payload.data.people.length};
 await page.locator('section[aria-labelledby="workforce-manager-today-list"] article').first().waitFor();
 stage='native-focus';await page.bringToFront();await page.waitForTimeout(1200);
 const wins=keys('search','--onlyvisible','--class','chromium').trim().split('\n');const title=await page.title();const window=wins.find(id=>keys('getwindowname',id).includes(title));assert.ok(window);
 keys('windowactivate','--sync',window);keys('windowfocus','--sync',window);
 if(process.env.WF_AT_ZOOM==='2'){
  const metrics=()=>page.evaluate(()=>({dpr:devicePixelRatio,width:innerWidth,height:innerHeight,scale:visualViewport?.scale}));
  keys('key','--clearmodifiers','ctrl+0');await page.waitForTimeout(350);const before=await metrics();
  for(let i=0;i<5;i++){keys('key','--clearmodifiers','ctrl+plus');await page.waitForTimeout(200)}
  await page.waitForTimeout(800);const after=await metrics();receipt.nativeZoom={before,after,factor:after.dpr/before.dpr,method:'five physical Ctrl+plus shortcuts after Ctrl+0'};assert.equal(receipt.nativeZoom.factor,2);assert.equal(after.scale,1);
 }
 const body=await page.locator('section[aria-labelledby="workforce-manager-today-list"]').boundingBox();
 // Native physical click into the real document, not programmatic DOM focus.
 const pos=keys('getwindowgeometry','--shell',window);const screen=Object.fromEntries(pos.trim().split('\n').map(x=>x.split('=')));
 keys('mousemove','--window',window,String(Math.round(body.x+40)),String(Math.min(600,Math.round(body.y+120+85)))) ;keys('click','1');await page.waitForTimeout(1000);
 stage='orca-reading';
 const action=async(name,seq,wait=650)=>{receipt.actions.push({name,at:Date.now()});keys('key','--clearmodifiers',...seq);await page.waitForTimeout(wait);await write()};
 await action('document-start',['ctrl+Home'],1200);
 for(let i=0;i<8;i++)await action('next-heading-'+i,['h']);
 await action('read-current-line',['KP_Insert+Up'],1000);
 await action('document-start-again',['ctrl+Home'],700);
 for(let i=0;i<140;i++)await action('next-line-'+i,['Down'],100);
 stage='pagination';receipt.pagination={nativeKeyboardOnly:true,found:false};
 await action('pagination-start',['ctrl+Home'],300);
 for(let i=0;i<65;i++){
  await action('pagination-tab-'+i,['Tab'],120);
  if(await page.evaluate(label=>document.activeElement?.textContent?.trim()===label,ui.managerLoadMore)){receipt.pagination.found=true;break;}
 }
 if(receipt.pagination.found){
  const originalControl=await page.locator('button').filter({hasText:ui.managerLoadMore}).elementHandle();assert.ok(originalControl);
  // Wait for the actual AT event, not merely the DOM focus event, before activation.
  for(let i=0;i<40;i++){const emitted=(await readFile(output+'/orca-presentations.jsonl','utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);if(emitted.slice(-8).some(x=>x.text.includes(ui.managerLoadMore)))break;await page.waitForTimeout(100)}
  receipt.pagination.speechBeforeActivation=(await readFile(output+'/orca-presentations.jsonl','utf8')).trim().split('\n').filter(Boolean).map(JSON.parse).slice(-8);
  const speechStart=(await readFile(output+'/orca-presentations.jsonl','utf8')).trim().split('\n').length;
  const more=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/v1/workforce/today'&&new URL(r.url()).searchParams.has('cursor')).then(r=>({response:r}),e=>({error:e.name}));
  await action('activate-load-more',['Return'],900);const loaded=await more;assert.ok(loaded.response);receipt.pagination.apiStatus=loaded.response.status();
  await page.waitForFunction(()=>document.querySelectorAll('section[aria-labelledby="workforce-manager-today-list"] article').length===26);
  receipt.pagination.rows=26;receipt.pagination.focusAfter=await page.evaluate(()=>({tag:document.activeElement?.tagName,text:document.activeElement?.tagName==='BODY'?'[body]':document.activeElement?.textContent?.slice(0,120)}));
  const expected=ui.managerLoadMoreResult.replace('{added}','1').replace('{total}','26')+' '+ui.managerListComplete;
  for(let i=0;i<40;i++){await page.waitForTimeout(100);const emitted=(await readFile(output+'/orca-presentations.jsonl','utf8')).trim().split('\n').filter(Boolean).map(JSON.parse).slice(speechStart);if(emitted.map(x=>x.text).join(' ').replace(/\s+/gu,' ').includes(expected))break;}
  receipt.pagination.automaticResultSpeech=(await readFile(output+'/orca-presentations.jsonl','utf8')).trim().split('\n').filter(Boolean).map(JSON.parse).slice(speechStart);
  receipt.pagination.expectedResult=expected;
  receipt.pagination.retainedControl=await originalControl.evaluate(el=>{const r=el.getBoundingClientRect();return {sameFocusedNode:el===document.activeElement,connected:el.isConnected,nativeDisabled:el.disabled,ariaDisabled:el.getAttribute('aria-disabled'),focusVisible:el.matches(':focus-visible'),visibleRect:{x:r.x,y:r.y,width:r.width,height:r.height},withinViewport:r.left>=0&&r.right<=innerWidth&&r.top>=0&&r.bottom<=innerHeight,ringClearance:{viewportBottom:innerHeight-r.bottom,mainBottom:(el.closest("main")?.getBoundingClientRect().bottom??innerHeight)-r.bottom},viewport:{width:innerWidth,height:innerHeight,visualHeight:visualViewport?.height,dpr:devicePixelRatio}}});
  await action('last-page-end',['ctrl+End'],500);
  for(let i=0;i<45;i++)await action('last-page-up-'+i,['Up'],110);
  for(let i=0;i<50;i++)await action('last-page-down-'+i,['Down'],110);
 }
 const tree=JSON.parse(execFileSync('/usr/bin/python3',[root+'/inspect-atspi.py'],{encoding:'utf8',timeout:20000}));await writeFile(output+'/atspi-tree.json',JSON.stringify(tree,null,2));receipt.atspi={nodes:tree.length,documents:tree.filter(x=>x.role.includes('document')),focused:tree.filter(x=>x.focused)};
 const speech=(await readFile(output+'/orca-presentations.jsonl','utf8').catch(()=>'' )).trim().split('\n').filter(Boolean).map(JSON.parse);
 receipt.actualOrcaPresentations=speech;
 receipt.domFocusedTag=await page.evaluate(()=>document.activeElement?.tagName);receipt.url=new URL(page.url()).pathname;
 // Preserve original Orca events; join visual line-wrap whitespace after a spoken hyphen.
 const norm=s=>s.replace(/\s+/gu,' ').replace(/-\s+(?=\p{L})/gu,'-').trim();const spoken=norm(speech.map(x=>x.text).join(' '));
 const segment=spoken.slice(spoken.indexOf('Today Employee 01'),spoken.indexOf('Today Employee 02',spoken.indexOf('Today Employee 01')));receipt.absentEmployeeSpeech=segment;
 receipt.assertions.push({name:'absent-employee-name-associated-with-localized-not-started',pass:segment.includes(norm(ui.managerAttendanceState.SCHEDULED_NOT_STARTED))},{name:'absent-employee-plan-and-UTC-window',pass:segment.includes('Today published UTC fixture')&&segment.includes('UTC')},{name:'absent-employee-non-presence-boundary',pass:segment.includes(norm(ui.managerPresenceBoundary))},{name:'recorded-no-show-is-distinct',pass:spoken.includes(norm(ui.managerAttendanceState.NO_SHOW))},{name:'native-load-more-control-spoken',pass:(receipt.pagination.speechBeforeActivation??[]).some(x=>x.text.includes(ui.managerLoadMore))},{name:'appended-absent-employee-26-reached-by-real-Orca',pass:spoken.includes('Today Employee 26')});
 receipt.assertions.push({name:'focus-stays-on-same-native-control-at-exhaustion',pass:receipt.pagination.retainedControl?.sameFocusedNode===true&&receipt.pagination.retainedControl?.nativeDisabled===false&&receipt.pagination.retainedControl?.ariaDisabled==='true'},{name:'actual-Orca-automatic-localized-count-and-end-result',pass:norm((receipt.pagination.automaticResultSpeech??[]).map(x=>x.text).join(' ')).includes(norm(receipt.pagination.expectedResult??'__missing__'))},{name:'retained-focus-visible-and-within-viewport',pass:receipt.pagination.retainedControl?.focusVisible===true&&receipt.pagination.retainedControl?.withinViewport===true});
 receipt.status=receipt.assertions.every(x=>x.pass)?'ACTUAL_AT_READING_OBSERVED':'AT_READING_NOT_ESTABLISHED';
} catch(e){receipt.status='FAIL';receipt.failure={stage,type:e.name,code:e.code??null,categories:['ERR_BLOCKED_BY_ADMINISTRATOR','ERR_CONNECTION_REFUSED','Timeout','Navigation','Target closed'].filter(x=>e.message.includes(x))};}
finally {await write();await context.close();}
