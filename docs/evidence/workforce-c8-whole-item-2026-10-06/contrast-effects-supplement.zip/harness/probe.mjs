import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { sampleTodayContrast } from './contrast-helper.mjs';
const root = process.env.WF_AT_ROOT, output = process.env.WF_AT_OUTPUT;
const origin = 'http://localhost:' + process.env.WF_AT_PORT;
const require = createRequire(root + '/source/package.json');
const { chromium } = require('playwright');
const fixture = JSON.parse(await readFile(root + '/fixture-private.json', 'utf8'));
const locale = process.env.WF_AT_LOCALE || 'ru';
const ui = JSON.parse(await readFile(root + '/source/messages/' + locale + '.json', 'utf8')).workforcePage;
const receipt = { status: 'RUNNING', locale, sourceParent: '30c4185b41d85be43a588e71d8c74c5f34e63596', sourceBinding: 'Exact integrated 30c source; supplemental computed-style guard, no new AT claim', assertions: [], responses: [], actions: [], audio: 'ALSA null; actual Orca original speak dispatch, no human listening', runtime: 'development; scoped synthetic fixture' };
const save = () => writeFile(output + '/at-receipt.json', JSON.stringify(receipt, null, 2));
const keys = (...args) => execFileSync('xdotool', args, { encoding: 'utf8', timeout: 10000 });
const context = await chromium.launchPersistentContext(output + '/chromium-profile', { headless: false, executablePath: '/usr/bin/chromium', baseURL: origin, viewport: { width: 1380, height: 900 }, args: ['--force-renderer-accessibility', '--no-sandbox', '--disable-dev-shm-usage'] });
const page = context.pages()[0]; page.setDefaultTimeout(60000);
let stage = 'auth';
const speech = async () => (await readFile(output + '/orca-presentations.jsonl', 'utf8').catch(() => '')).split('\n').filter(Boolean).map(JSON.parse);
async function login(actor) {
  const csrf = await context.request.get('/api/auth/csrf', { timeout: 120000 }); assert.equal(csrf.status(), 200);
  const response = await context.request.post('/api/auth/callback/credentials', { timeout: 120000, headers: { 'X-Auth-Return-Redirect': '1' }, form: { csrfToken: (await csrf.json()).csrfToken, email: actor.email, password: fixture.password, organizationSlug: actor.slug, callbackUrl: origin + '/workforce' } });
  assert.equal(response.status(), 200); assert.equal(new URL((await response.json()).url, origin).searchParams.get('error'), null);
  const session = await context.request.get('/api/auth/session'); const user = (await session.json()).user;
  assert.equal(user.id, actor.id); assert.equal(user.organizationId, actor.organizationId);
}

try {
  receipt.contrast=[];
  for(const language of ['en','ru','az']) {
    await context.addCookies([{name:'NEXT_LOCALE',value:language,url:origin}]);
    for(const [role,actor,status] of [['denied',fixture.denied,403],['manager',fixture.manager,200]]) {
      stage=language+'-'+role; await login(actor);
      const wait=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/v1/workforce/today');
      await page.goto('/workforce',{waitUntil:'domcontentloaded',timeout:120000}); assert.equal((await wait).status(),status);
      await page.locator(role==='manager'?'section[aria-labelledby="workforce-manager-today-list"] article':'[role="alert"] p').first().waitFor();
      for(const theme of ['light','dark']) {
        await page.evaluate(theme=>{document.documentElement.classList.toggle('dark',theme==='dark');document.documentElement.classList.toggle('light',theme==='light')},theme);await page.waitForTimeout(400);
        receipt.contrast.push(await sampleTodayContrast(page,language+'-'+role+'-'+theme));
      }
    }
  }
  const samples=receipt.contrast.flatMap(x=>x.samples), checked=samples.filter(x=>x.checked);
  receipt.assertions=[{name:'all12-locale-role-theme-cases-present',pass:receipt.contrast.length===12},{name:'checked-samples-have-no-unsupported-effects',pass:checked.length>0&&checked.every(x=>x.effects.length===0)},{name:'all-checked-text-contrast-at-least4.5',pass:checked.length>0&&checked.every(x=>x.pass)}];
  receipt.summary={checked:checked.length,minimum:Math.min(...checked.map(x=>x.ratio)),unsupported:checked.filter(x=>x.effects.length),failed:checked.filter(x=>!x.pass),excluded:samples.filter(x=>!x.checked)};
  receipt.status=receipt.assertions.every(x=>x.pass)?'PASS':'NEGATIVE_REPRODUCED';
} catch(error) {receipt.status='FAIL';receipt.failure={stage,type:error.name,categories:['Timeout','Target closed'].filter(x=>error.message.includes(x))};}
finally {await save();await context.close();}
process.exitCode=receipt.status==='PASS'?0:1;
