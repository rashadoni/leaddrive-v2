export async function sampleTodayContrast(page, labels) {
  return page.evaluate(({ labels }) => {
    const ctx = document.createElement('canvas').getContext('2d', { willReadFrequently: true });
    function rgba(value) { ctx.clearRect(0, 0, 1, 1); ctx.fillStyle = value; ctx.fillRect(0, 0, 1, 1); const c = [...ctx.getImageData(0, 0, 1, 1).data]; c[3] /= 255; return c; }
    function over(a, b) { return [0, 1, 2].map(i => a[i] * a[3] + b[i] * (1 - a[3])).concat(1); }
    function luminance(c) { const x = c.slice(0, 3).map(v => { const a = v / 255; return a <= .04045 ? a / 12.92 : ((a + .055) / 1.055) ** 2.4; }); return x[0] * .2126 + x[1] * .7152 + x[2] * .0722; }
    const list = document.querySelector('section[aria-labelledby="workforce-manager-today-list"]');
    const nodes = [...(list?.querySelectorAll('article p, article .rounded-full, button, a, h3') || [])];
    for (const el of document.querySelectorAll('[role="alert"] p, [role="alert"] button')) nodes.push(el);
    const selected = []; const seen = new Set();
    for (const el of nodes) {
      const style = getComputedStyle(el); const rect = el.getBoundingClientRect(); if (!rect.width || !rect.height || !el.textContent.trim()) continue;
      let background = [255, 255, 255, 1], opacity = 1; const ancestors = []; let p = el;
      while (p) { ancestors.unshift(p); p = p.parentElement; }
      const gradients = []; const effects = [];
      for (const a of ancestors) { const s = getComputedStyle(a); opacity *= Number(s.opacity); if (s.backgroundImage !== 'none') gradients.push(s.backgroundImage); background = over(rgba(s.backgroundColor), background);
        for (const [property, expected] of [['filter','none'],['backdropFilter','none'],['mixBlendMode','normal'],['textShadow','none'],['maskImage','none']]) {
          const value = s[property]; if (value && value !== expected) effects.push({ tag: a.tagName, property, value });
        }
        for (const pseudo of ['::before','::after']) { const q=getComputedStyle(a,pseudo); if (!['none','normal'].includes(q.content) && q.display !== 'none' && q.visibility !== 'hidden' && Number(q.opacity)!==0) effects.push({tag:a.tagName,pseudo,content:q.content,background:q.backgroundColor,backgroundImage:q.backgroundImage}); }
      }
      const foreground = over(rgba(style.color), background); const l1 = luminance(foreground), l2 = luminance(background); const ratio = (Math.max(l1, l2) + .05) / (Math.min(l1, l2) + .05);
      const label = el.textContent.trim(); const key = [el.tagName, style.color, style.backgroundColor, style.fontSize, background.join(','), JSON.stringify(effects), opacity, el.className, label.includes('Today Employee') ? 'employee' : label].join('|'); if (seen.has(key)) continue; seen.add(key);
      const inactive = el.getAttribute('aria-disabled') === 'true' || el.matches(':disabled');
      selected.push({ text: label.includes('Today Employee') ? '[synthetic employee name]' : label.slice(0, 160), tag: el.tagName, color: style.color, backgroundColor: style.backgroundColor, compositeForeground: foreground.slice(0, 3), compositeBackground: background.slice(0, 3), ratio, fontSize: style.fontSize, opacity, inactive, gradients, effects, hover: el.matches(':hover'), focusVisible: el.matches(':focus-visible'), checked: !inactive && opacity === 1 && gradients.length === 0, pass: ratio >= 4.5 });
    }
    return { theme: document.documentElement.classList.contains('dark') ? 'dark' : 'light', viewport: { width: innerWidth, height: innerHeight }, documentWidth: document.documentElement.scrollWidth, labels, samples: selected, scope: 'Supplement: dedupe includes composited ancestor background; computed filter/backdrop/mix-blend/text-shadow/mask and visible pseudo guards; sampled rendered text and controls only; no whole-page WCAG claim; active samples require >=4.5; inactive opacity/gradient samples qualified separately' };
  }, { labels });
}
