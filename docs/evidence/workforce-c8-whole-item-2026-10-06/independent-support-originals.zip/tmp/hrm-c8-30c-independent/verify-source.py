import pathlib,json,hashlib
D=pathlib.Path('/tmp');W=pathlib.Path('/workspace/hrm-c8-completion-20261006');R=pathlib.Path('/workspace/hrm-c8-session-at-20261006')
def j(k):return json.loads((D/f'hrm-c8-30c-independent-{k}.json').read_text())
def bm(k):return {x['path']:(x['mode'],x['sha']) for x in j(k)['tree'] if x['type']=='blob'}
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
a,parent,main,old=bm('tree'),bm('parent'),bm('mainTree'),bm('oldMain');assert len(a)==8844
expected={x['path']:(x['mode'],x['sha']) for x in json.load(open(D/'hrm-c8-acceptance-20261006/final-source-expected-tree.json'))};assert a==expected
for p,(m,s) in a.items():
 f=W/p;assert blob(f.read_bytes())==s,p;assert bool(f.stat().st_mode&0o111)==(m=='100755'),p
nodes={}
for path,val in a.items():
 t=nodes;parts=path.split('/')
 for p in parts[:-1]:t=t.setdefault(p,{})
 t[parts[-1]]=val
def th(t):
 out=b''
 for n,v in sorted(t.items(),key=lambda kv:(kv[0]+('/' if isinstance(kv[1],dict) else '')).encode()):
  mode,sha=('40000',th(v)) if isinstance(v,dict) else v
  out+=mode.encode()+b' '+n.encode()+b'\0'+bytes.fromhex(sha)
 return hashlib.sha1(b'tree '+str(len(out)).encode()+b'\0'+out).hexdigest()
assert th(nodes)=='9302e6432c64e818d7859dae78977a35fc996749'
assert j('synthetic')['tree']['sha']==th(nodes)
texts=j('remote-delta');assert len(texts)==22
for x in texts:assert x['content'].encode()==(W/x['path']).read_bytes();assert blob(x['content'].encode())==a[x['path']][1]
changes=sorted(p for p in set(main)|set(old) if main.get(p)!=old.get(p));assert len(changes)==11
for p in changes:
 if not p.startswith('messages/'):assert a.get(p)==main[p]
def flat(v,p=''):
 if not isinstance(v,dict):return {p:v}
 r={}
 for k,x in v.items():r.update(flat(x,p+'.'+k if p else k))
 return r
mc={x['path']:flat(json.loads(x['content'])) for x in j('catalog-mainTree')};oc={x['path']:flat(json.loads(x['content'])) for x in j('catalog-oldMain')}
translation=[]
for p in mc:
 final=flat(json.load(open(W/p))); runtime=flat(json.load(open(R/'source'/p)));incoming={k:v for k,v in mc[p].items() if k not in oc[p] or oc[p][k]!=v};actual={k:v for k,v in final.items() if k not in runtime or runtime[k]!=v}
 assert incoming==actual,(p,set(incoming)^set(actual));assert not(set(runtime)-set(final));assert all(final[k]==v for k,v in runtime.items() if k.startswith(('workforcePage.','nav.','common.')))
 translation.append({'path':p,'incomingLeaves':len(incoming),'keys':sorted(incoming),'entireOtherExistingCatalogLeavesPreserved':True})
frozen=json.load(open(R/'source-manifest.json')); fpaths={x['path'] for x in frozen};transferChanges=[]
for x in frozen:
 p=x['path'];rb=(R/'source'/p).read_bytes();assert hashlib.sha256(rb).hexdigest()==x['sha256'];assert bool((R/'source'/p).stat().st_mode&0o111)==(x['mode']=='100755')
 if a[p][1]!=blob(rb) or a[p][0]!=x['mode']:transferChanges.append(p)
assert set(transferChanges)<=set(changes)
extra=sorted(set(a)-fpaths);assert len(extra)==11
assert not(fpaths-set(a))
oldAccepted=json.load(open('/tmp/hrm-c8-immutable-independent-parentAccepted.json'));ap={x['path']:(x['mode'],x['sha']) for x in oldAccepted['tree'] if x['type']=='blob'}
common=json.load(open('/tmp/hrm-c8-immutable-independent-common.json'));cp={x['path']:(x['mode'],x['sha']) for x in common['tree'] if x['type']=='blob'}
acceptedDelta={p for p in set(ap)|set(cp) if ap.get(p)!=cp.get(p)};assert len(acceptedDelta)==162;exceptions=sorted(p for p in acceptedDelta if ap.get(p)!=a.get(p));assert exceptions==['messages/az.json','messages/en.json','messages/ru.json']
ledger='docs/workforce-hrm-completion-roadmap-2026-08-30.md';assert a[ledger]==ap[ledger]
result={'sourceHead':j('commit')['sha'],'tree':th(nodes),'blobs':8844,'allLocalBlobBytesModesEqualIndependentRemoteTree':True,'remoteChangedTextBlobsExact':22,'deltaFromD97':sorted(p for p in set(a)|set(parent) if a.get(p)!=parent.get(p)),'incomingMainPaths':changes,'allEightNoncatalogMainPathsExact':True,'translationProof':translation,'ATFrozenSourceFiles':len(frozen),'ATToFinalChangedExistingFiles':sorted(transferChanges),'ATToFinalAddedFiles':extra,'noATFrozenFileDeleted':True,'allATSourceRuntimeBytesModesVerified':True,'acceptedC7Delta':162,'acceptedC7Noncatalog159Exact':True,'canonicalLedgerUnchanged':True}
p=D/'hrm-c8-30c-independent/source-validation.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
