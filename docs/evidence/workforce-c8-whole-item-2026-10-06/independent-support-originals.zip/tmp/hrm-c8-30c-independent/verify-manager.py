import json, pathlib, hashlib, zipfile, datetime
P=pathlib.Path; R=P('/tmp/hrm-c8-30c-independent'); D=P('/tmp/hrm-c8-acceptance-20261006/hosted-30c-manager'); W=P('/workspace/hrm-c8-completion-20261006')
H='30c4185b41d85be43a588e71d8c74c5f34e63596'; S='99009aff39ae1445e2f43eb3c748db3fe7a3e122'
def read(p):return json.loads(P(p).read_text())
def bind(p):
 p=P(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
m=read(R/'manager-hosted-metadata.json');run=m['run'];jobs=m['jobs']['jobs'];arts=m['artifacts']['artifacts']
assert run['id']==37531925881 and run['head_sha']==H and run['run_attempt']==1 and run['conclusion']=='success'
assert len(jobs)==m['jobs']['total_count']==1 and jobs[0]['id']==112503175669 and jobs[0]['head_sha']==H and jobs[0]['conclusion']=='success'
assert all(s['conclusion'] in ('success','skipped') for s in jobs[0]['steps'])
assert len(arts)==m['artifacts']['total_count']==1 and arts[0]['id']==11444363837 and not arts[0]['expired']
z=P('/workspace/attachments/f15a286e-fd4e-4fb9-9add-184458504261/c8-30c-manager-sanitized-evidence.zip')
zb=bind(z);assert zb['bytes']==arts[0]['size_in_bytes'] and 'sha256:'+zb['sha256']==arts[0]['digest']
with zipfile.ZipFile(z) as zipf:
 allowed=['manager-today-receipt.json','workflow-context.json']
 assert len(zipf.namelist())==len(set(zipf.namelist()))
 for n in allowed:assert zipf.read(n)==(D/n).read_bytes()
 # PNG entries are intentionally not opened, CRC-tested or visually inspected.
 names=zipf.namelist()
x=read(D/'manager-today-receipt.json'); c=read(D/'workflow-context.json')
assert x['candidateHead']==H and x['checkedMergeSha']==S and x['status']=='PASS' and x['nativeZoomVerdict']=='PASS'
assert c['headSha']==H and c['ciSha']==S and c['runId']==str(run['id']) and c['runAttempt']=='1' and c['productionMutation'] is False
tree=read('/tmp/hrm-c8-30c-independent-tree.json');tm={v['path']:v for v in tree['tree'] if v['type']=='blob'}
assert len(x['sourceBindings'])==len({r['path'] for r in x['sourceBindings']})==58
for sb in x['sourceBindings']:
 b=(W/sb['path']).read_bytes();assert len(b)==sb['bytes'] and hashlib.sha256(b).hexdigest()==sb['sha256']
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==tm[sb['path']]['sha']
assert x['harnessSha256']==x['sourceBindings'][0]['sha256']
cases=x['cases'];assert len(cases)==len({c['name'] for c in cases})==9 and all(c['status']=='PASS' for c in cases)
expected={'manager-en','manager-ru','manager-az','approver-ru','forged-tenant-headers-remain-session-bound','no-grant-real-session-denied','manager-en-native-200','manager-ru-native-200','manager-az-native-200'}
assert {c['name'] for c in cases}==expected
for v in cases:
 if 'firstPage' in v:
  assert (v['firstPage'],v['secondPage'],v['finalUniqueOrderedPeople'])==(25,1,26)
  assert set(v['currentSnapshotStates'])=={'STARTED','PAUSED','COMPLETED'}
  for k in ['canonicalSnapshotLinksAndFrozenUtcPlan','missingCurrentSnapshotUnavailableExplained','liveAssignmentDoesNotReconstructExistingWorkday','scheduledWithoutWorkdayExplained','previousOpenRetained','leaveAndHolidayExplained','unavailableScheduleExplained','nativePaginationEnter','readOnlyWorkforceRequests','realSessionPreserved']: assert v[k] is True,(v['name'],k)
  assert all(all(g[k] for k in ['positive','withinViewport','untruncated','displayed','stateTextMatched']) for g in v['pageTwoAbsenceGeometry'])
  assert v['exceptionsNullWithoutAuthority'] == (v['name']=='approver-ru')
  assert v['persistedNoShowAuthority'] == (v['name']!='approver-ru')
 if 'nativeZoom' in v:
  nz=v['nativeZoom'];assert nz['factor']==2 and nz['zoomed']['devicePixelRatio']==2 and nz['control']['devicePixelRatio']==1 and nz['zoomed']['width']==320 and nz['control']['width']==640
  assert nz['viewportEmulation'] is False and nz['applicationCssChanged'] is False
denied=next(c for c in cases if c['name']=='no-grant-real-session-denied')
assert denied['responseStatus']==403 and denied['namesAndFactsExcluded'] and denied['noRosterRendered'] and denied['localizedErrorRendered']
forged=next(c for c in cases if c['name'].startswith('forged-'));assert forged['responseStatus']==200 and forged['foreignPeopleExcluded'] and forged['authenticatedTenantPreserved']
assert len(x['focusGeometryDiagnostics'])==6
for d in x['focusGeometryDiagnostics']:
 assert d['status']=='PASS'
 for k in ['first','last']:
  g=d[k];assert g['pass'] and g['focused'] and g['focusVisible'] and g['connected'] and not g['disabled'] and all(g['clauses'].values())
  t=g['target'];v=g['viewport'];main=g['main'];assert t['top']>=max(0,main['top']) and t['bottom']<=min(v['height'],main['bottom']) and t['left']>=max(0,main['left']) and t['right']<=min(v['width'],main['right'])
auth=x['authenticationDiagnostics'];assert len(auth)==8 and all(v['csrfStatus']==v['callbackStatus']==200 for v in auth)
guards=x['snapshotDatabaseGuards'];assert guards['disposableAdminTransactionsOnly'] and not guards['productionMigrationsChanged'] and not guards['appWritePrivilegesAdded']
assert len(guards['results'])==len({g['name'] for g in guards['results']})==10
for g in guards['results']:assert g['status']=='PASS' and g['postgresCode'] in ('55000','23514') and g['stagedFactCreatedBeforeError'] and (g['stagedWorkdayCount'],g['committedWorkdayCountAfter'])==(6,5) and g['allFactHashesAndCountsRestored']
for phase in ['rlsBefore','rlsAfter']:
 rr=x[phase];assert rr['tenantContextAbsent'] and rr['bypassAbsent'] and rr['unsafeRolePrivilegesAbsent']
 assert len(rr['counts'])==len({v['table'] for v in rr['counts']})==21
 assert all(v['unscopedVisibleRows']==0 and v['forcedRls'] and not v['appOwnsTable'] for v in rr['counts'])
 assert sum(v['syntheticRows']>0 for v in rr['counts'])==16
assert x['rlsBefore']['counts']==x['rlsAfter']['counts']
facts=x['factImmutability'];assert facts['status']=='PASS' and facts['tenantCount']==2 and facts['userAuthenticationMetadataExcluded']
assert len(facts['tables'])==len({v['table'] for v in facts['tables']})==20
assert all(v['sha256']==v['afterSha256'] and v['unchanged'] for v in facts['tables'])
assert x['cleanup']=='PASS' and len(x['cleanupActions'])==11 and all(v['status']=='PASS' for v in x['cleanupActions'])
r={'schema':'independent-c8-hosted-manager-review/v1','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'EXACT_30C_R2_BOUNDED_HOSTED_MANAGER_ACCEPTED','head':H,'synthetic':S,'tree':tree['sha'],'run':run['id'],'attempt':1,'job':jobs[0]['id'],'artifact':arts[0]['id'],'metadataIndependentlyFetched':True,'archive':{**zb,'matchedGitHubDigest':True,'onlyTwoJsonMembersRead':allowed,'otherMemberContentsNotRead':len(names)-2},'sourceBindings':x['sourceBindings'],'accepted':{'cases':9,'uniqueCaseNames':sorted(expected),'native200Languages':['en','ru','az'],'strictFocusChecksRecomputed':6,'realAuthCsrfCredentialsPairs':8,'positiveCurrentSnapshotStates':['STARTED','PAUSED','COMPLETED'],'missingCurrentSnapshotExplicit':True,'snapshotNamedDatabaseGuards':guards['results'],'rlsTables':21,'populated':16,'empty':5,'beforeAfterUnscopedZero':True,'factTablesUnchanged':20,'twoSyntheticTenants':True,'cleanupActionsPassed':11},'limits':x['limitations']+['Original JSON parsed in full and finite assertions independently checked; no PNG content, raw application/CI logs or visual screenshots inspected. Receipt screenshot booleans are producer assertions, not reviewer visual evidence.', 'Schema setup is prisma db push plus named fixture RLS/snapshot guard SQL, not full historical migration replay. Empty tables establish only configured FORCE RLS/unscoped empty result; they do not prove positive-row rejection.', 'Fact hashing excludes user authentication metadata; snapshot negative probes run as disposable admin, not app write capability.', 'Native 200% uses fixture extension browser tab zoom, not human keyboard or Orca; real AT remains separately source-bound.', 'Other exact-head CI/build lanes are not accepted by this R2 receipt; no whole-C8 ledger transition yet.'],'findings':{'P0':[],'P1':[],'P2':[],'P3':[]},'history':'Prior d97 strict fractional-focus negative remains preserved; this exact30c first attempt passes the unchanged strict geometry predicates. No prior failure was erased.','supportBindings':[bind(R/'manager-hosted-metadata.json'),bind(D/'manager-today-receipt.json'),bind(D/'workflow-context.json'),bind(D/'member-inventory.json'),bind(R/'verify-manager.py'),bind('/tmp/hrm-c8-independent-source-transfer-30c-20261006.json')]}
out=P('/tmp/hrm-c8-independent-hosted-manager-30c-20261006.json');out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(bind(out)))
