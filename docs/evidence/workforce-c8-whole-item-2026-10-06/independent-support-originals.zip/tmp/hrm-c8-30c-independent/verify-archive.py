import pathlib,json,hashlib,zipfile,stat,datetime
P=pathlib.Path;R=P('/tmp/hrm-c8-30c-independent');A=P('/tmp/hrm-c8-acceptance-20261006');F=A/'final-packet'
def read(p):return json.loads(P(p).read_text())
def bind(p):
 p=P(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def gh(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
ct=read(R/'archive-commit.json');tree=read(R/'archive-tree.json');base=read('/tmp/hrm-c8-30c-independent-tree.json')
assert ct['sha']=='9bb70b2b742deec13d225aded25a896a1393eb90' and [x['sha'] for x in ct['parents']]==['30c4185b41d85be43a588e71d8c74c5f34e63596'] and ct['tree']['sha']==tree['sha']=='9eb9da388f51400f7ff97313d69f6dc253cd1e8c' and not tree['truncated']
b={x['path']:(x['sha'],x['mode']) for x in base['tree'] if x['type']=='blob'};t={x['path']:(x['sha'],x['mode']) for x in tree['tree'] if x['type']=='blob'}
assert len(b)==8844 and len(t)==8871 and all(t[p]==v for p,v in b.items())
files=read(A/'packet-files.json');assert len(files)==27 and set(t)-set(b)=={x['path'] for x in files}
texts={x['path']:x for x in read(R/'archive-text-readback.json')};assert len(texts)==25
for x in files:
 p=F/x['relative'];content=p.read_bytes();assert len(content)==x['bytes'] and hashlib.sha256(content).hexdigest()==x['sha256'] and gh(content)==x['sha']==t[x['path']][0] and t[x['path']][1]=='100644'
 if not x['binary']:assert texts[x['path']]['content'].encode()==content
assert (F/'independent-source-transfer-30c.json').read_bytes()==P('/tmp/hrm-c8-independent-source-transfer-30c-20261006.json').read_bytes()
assert (F/'independent-hosted-manager-30c.json').read_bytes()==P('/tmp/hrm-c8-independent-hosted-manager-30c-20261006.json').read_bytes()
zipResults=[];archivedHashes={x['sha256'] for x in files}
for name,expected,root in [('session-and-pagination-originals.zip',223,P('/workspace/hrm-c8-session-at-20261006')),('contrast-effects-supplement.zip',24,P('/workspace/hrm-c8-contrast-at-20261006'))]:
 p=F/name
 with zipfile.ZipFile(p) as z:
  ns=z.namelist();assert len(ns)==len(set(ns))==expected and 'MANIFEST.json' in ns
  assert all(not n.startswith('/') and '..' not in P(n).parts and not n.endswith(('.log','.png','.jpg','.sock')) and not any(v in P(n).parts for v in ['private-fixture','profile','cache','xauthority']) for n in ns)
  assert all(not stat.S_ISLNK(i.external_attr>>16) for i in z.infolist())
  manifest=json.loads(z.read('MANIFEST.json'));assert len(manifest)==expected-1 and {x['path'] for x in manifest}==set(ns)-{'MANIFEST.json'}
  assert z.testzip() is None
  for x in manifest:
   raw=z.read(x['path']);assert len(raw)==x['bytes'] and hashlib.sha256(raw).hexdigest()==x['sha256'];archivedHashes.add(x['sha256'])
   rel=x['path'];origin=root/(rel[8:] if rel.startswith('harness/') else rel)
   assert origin.read_bytes()==raw,str(origin)
  if name.startswith('session'):
   external=read(F/'session-and-pagination-originals-manifest.json');assert external==manifest
 zipResults.append({**bind(p),'members':expected,'manifestRows':expected-1,'CRCAndHashLengthsPass':True,'memberBytesMatchOriginals':True,'remoteGitBlob':t['docs/evidence/workforce-c8-whole-item-2026-10-06/'+name][0],'remoteBinaryPayloadReadback':False})
readme=(F/'README.md').read_text();assert 'PENDING' in readme and 'Canonical ledger remains 83/161' in readme and 'Remote binary payload readback is NOT PERFORMED' in readme
supports=[]
for name in ['independent-source-transfer-30c.json','independent-hosted-manager-30c.json']:
 d=read(F/name)
 for x in d.get('supportBindings',[])+d.get('recursiveOriginalATSupportBindings',[]):
  if isinstance(x,dict) and 'path' in x and 'sha256' in x:
   p=P(x['path']);assert p.is_file();assert bind(p)['sha256']==x['sha256'];supports.append({**x,'preservedInNewPacketByRawHash':x['sha256'] in archivedHashes})
missing=[x for x in supports if not x['preservedInNewPacketByRawHash']]
r={'schema':'independent-c8-finite-packet-durability/v1','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'IMMUTABLE_EVIDENCE_CHECKPOINT_ACCEPTED_WITH_BINARY_AND_SUPPORT_BOUNDARIES_R5_PENDING','commit':ct['sha'],'tree':tree['sha'],'parent':ct['parents'][0]['sha'],'sourceUnchanged':True,'priorBlobsAndModesPreserved':8844,'totalBlobs':8871,'additions':27,'actualUtf8RemoteReadbacks':25,'binaryBlobsTreeAndLocalGitHashBound':2,'binaryRemotePayloadReadback':False,'publishedIndependentSourceAndHostedReceiptsByteExact':True,'packetPathManifestBindings':files,'localOriginalArchiveVerification':zipResults,'preparedR6Terms':bind('/tmp/hrm-c8-independent-r6-prepared-ledger-20261006.json'),'recursiveSupportAudit':{'allLocalOriginalHashesVerified':len(supports),'newPacketRawHashCovered':len(supports)-len(missing),'notAddedAsRawOriginalToThisPacket':missing,'qualification':'Remote source trees/metadata/verifier programs and some historical receipts remain local or previously archived; this receipt does not claim every hash-bound /tmp support file is newly durable. Independent receipts are verbatim, source objects immutable, both original safe archive member sets verified. Binary remote payload retrieval was not attempted.'},'findings':{'P0':[],'P1':[],'P2':[],'P3':[]},'pending':['Exact30c current full hosted compiler/build and complete applicable jobs acceptance.','Final whole-item acceptance and conditional sole C8-002 ledger change; current83/161 remains.','A subsequent closure head must retain this immutable checkpoint and receive its own applicable CI; this receipt does not move any branch.'],'supportBindings':[bind(R/'archive-commit.json'),bind(R/'archive-tree.json'),bind(R/'archive-text-readback.json'),bind(A/'packet-files.json'),bind(A/'packet-publication.json'),bind(R/'verify-archive.py')],'inspectionLimits':'No raw app/CI logs, PNG screenshots, private fixture, credentials or browser/process interaction. Only explicitly safe archive members parsed.'}
out=P('/tmp/hrm-c8-independent-packet-durable-9bb70-20261006.json');out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'receipt':bind(out),'supportCovered':len(supports)-len(missing),'supportLocalOrPrior':len(missing)}))
