import pathlib,json,hashlib,zipfile,stat
D=pathlib.Path('/tmp/hrm-c8-30c-independent');C=pathlib.Path('/workspace/hrm-c8-contrast-at-20261006');R=pathlib.Path('/workspace/hrm-c8-session-at-20261006');run=C/'run-0crzwea6';h=lambda b:hashlib.sha256(b).hexdigest()
remote=json.load(open('/tmp/hrm-c8-30c-independent-tree.json'));t={x['path']:x for x in remote['tree'] if x['type']=='blob'};m=json.load(open(run/'source-manifest.json'));assert len(m)==8844;assert h((run/'source-manifest.json').read_bytes())=='c901a63016fc966df40fbc3e96d9c6d7b3c41088f5038210f39ff4ffc99da881'
for x in m:
 p=C/'source'/x['path'];b=p.read_bytes();assert h(b)==x['sha256'];assert bool(p.stat().st_mode&0o111)==(x['mode']=='100755');assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==t[x['path']]['sha']
a=json.load(open(run/'at-receipt.json'));assert a['sourceParent']=='30c4185b41d85be43a588e71d8c74c5f34e63596';assert a['status']=='PASS' and all(x['pass'] for x in a['assertions'])
assert {x['labels'] for x in a['contrast']}=={f'{l}-{r}-{s}' for l in ['en','ru','az'] for r in ['denied','manager'] for s in ['light','dark']}
samples=[s for c in a['contrast'] for s in c['samples']];assert len(samples)==174
ratios=[]
def lum(c):
 v=[x/255 for x in c];v=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in v];return sum(x*w for x,w in zip(v,[.2126,.7152,.0722]))
for s in samples:
 assert s['effects']==s['gradients']==[] and s['opacity']==1 and not s['inactive'] and s['checked'];lo,hi=sorted([lum(s['compositeForeground']),lum(s['compositeBackground'])]);ratio=(hi+.05)/(lo+.05);assert abs(ratio-s['ratio'])<1e-10 and ratio>=4.5 and s['pass'];ratios.append(ratio)
before=json.load(open(run/'executed-script-hashes-before.json'));assert before==json.load(open(run/'executed-script-hashes-after.json'))
for n in ['probe','contrast-helper']:assert h((run/f'executed-{n}.mjs').read_bytes())==before[n+'.mjs']
clean=json.load(open(run/'cleanup.json'));assert len(clean)==7 and all(x['exit'] is not None for x in clean)
zipPath=pathlib.Path('/tmp/hrm-c8-acceptance-20261006/session-and-pagination-originals-complete.zip');assert h(zipPath.read_bytes())=='b7f5404e309a83cb28f5919d85233078c0d88bdfb98219d5309fbfccb33b8fa5'
allowed={'at-receipt.json','source-manifest.json','orca-presentations.jsonl','orca-dispatch-completed.jsonl','executed-script-hashes-before.json','executed-script-hashes-after.json','cleanup.json','safe-error-categories.json','backend-check.json','supervisor-events.json','app-ready.json','executed-probe.mjs','executed-pagination-probe.mjs','executed-contrast-helper.mjs','atspi-tree.json'};negativeSources=[];statuses=[];nodes=0
with zipfile.ZipFile(zipPath) as z:
 assert len(z.namelist())==len(set(z.namelist()))==223;assert z.testzip() is None;manifest=json.loads(z.read('MANIFEST.json'));assert len(manifest)==222;assert set(z.namelist())=={'MANIFEST.json'}|{x['path'] for x in manifest}
 for x in manifest:
  p=pathlib.PurePosixPath(x['path']);assert not p.is_absolute() and '..' not in p.parts;info=z.getinfo(x['path']);assert not stat.S_ISLNK(info.external_attr>>16);assert not info.is_dir();b=z.read(x['path']);assert len(b)==x['bytes'] and h(b)==x['sha256'];local=R/(str(p).removeprefix('harness/'));assert local.read_bytes()==b,x['path']
  if p.parts[0]=='harness':assert len(p.parts)==2 and p.suffix in ['.json','.py','.mjs','.cjs']
  elif 'negative-source' in p.parts:negativeSources.append(str(p));assert p.suffix in ['.mjs','.tsx','.json']
  else:assert len(p.parts)==2 and p.name in allowed,str(p)
  if p.name=='at-receipt.json':q=json.loads(b);statuses.append({'run':p.parts[0],'status':q['status'],'passed':sum(v['pass'] for v in q.get('assertions',[])),'assertions':len(q.get('assertions',[]))})
  if p.name=='atspi-tree.json':
   q=json.loads(b);assert all(set(v)=={'depth','role','name','focused','children'} for v in q);assert not any('http://' in v['name'] or 'https://' in v['name'] or '@' in v['name'] for v in q);nodes+=len(q)
assert len(negativeSources)==15 and len(statuses)==14
out={'supplement':{'run':'run-0crzwea6','sourceManifestSha256':h((run/'source-manifest.json').read_bytes()),'all8844SourceBytesModesMatchExact30cRemoteTree':True,'cases':12,'samples':174,'minimum':min(ratios),'unsupported':0,'excluded':0,'allRatiosRecomputed':True,'originalScriptSnapshotsMatchStableBeforeAfter':True,'ownChildrenReaped':7,'newATClaim':False},'archive':{'path':str(zipPath),'sha256':h(zipPath.read_bytes()),'bytes':zipPath.stat().st_size,'members':223,'manifestRows':222,'allMemberHashLengthsCRCAndOriginalLocalBytesMatch':True,'allSafeRegularUniqueRelativePaths':True,'noRawLogsScreenshotsPrivateFixturesOrProfiles':True,'optionalAtspiNodesInspected':nodes,'explicitNegativeSourceFiles':negativeSources,'originalRunStatuses':statuses,'remoteBinaryReadback':False}}
p=D/'contrast-archive-validation.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
