import pathlib,json,hashlib,re
R=pathlib.Path('/workspace/hrm-c8-session-at-20261006');W=pathlib.Path('/workspace/hrm-c8-completion-20261006');D=pathlib.Path('/tmp/hrm-c8-30c-independent')
h=lambda b:hashlib.sha256(b).hexdigest();norm=lambda s:re.sub(r'-\s+(?=[^\W\d_])','-',re.sub(r'\s+',' ',s)).strip()
manifest=json.loads((R/'source-manifest.json').read_text());assert len(manifest)==8833 and h((R/'source-manifest.json').read_bytes())=='b2b9a917e3901a0c1f0ac6995b1f596f2904c27e265628169ba6b5c662d09ea5'
for root in [R/'source']:
 for x in manifest:
  p=root/x['path'];b=p.read_bytes();assert h(b)==x['sha256'],str(p)
  assert bool(p.stat().st_mode&0o111)==(x['mode']=='100755'),str(p)
def lum(c):
 v=[x/255 for x in c];v=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in v];return sum(x*w for x,w in zip(v,[.2126,.7152,.0722]))
runs=[];supported=[]
for n in [x['run'] for x in json.loads((R/'acceptance-matrix.json').read_text())]:
 p=R/n;a=json.loads((p/'at-receipt.json').read_text());events=[json.loads(x) for x in (p/'orca-presentations.jsonl').read_text().splitlines()];done=[json.loads(x) for x in (p/'orca-dispatch-completed.jsonl').read_text().splitlines()];assert len(events)==len(done) and len({x['time'] for x in events})==len(events);assert all(x['time']==y['time'] and y['completed'] for x,y in zip(events,done))
 before=json.loads((p/'executed-script-hashes-before.json').read_text());assert before==json.loads((p/'executed-script-hashes-after.json').read_text());assert (p/'source-manifest.json').read_bytes()==(R/'source-manifest.json').read_bytes()
 for s in ['probe','pagination-probe','contrast-helper']:
  f=p/f'executed-{s}.mjs'
  if f.exists():assert h(f.read_bytes())==before[s+'.mjs']
 clean=json.loads((p/'cleanup.json').read_text());assert len(clean)==7 and all(x['exit'] is not None for x in clean)
 assert all(x['pass'] for x in a['assertions']);ui=json.loads((W/'messages'/f"{a['locale']}.json").read_text())['workforcePage'];es={json.dumps(e,sort_keys=True) for e in events}
 row={'run':n,'locale':a['locale'],'assertions':len(a['assertions']),'speechCalls':len(events),'originalDispatchesReturned':True,'ownChildrenReaped':len(clean),'scriptSnapshotsBeforeAfterVerified':True}
 if 'transition' in a:
  for group in [a['denial']['actualSpeech'],a['transition']['pendingSpeech'],a['unavailable']['actualSpeech']]:assert all(json.dumps(e,sort_keys=True) in es for e in group)
  assert norm(ui['managerReadDenied']) in norm(' '.join(e['text'] for e in a['denial']['actualSpeech']))
  assert norm(ui['managerReadUnavailable']) in norm(' '.join(e['text'] for e in a['unavailable']['actualSpeech']))
  assert not any('Today Employee' in e['text'] for e in a['denial']['actualSpeech']+a['transition']['pendingSpeech'])
  assert not any('Synthetic private server detail' in e['text'] for e in a['unavailable']['actualSpeech'])
  t=a['transition'];assert t['oldStatus']==t['newStatus']==200 and t['oldRelease']=='fulfilled';assert all(t[k] for k in ['samePage','sameOrg','differentPrincipal','realCredentialsAndBroadcastChannel','newAttendanceOnlyExceptionsNull','noOldNamesWhileNewPending','oldCompletionDoesNotExposeRowsOrClearNewLoading','newRosterLoadedWithoutStaleAppend'])
  samples=[s for g in a['contrast'] for s in g['samples']];checked=[s for s in samples if s['checked']]
  assert len(checked)==58
  for s in checked:
   l1,l2=sorted([lum(s['compositeForeground']),lum(s['compositeBackground'])]);ratio=(l2+.05)/(l1+.05);assert abs(ratio-s['ratio'])<1e-10 and ratio>=4.5 and s['pass'];assert s['opacity']==1 and not s['inactive'] and s['gradients']==[]
  row.update({'checkedContrastSamples':58,'minimumSampledRGBRatio':min(s['ratio'] for s in checked),'unmodeledVisualEffectsNotRecorded':True,'realOldResponseFulfilledDuringNewPending':True,'localizedDeniedAndUnavailableActuallySpoken':True,'narrow':a['narrow']})
 else:
  pg=a['pagination'];assert all(json.dumps(e,sort_keys=True) in es for e in pg['automaticResultSpeech']);assert norm(pg['expectedResult']) in norm(' '.join(e['text'] for e in pg['automaticResultSpeech']));c=pg['retainedControl'];b=c['visibleRect'];v=c['viewport'];assert c['sameFocusedNode'] and c['focusVisible'] and c['withinViewport'] and b['y']+b['height']<=v['height'];assert c['ringClearance']['viewportBottom']>=7.5 and c['ringClearance']['mainBottom']>=8
  assert norm(ui['managerPresenceBoundary']) in norm(a['absentEmployeeSpeech']);row.update({'fractionalGeometry':c,'nativeZoom':a.get('nativeZoom')})
 runs.append(row)
 for file in ['at-receipt.json','source-manifest.json','orca-presentations.jsonl','orca-dispatch-completed.jsonl','executed-script-hashes-before.json','executed-script-hashes-after.json','cleanup.json','safe-error-categories.json','backend-check.json','supervisor-events.json','app-ready.json','executed-probe.mjs','executed-pagination-probe.mjs','executed-contrast-helper.mjs','atspi-tree.json']:
  f=p/file
  if f.exists():supported.append({'path':str(f),'bytes':f.stat().st_size,'sha256':h(f.read_bytes())})
negative=json.loads((R/'run-2zt_mlln/at-receipt.json').read_text());assert sum(x['pass'] for x in negative['assertions'])==8
original=negative['absentEmployeeSpeech'];assert 'work- time' in original;ui=json.loads((W/'messages/en.json').read_text())['workforcePage'];assert ui['managerPresenceBoundary'] not in re.sub(r'\s+',' ',original);assert norm(ui['managerPresenceBoundary']) in norm(original)
assert norm('work-\ntime')=='work-time' and norm('do NOT prove')!='do prove' and norm('time facts do prove presence')!='time facts do not prove presence'
out={'sourceManifestSha256':h((R/'source-manifest.json').read_bytes()),'sourceFiles':8833,'allSourceBytesModesMatchFrozenATRuntime':True,'runs':runs,'reviewedAllNineCompletedRuns':True,'originalHyphenNegativeStill8of9':True,'semanticNormalizerDoesNotDeleteWordsNegationOrChangeFocusChecks':True,'allowlistedExistingSupportBindings':supported}
p=D/'validation.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':h(p.read_bytes()),'runs':runs},ensure_ascii=False,indent=2))
