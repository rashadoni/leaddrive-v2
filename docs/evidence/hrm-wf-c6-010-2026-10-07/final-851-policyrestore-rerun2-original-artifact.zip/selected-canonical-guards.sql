BEGIN; SET LOCAL lock_timeout='3s'; SET LOCAL statement_timeout='60s';
CREATE OR REPLACE FUNCTION workforce_guard_published_definition_delete()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF OLD."status" <> 'DRAFT' THEN
    RAISE EXCEPTION '% published definition cannot be deleted; retire it instead', TG_TABLE_NAME
      USING ERRCODE = '55000';
  END IF;

  RETURN OLD;
END;
$$;
CREATE TRIGGER workforce_policies_published_definition_delete_guard
  BEFORE DELETE ON "workforce_policies"
  FOR EACH ROW EXECUTE FUNCTION workforce_guard_published_definition_delete();
CREATE OR REPLACE FUNCTION workforce_guard_published_policy_definition()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  old_status TEXT := OLD."status"::text;
  new_status TEXT := NEW."status"::text;
  allowed_keys TEXT[];
BEGIN
  allowed_keys := CASE old_status
    WHEN 'ACTIVE' THEN ARRAY['status', 'retiredAt', 'effectiveTo', 'updatedAt']
    WHEN 'RETIRED' THEN ARRAY['updatedAt']
    ELSE ARRAY[]::TEXT[]
  END;

  IF old_status <> 'DRAFT'
     AND (to_jsonb(NEW) - allowed_keys) IS DISTINCT FROM (to_jsonb(OLD) - allowed_keys) THEN
    RAISE EXCEPTION 'workforce_policies published definition content is immutable; create a new draft version'
      USING ERRCODE = '55000';
  END IF;

  IF old_status = 'ACTIVE' AND NEW."effectiveTo" IS DISTINCT FROM OLD."effectiveTo" THEN
    IF NEW."effectiveTo" IS NULL
       OR (OLD."effectiveTo" IS NOT NULL AND NEW."effectiveTo" > OLD."effectiveTo") THEN
      RAISE EXCEPTION 'An active Workforce policy effective window can only be narrowed' USING ERRCODE = '55000';
    END IF;
    IF EXISTS (
      SELECT 1
      FROM "workforce_policy_snapshots"
      WHERE "organizationId" = OLD."organizationId"
        AND "policyId" = OLD."id"
        AND "workDate" > NEW."effectiveTo"
    ) THEN
      RAISE EXCEPTION 'A Workforce policy effective window cannot exclude an existing snapshot' USING ERRCODE = '55000';
    END IF;
  END IF;

  IF old_status = 'DRAFT' AND new_status NOT IN ('DRAFT', 'ACTIVE') THEN
    RAISE EXCEPTION 'invalid Workforce policy transition % -> %', old_status, new_status USING ERRCODE = '23514';
  ELSIF old_status = 'ACTIVE' AND new_status NOT IN ('ACTIVE', 'RETIRED') THEN
    RAISE EXCEPTION 'invalid Workforce policy transition % -> %', old_status, new_status USING ERRCODE = '23514';
  ELSIF old_status = 'RETIRED' AND new_status <> 'RETIRED' THEN
    RAISE EXCEPTION 'retired Workforce policy cannot transition to %', new_status USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;
CREATE OR REPLACE TRIGGER workforce_policies_published_definition_guard
  BEFORE UPDATE ON "workforce_policies"
  FOR EACH ROW EXECUTE FUNCTION workforce_guard_published_policy_definition();
COMMIT;
