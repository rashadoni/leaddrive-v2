from pathlib import Path
import subprocess,json,gzip,time,datetime,sys
M,output=sys.argv[1:];p=Path(output);assert not p.exists();p.mkdir();rid=None;last=None;logs=set()
def api(path,name):
 a=subprocess.run(['gh','api','repos/rashadoni/leaddrive-v2/'+path],capture_output=True);(p/(name+'.json.gz')).write_bytes(gzip.compress(a.stdout,mtime=0));(p/(name+'-stderr-original.txt')).write_bytes(a.stderr);assert a.returncode==0;return json.loads(a.stdout)
for tick in range(100):
 if rid is None:
  runs=api('actions/runs?head_sha='+M+'&event=push&per_page=100',f'tick-{tick:02d}-main-runs')
  rows=[r for r in runs['workflow_runs']if r['path']=='.github/workflows/deploy.yml'and r['head_branch']=='main'and r['head_sha']==M and r['event']=='push'and r['run_attempt']==1]
  if rows:assert len(rows)==1;rid=rows[0]['id']
 if rid:
  r=api(f'actions/runs/{rid}',f'tick-{tick:02d}-normal-run');j=api(f'actions/runs/{rid}/jobs?per_page=100',f'tick-{tick:02d}-normal-jobs')
  assert r['head_sha']==M and r['head_branch']=='main'and r['path']=='.github/workflows/deploy.yml'and r['event']=='push'and r['run_attempt']==1
  assert len(j['jobs'])==j['total_count']
  state=tuple((x['id'],x['name'],x['status'],x['conclusion'],[s['name']for s in x['steps']if s['status']=='in_progress'])for x in j['jobs'])
  if state!=last:print(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'normalPublicationRun':rid,'main':M,'jobs':state}),flush=True);last=state
  for x in j['jobs']:
   if x['status']=='completed'and x['conclusion']!='skipped'and x['id']not in logs:
    a=subprocess.run(['gh','api',f"repos/rashadoni/leaddrive-v2/actions/jobs/{x['id']}/logs"],capture_output=True)
    if a.returncode:(p/f'tick-{tick:02d}-job-{x["id"]}-log-read-error-original.txt').write_bytes(a.stderr)
    else:(p/f'first-terminal-job-{x["id"]}-whole-original.txt.gz').write_bytes(gzip.compress(a.stdout,mtime=0));logs.add(x['id'])
  if r['status']=='completed':
   artifacts=api(f'actions/runs/{rid}/artifacts?per_page=100','terminal-artifact-metadata-original')
   (p/'actual-preview-publication-status.json').write_text(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main':M,'run':rid,'attempt':1,'normalConclusion':r['conclusion'],'jobs':state,'additionalModuleTests':'DEFERRED_BY_OWNER','optionalSourceCurrentRuntimeAcceptance':'NOT_COMPLETE','artifactMetadataOnly':True},indent=2))
   print(json.dumps({'ordinaryPublicationTerminal':r['conclusion'],'run':rid,'main':M,'additionalModuleTests':'DEFERRED_BY_OWNER'}),flush=True)
   if r['conclusion']!='success':raise RuntimeError('NORMAL_PUBLICATION_FAILED_NO_MANUAL_FALLBACK')
   break
 time.sleep(25)
else:raise RuntimeError('BOUNDED_NORMAL_PUBLICATION_WAIT_EXPIRED_NO_DEPLOY_SUCCESS_ASSUMED')
