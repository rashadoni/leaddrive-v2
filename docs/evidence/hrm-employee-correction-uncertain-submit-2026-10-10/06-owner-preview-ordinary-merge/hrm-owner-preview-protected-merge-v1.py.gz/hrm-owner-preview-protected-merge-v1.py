from pathlib import Path
import subprocess,json,gzip,time,datetime,sys
H,B,output=sys.argv[1:];p=Path(output);assert not p.exists();p.mkdir();last=None
expected=['pr-scope','static-checks','typecheck','runner-policy','scan']
def api(path,name):
 a=subprocess.run(['gh','api','repos/rashadoni/leaddrive-v2/'+path],capture_output=True)
 (p/(name+'-stderr-original.txt')).write_bytes(a.stderr)
 (p/(name+'.json.gz')).write_bytes(gzip.compress(a.stdout,mtime=0))
 assert a.returncode==0,(path,a.returncode)
 return json.loads(a.stdout)
for tick in range(84):
 r=api('pulls/686',f'tick-{tick:02d}-pr')
 assert r['head']['sha']==H and r['base']['sha']==B and r['state']=='open'and not r['draft']and not r['merged']
 checks=api('commits/'+H+'/check-runs?per_page=100',f'tick-{tick:02d}-checks')
 assert checks['total_count']==len(checks['check_runs'])
 selected={}
 for name in expected:
  rows=[x for x in checks['check_runs']if x['name']==name];assert rows
  x=max(rows,key=lambda x:x['id']);assert x['app']['id']==15368 and x['head_sha']==H
  selected[name]=x
 state=tuple((name,x['id'],x['status'],x['conclusion'])for name,x in selected.items())
 if state!=last:print(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'requiredPublicationContexts':state}),flush=True);last=state
 if any(x['status']=='completed'and x['conclusion']not in ['success','skipped']for x in selected.values()):raise RuntimeError('MANDATORY_GITHUB_PUBLICATION_CONTEXT_FAILED_NO_BYPASS')
 if all(x['status']=='completed'and x['conclusion']=='success'for x in selected.values()):
  main=api('git/ref/heads/main','immediate-main-before-merge');assert main['object']['sha']==B
  protection=api('branches/main/protection','immediate-protection-before-merge')
  assert sorted(protection['required_status_checks']['contexts'])==sorted(expected)and protection['enforce_admins']['enabled']and not protection['allow_force_pushes']['enabled']
  fresh=api('pulls/686','immediate-pr-before-merge');assert fresh['head']['sha']==H and fresh['base']['sha']==B and fresh['state']=='open'and not fresh['draft']
  body={'sha':H,'merge_method':'merge'};(p/'ordinary-exact-head-merge-input.json').write_text(json.dumps(body))
  a=subprocess.run(['gh','api','--method','PUT','repos/rashadoni/leaddrive-v2/pulls/686/merge','--input',str(p/'ordinary-exact-head-merge-input.json')],capture_output=True)
  (p/'ordinary-exact-head-merge-response-original.json').write_bytes(a.stdout);(p/'ordinary-exact-head-merge-stderr-original.txt').write_bytes(a.stderr);(p/'ordinary-exact-head-merge-exit-original.json').write_text(json.dumps({'exit':a.returncode,'time':datetime.datetime.now(datetime.timezone.utc).isoformat()}))
  assert a.returncode==0;d=json.loads(a.stdout);assert d['merged']is True
  commit=api('git/commits/'+d['sha'],'actual-ordinary-merge-commit-original');assert [x['sha']for x in commit['parents']]==[B,H]
  print(json.dumps({'ordinaryMergeCompleted':True,'mergeSha':d['sha'],'sourceHead':H,'parentMain':B,'optionalRuntimeAcceptance':'DEFERRED_BY_OWNER','normalDeploy':'AUTOMATIC_MAIN_PUSH'}),flush=True);break
 time.sleep(25)
else:raise RuntimeError('BOUNDED_REQUIRED_CONTEXT_WAIT_EXPIRED_NO_MERGE_OR_DEPLOY_ASSUMED')
