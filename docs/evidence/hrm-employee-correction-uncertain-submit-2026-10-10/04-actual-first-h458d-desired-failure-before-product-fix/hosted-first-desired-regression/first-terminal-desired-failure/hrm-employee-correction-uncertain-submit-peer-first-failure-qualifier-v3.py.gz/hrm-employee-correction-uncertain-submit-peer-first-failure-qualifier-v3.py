from pathlib import Path
import sys,json,subprocess,hashlib,re,datetime,gzip,zipfile
p=Path(sys.argv[1]);H=sys.argv[2];C=sys.argv[3]if len(sys.argv)>3 else H;B=sys.argv[4]if len(sys.argv)>4 else None
assert re.fullmatch('[a-f0-9]{40}',H)and re.fullmatch('[a-f0-9]{40}',C)
s=json.loads((p/'correction-uncertain-submit-terminal-job-root-summary.json').read_text());r=s['receipt']
assert s['headSha']==H and s['jobConclusion']=='failure' and r['sourceHead']==H and r['checkedMergeSha']==C
assert r['status']=='FAIL' and r['cleanup']=='PASS' and r['version']==1
assert r['failure']['stage']=='require-edit-boundary-after-unknown-commit' and r['failure']['class']=='AssertionError' and r['failure']['code']=='ERR_ASSERTION'
assert 1<=len(r['failure']['frames'])<=4 and any('workforce-employee-correction-uncertain-submit-browser-evidence.mjs:' in x for x in r['failure']['frames'])
assert subprocess.check_output(['git','rev-parse',H+'^{tree}'])==subprocess.check_output(['git','rev-parse',C+'^{tree}'])
if C != H:
 assert B and re.fullmatch('[a-f0-9]{40}',B)
 assert subprocess.check_output(['git','rev-list','--parents','-n','1',C],text=True).split()[1:]==[B,H]
log=gzip.decompress((p/'whole-correction-uncertain-submit-job-original.txt.gz').read_bytes()).decode();ls=log.splitlines();bind=[]
for i,l in enumerate(ls):
 if 'git log -1 --format=%H'in l:bind+=ls[i:i+2]
assert re.findall('[a-f0-9]{40}','\n'.join(bind))[-1]==C
job=json.loads(gzip.decompress((p/'job-api-original.json.gz').read_bytes()));run=json.loads(gzip.decompress((p/'run-api-original.json.gz').read_bytes()))
assert run['head_sha']==job['head_sha']==H and job['run_id']==s['runId'] and run['path']=='.github/workflows/workforce-correction-uncertain-submit-browser-evidence.yml'
assert job['name']=='Authenticated employee correction unknown-commit editing regression'
# Qualify only the actual resolved GitHub action cache post-step skipped on FAIL.
resolved=re.findall(r"Download action repository 'actions/setup-node@v6' \(SHA:([a-f0-9]{40})\)",log)
assert resolved==['249970729cb0ef3589644e2896645e5dc5ba9c38']
action=(p/'actual-resolved-setup-node-action-original.yml').read_bytes()
assert hashlib.sha256(action).hexdigest()=='ad45f1922115116fb4706651d0a9262332bc4e4f11eb2021e09789dd1af18085' and b'post-if: success()'in action
check_raw=subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/check-runs/'+str(s['jobId'])])
(p/'independent-first-failure-check-whole-original-api.json.gz').write_bytes(gzip.compress(check_raw,mtime=0));check=json.loads(check_raw)
assert check['id']==job['id']==s['jobId'] and check['name']==job['name'] and check['head_sha']==H and check['app']['id']==15368 and check['status']=='completed'and check['conclusion']=='failure'
artifact_api=json.loads(gzip.decompress((p/'artifacts-api-original.json.gz').read_bytes()));artifact=next(a for a in artifact_api['artifacts']if a['id']==s['artifact']['id'])
assert artifact['name']==f"workforce-employee-correction-uncertain-submit-browser-{C}-{s['runAttempt']}" and artifact['workflow_run']['id']==s['runId'] and artifact['workflow_run']['head_sha']==H and not artifact['expired']
original_zip=(p/f"artifact-{s['artifact']['id']}-original.zip").read_bytes()
assert len(original_zip)==artifact['size_in_bytes']==s['artifact']['bytes']and artifact['digest']=='sha256:'+hashlib.sha256(original_zip).hexdigest()and s['artifact']['sha256']==hashlib.sha256(original_zip).hexdigest()

assert run['id']==s['runId']==job['run_id'] and job['id']==s['jobId']
assert run['run_attempt']==s['runAttempt']==1
assert run['status']==job['status']=='completed' and run['conclusion']==job['conclusion']==s['jobConclusion']=='failure'
expected_skips=['Post Setup Node.js']
if C == H:
 assert run['event']=='workflow_dispatch'
else:
 assert run['event']=='pull_request'
 expected_skips.insert(0,'Verify exact authorized source dispatch')
assert [x['name']for x in job['steps']if x['conclusion']=='skipped']==expected_skips
assert [x['name']for x in job['steps']if x['conclusion']=='failure']==['Run actual committed reply-loss and UI recovery scenarios']
assert all(x['status']=='completed'and(x['conclusion']=='success'or(x['name']in expected_skips and x['conclusion']=='skipped')or(x['name']=='Run actual committed reply-loss and UI recovery scenarios'and x['conclusion']=='failure'))for x in job['steps'])
workflow=subprocess.check_output(['git','show',H+':.github/workflows/workforce-correction-uncertain-submit-browser-evidence.yml'],text=True).split('  employee-correction-uncertain-submit-browser:')[1]
assert '- name: Preserve non-secret workflow failure receipt\n        if: failure()'in workflow

assert sorted(s['artifact']['members'])==['employee-correction-uncertain-submit-receipt.json','workflow-context.json','workflow-failure.json']
with zipfile.ZipFile(p/f"artifact-{s['artifact']['id']}-original.zip")as z:
 assert z.testzip()is None and sorted(z.namelist())==sorted(s['artifact']['members'])
 assert json.loads(z.read('employee-correction-uncertain-submit-receipt.json'))==r
 context=json.loads(z.read('workflow-context.json'));failure=json.loads(z.read('workflow-failure.json'))
 assert context=={'stage':'workflow-preparing','headSha':H,'ciSha':C,'runId':str(s['runId']),'runAttempt':'1','runtime':'ephemeral-next-dev','productionMutation':False}
 assert failure=={'status':'FAILED','headSha':H,'ciSha':C,'runId':str(s['runId']),'runAttempt':'1','runtime':'ephemeral-next-dev'}
harness=subprocess.check_output(['git','show',H+':scripts/workforce-employee-correction-uncertain-submit-browser-evidence.mjs'],text=True)
expected_sources=json.loads(re.search(r'const sourcePaths = (\[[^\n]+\])',harness)[1])
assert sorted(expected_sources)==sorted(x['path']for x in r['sources'])and len(expected_sources)==37
sources=r['sources'];assert len(sources)==37 and len({x['path']for x in sources})==37
for x in sources:
 b=subprocess.check_output(['git','show',H+':'+x['path']]);assert x['bytes']==len(b)and x['sha256']==hashlib.sha256(b).hexdigest()
cells={(l,w)for l in['az','ru','en']for w in[320,768,1440]};cases=r['cases'];assert len(cases)==11
matrix=[x for x in cases if 'locale'in x];assert len(matrix)==9 and{(x['locale'],x['width'])for x in matrix}==cells
expected={'committedResponseDeliberatelyLost':True,'actualClientRequestFailed':True,'actualErrorToast':True,'draftPreserved':True,'actualUiRetryStatus':200,'sameUiPayloadAndClientKey':True,'sameUiRequestId':True,'committedRequestAndAuditUnchangedOnUiRetry':True,'actualPostStatus':201,'actualReplayStatus':200,'pending':True,'ownWorkday':True,'actualUiHistory':True,'duplicateRows':0}
for case in matrix:
 assert case['status']=='PASS'
 for name in['linked','unlinked']:
  a=case[name];assert all(a[k]==v for k,v in expected.items());assert a['sourceLinked']==(name=='linked');assert a['immutableRevision']==(0 if name=='linked'else None)
a=next(x for x in cases if x['name']=='second-populated-tenant');assert a['status']=='PASS'and all(a['linked'][k]==v for k,v in expected.items())and a['linked']['sourceLinked']is True and a['linked']['immutableRevision']==0
b=next(x for x in cases if x['name']=='foreign-missing-and-different-day-cases-indistinguishable');assert b['status']=='PASS'and b['actual409']==3 and b['requestsAndAuditUnchanged']is True
for i,a in enumerate(r['authenticationDiagnostics'],1):
 assert a['ordinal']==i and a['csrfStatus']==a['callbackStatus']==a['verificationStatus']==a['sessionUpdateStatus']==200 and a['verificationWarmupStatus']==405 and a['mandatoryTotp']is True and a['nonceConsumed']is True
 assert isinstance(a['pacingWaitMs'],int)and 0<=a['pacingWaitMs']<=600000
assert len(r['authenticationDiagnostics'])==10
states={'IMMUTABLE_CASE_LINK':'55000','IMMUTABLE_CASE_REVISION':'55000','EXACT_LINKED_WORKDAY':'23514','SYNTHETIC_AUDIT_IMMUTABLE':'55000','EXACT_CASE_IMMUTABLE':'55000'}
assert len(r['databaseDiagnostics'])==5 and{x['kind']for x in r['databaseDiagnostics']}==set(states)
for x in r['databaseDiagnostics']:assert x['expectedSqlState']==x['actualSqlState']==states[x['kind']]and x['rolledBack']is True and x['persistedRequestAndAuditFingerprintsUnchanged']is True
b=r['database'];assert b['actualRequests']==b['actualAudits']==19 and b['linkedRequests']==10 and b['unlinkedAfterTypeDayChange']==9
for k in['nonownerForcedRls','twoPopulatedTenants','unchanged']:assert b[k]is True
for k in['unscopedRows','foreignRows','automaticPersonnelDecisions','corrections','employeeResponses']:assert b[k]==0
assert b['defaultAclReviewed']is False and b['fullHistoricalReplay']is False
c=b['actualRoleCatalog'];assert c['forced']==5 and c['owned']==c['memberships']==0 and c['request_insert']is True and c['audit_insert']is True
for k in['request_mutation','audit_mutation','workday_write','decision_write','response_write','correction_write']:assert c[k]is False
facts=b['knownFactControls'];assert len(facts)==11 and len({x['table']for x in facts})==11
for x in facts:assert isinstance(x['rows'],int)and x['rows']>=0 and re.fullmatch('[a-f0-9]{64}',x['sha256'])
assert {x['table']:x['rows']for x in facts}=={'organizations':2,'mtm_agents':2,'mtm_agent_workdays':19,'workforce_exception_cases':19,'workforce_exception_decisions':0,'workforce_employee_team_memberships':0,'workforce_access_grants':0,'workforce_shift_templates':0,'workforce_shift_segments':0,'workforce_time_corrections':0,'workforce_exception_employee_responses':0}
phases=[]
for locale in ['az','ru','en']:
 for width in [320,768,1440]:
  phases += [(f'{locale}-{width}-actual-linked-request-reply-loss-and-ui-retry',True),(f'{locale}-{width}-actual-cleared-source-reply-loss-and-ui-retry',False)]
phases += [('second-positive-tenant',True)]
assert len(r['recoveryDiagnostics'])==19
assert sum(x['linked']is True for x in r['recoveryDiagnostics'])==10 and sum(x['linked']is False for x in r['recoveryDiagnostics'])==9
for i,(x,(phase,linked)) in enumerate(zip(r['recoveryDiagnostics'],phases),1):
 assert x['phase']==phase and x['linked']is linked
 assert x['ordinal']==i and x['requestsBefore']==x['auditsBefore']==i-1
 assert x['realServerStatus']==201 and x['actualUiRetryStatus']==200 and x['handlerFailureClass']is None and x['handlerFailureCode']is None
 assert isinstance(x['phase'],str)and len(x['phase'])<=100 and 'PRIVATE'not in x['phase']
 for field in ['routeAbortCompleted','browserRequestFailed','errorToastObserved','retainedDraftVerified','sameUiBodyAndClientKey','sameUiRequestId','committedRowsUnchanged']:assert x[field]is True
assert len(r['uncertainEditDiagnostics'])==19
for i,(x,(phase,linked)) in enumerate(zip(r['uncertainEditDiagnostics'],phases),1):
 assert x['ordinal']==i and x['phase']==phase and x['linked']is linked
 for k in ['allFieldsLockedAfterUnknownCommit','attemptedEditPrevented']:assert x[k]is False
 for k in ['originalInputPreserved','committedRequestAndAuditUnchangedAfterEditedAttempt','originalClientKeyPreservedOnEditedAttempt','onlyReasonChangedOnEditedAttempt']:assert x[k]is True
 assert x['actualEditedUiStatus']==409 and x['refusalCode']=='WORKFORCE_SELF_REQUEST_IDEMPOTENCY_MISMATCH'
assert len(r['productionRoutines'])==11
for x in r['productionRoutines']:
 text=subprocess.check_output(['git','show',H+':'+x['path']],text=True)
 if x['kind']=='EXACT_STATEMENT':
  matches=[]
  for i in range(len(text)):
   if text.startswith(('CREATE OR REPLACE FUNCTION','CREATE TRIGGER','ALTER TABLE'),i):
    if text.startswith('CREATE OR REPLACE FUNCTION',i):end=text.index('\n$$;',i)+4
    else:end=text.index(';',i)+1
    bb=text[i:end].encode()
    if len(bb)==x['bytes']and hashlib.sha256(bb).hexdigest()==x['sha256']:matches.append(i)
  assert len(matches)==1,(x['path'],x)
 else:
  assert x['kind']=='EXACT_CHECK_FRAGMENT_RECONSTRUCTED_ALTER';start=text.index('ADD CONSTRAINT "'+x['name']+'"');end=text.index(' NOT VALID',start)+len(' NOT VALID');fragment=text[start+4:end]
  assert hashlib.sha256(fragment.encode()).hexdigest()==x['fragmentSha256'];assert hashlib.sha256(('ALTER TABLE public."mtm_hrm_requests" ADD '+fragment+';').encode()).hexdigest()==x['executedSha256']
assert len(r['cleanupDiagnostics'])==13 and len({x['resource']for x in r['cleanupDiagnostics']})==13 and all(x['status']=='PASS'for x in r['cleanupDiagnostics'])
assert len(r['limitations'])==8 and not any(x.endswith('.png')for x in s['artifact']['members'])
assert all(x not in json.dumps(r)for x in['PRIVATE_CORRECTION_UNCERTAIN_SUBMIT_','Fixture!9a-','@example.test','Synthetic correction agent'])
# Keep every original receipt bound above, then independently require all exact
# identities and resources; duplicate valid routine rows cannot substitute.
assert {x['name'] for x in cases}=={f"{l}-{w}" for l,w in cells}|{'second-populated-tenant','foreign-missing-and-different-day-cases-indistinguishable'}
for x in matrix:assert x['name']==f"{x['locale']}-{x['width']}"
assert {x['resource'] for x in r['cleanupDiagnostics']}=={f'context-{i}' for i in range(1,11)}|{'browser','app-prisma','admin-prisma'}
assert all(a['pacingWaitMs']<=3*62000 for a in r['authenticationDiagnostics'])
L='prisma/migrations/20260830170000_workforce_exception_case_lifecycle/migration.sql'
R='prisma/migrations/20260927014000_workforce_exception_case_revisions/migration.sql'
K='prisma/migrations/20260831113000_workforce_exception_correction_request_link/migration.sql'
V='prisma/migrations/20260927014300_workforce_exception_case_revisions_contract/migration.sql'
texts={n:subprocess.check_output(['git','show',H+':'+n],text=True) for n in [L,R,K,V]}
def extract(text,start,end=';'):
 assert text.count(start)==1;from_=text.index(start);to=text.index(end,from_);return text[from_:to+len(end)]
expected_routines=[]
for path,start,end in [(L,'CREATE OR REPLACE FUNCTION workforce_reject_exception_case_mutation(','\n$$;'),(L,'CREATE OR REPLACE FUNCTION workforce_reject_exception_decision_mutation(','\n$$;'),(L,'CREATE TRIGGER workforce_exception_cases_append_only',';'),(L,'CREATE TRIGGER workforce_exception_decisions_append_only',';'),(R,'CREATE OR REPLACE FUNCTION workforce_next_exception_compatibility_timestamp(','\n$$;'),(R,'CREATE OR REPLACE FUNCTION workforce_validate_hrm_request_exception_link()','\n$$;'),(K,'CREATE TRIGGER workforce_hrm_requests_validate_exception_link',';')]:
 bb=extract(texts[path],start,end).encode();expected_routines.append({'path':path,'kind':'EXACT_STATEMENT','bytes':len(bb),'sha256':hashlib.sha256(bb).hexdigest()})
for name in ['mtm_hrm_requests_exception_case_revision_check','mtm_hrm_requests_exception_case_revision_shape_check']:
 text=texts[R];start=text.index('ADD CONSTRAINT "'+name+'"');end=text.index(' NOT VALID',start)+len(' NOT VALID');fragment=text[start+4:end];executed='ALTER TABLE public."mtm_hrm_requests" ADD '+fragment+';';expected_routines.append({'path':R,'name':name,'kind':'EXACT_CHECK_FRAGMENT_RECONSTRUCTED_ALTER','fragmentSha256':hashlib.sha256(fragment.encode()).hexdigest(),'executedSha256':hashlib.sha256(executed.encode()).hexdigest()});bb=extract(texts[V],'ALTER TABLE "mtm_hrm_requests"\n  VALIDATE CONSTRAINT "'+name+'"').encode();expected_routines.append({'path':V,'kind':'EXACT_STATEMENT','bytes':len(bb),'sha256':hashlib.sha256(bb).hexdigest()})
assert len(expected_routines)==11 and sorted(json.dumps(x,sort_keys=True) for x in r['productionRoutines'])==sorted(json.dumps(x,sort_keys=True) for x in expected_routines)

out={'status':'ACTUAL_FIRST_UNCHANGED_PRODUCT_UNKNOWN_COMMIT_EDIT_FAILURE_QUALIFIED_NOT_FIXED','sourceHead':H,'checkedCandidate':C,'base':B,'sourceDispatchVerificationSkippedOnPrReceivesNoCredit':C!=H,'actualFailureOnlyReceiptRan':True,'desiredEditBoundaryFailedAfterAll19Reproductions':True,'productFixAccepted':False,'predecessorRecoveryReaderFindingsRetained':True,'runId':s['runId'],'jobId':s['jobId'],'actualCases':11,'actualMfaContexts':10,'actualBindings':37,'actualViewports':9,'actualPendingRequestsAndAudits':19,'linked':10,'clearedSource':9,'controlledTransportRecoveryFlows':19,'firstReal201ThenAbortRequestfailedDraftUiRetry200':True,'recoveryDiagnostics':19,'sqlRollbackChecks':5,'forcedRlsTables':5,'factTablesUnchanged':11,'fullHistoricalReplay':False,'defaultAclReviewed':False,'production':False,'nativeFormDeviceHuman':False,'scope':'New independent disposable hosted runtime only; source bindings plus actual PASS assertions. Original eight gates, current-candidate/five and normal release remain separately required.','observedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
f=p/'peer-first-correction-uncertain-submit-failure-content-qualification-v3.json';assert not f.exists();f.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
