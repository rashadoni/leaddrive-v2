from pathlib import Path
import subprocess,json,sys,gzip,time,datetime,hashlib
R,H,output=sys.argv[1:];p=Path(output);assert not p.exists();p.mkdir();last=None
def api(path,name):
    b=subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/'+path]);(p/(name+'.json.gz')).write_bytes(gzip.compress(b,mtime=0));return json.loads(b)
for tick in range(84):
    r=api('actions/runs/'+R,f'tick-{tick:02d}-run');d=api('actions/runs/'+R+'/jobs?per_page=100',f'tick-{tick:02d}-jobs')
    assert r['head_sha']==H and r['run_attempt']==1 and r['event']=='workflow_dispatch' and r['path']=='.github/workflows/workforce-correction-uncertain-submit-browser-evidence.yml'
    assert len(d['jobs'])==d['total_count'] and d['total_count']<=1
    if d['jobs']:
        j=d['jobs'][0];assert j['name']=='Authenticated employee correction unknown-commit editing regression'
        stage=[s['name']for s in j['steps']if s['status']=='in_progress'];state=(r['status'],r['conclusion'],j['status'],j['conclusion'],stage)
        if state!=last:print(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run':int(R),'job':j['id'],'runStatus':r['status'],'runConclusion':r['conclusion'],'jobStatus':j['status'],'jobConclusion':j['conclusion'],'actualStage':stage}),flush=True);last=state
        if r['status']=='completed' and j['status']=='completed':
            a=subprocess.run(['gh','api',f"repos/rashadoni/leaddrive-v2/actions/jobs/{j['id']}/logs"],capture_output=True)
            if a.returncode:(p/f'tick-{tick:02d}-terminal-log-read-error-original.txt').write_bytes(a.stderr)
            else:
                (p/'first-terminal-whole-job-original.txt.gz').write_bytes(gzip.compress(a.stdout,mtime=0));(p/'first-terminal-job-id.json').write_text(json.dumps({'run':int(R),'job':j['id'],'head':H,'conclusion':j['conclusion'],'wholeBytes':len(a.stdout),'sha256':hashlib.sha256(a.stdout).hexdigest()})+'\n');print(json.dumps({'actualFirstTerminal':j['conclusion'],'job':j['id'],'bytes':len(a.stdout),'sha256':hashlib.sha256(a.stdout).hexdigest()}),flush=True);break
    time.sleep(25)
else:raise RuntimeError('BOUNDED_OBSERVER_EXPIRED_NO_DESIRED_FAILURE_ASSUMED')
