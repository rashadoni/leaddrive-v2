
// One task-scoped read-only observation using the already reviewed executor.
// C12_CATALOG_SQL, C12_CATALOG_BINDINGS and C12_CATALOG_FIELDS are fixed literals
// from exact reviewed main; no URL, identity or SQL override is accepted.
const c12CatalogReport = {
  version: 1, status: "ERROR", expectedMainSha: process.env.EXPECTED_MAIN_SHA,
  productionArtifactShaBefore: null, productionArtifactShaAfter: null,
  bindings: C12_CATALOG_BINDINGS, snapshot: null, code: "INSPECTION_FAILED", sqlState: null,
};
try {
  if (!SHA.test(c12CatalogReport.expectedMainSha) || process.getuid() !== 0) fail("INPUT_INVALID");
  const marker = "/opt/leaddrive-v2/.next/standalone/.deploy-sha";
  if (readRootFile(marker, 128).trim() !== c12CatalogReport.expectedMainSha) fail("ARTIFACT_MISMATCH");
  c12CatalogReport.productionArtifactShaBefore = c12CatalogReport.expectedMainSha;
  const connection = parseMigrationEnv(readRootFile("/etc/leaddrive/migration.env", 32_768, 0o600));
  const text = queryMetadata(connection, C12_CATALOG_SQL);
  if (typeof text !== "string" || Buffer.byteLength(text) > 4096) fail("OUTPUT_INVALID");
  const snapshot = JSON.parse(text);
  if (!snapshot || typeof snapshot !== "object" || Array.isArray(snapshot)
    || Object.keys(snapshot).sort().join(",") !== [...C12_CATALOG_FIELDS].sort().join(",")
    || C12_CATALOG_FIELDS.some(field => typeof snapshot[field] !== "boolean")) fail("OUTPUT_INVALID");
  if (readRootFile(marker, 128).trim() !== c12CatalogReport.expectedMainSha) fail("ARTIFACT_MISMATCH");
  c12CatalogReport.productionArtifactShaAfter = c12CatalogReport.expectedMainSha;
  Object.assign(c12CatalogReport, { status: "READ_COMPLETE", snapshot, code: null });
} catch (error) {
  c12CatalogReport.code = CODES.has(error?.message) ? error.message : "INSPECTION_FAILED";
  c12CatalogReport.sqlState = c12CatalogReport.code === "QUERY_FAILED" && SQL_STATES.has(error?.sqlState) ? error.sqlState : null;
}
console.log(JSON.stringify(c12CatalogReport));
if (c12CatalogReport.status !== "READ_COMPLETE") process.exitCode = 1;
