from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib,gzip,re,zipfile
out=Path('/tmp/hrm-c12-catalog-actual-production-peer-a1')
repo=Path('/mnt/HC_Volume_106454338/codex-alt-data/worktrees/leaddrive-hrm-c12-catalog-acceptance-20261010')
sha='a1b05f9991019e153ee371e99bb1d99f47f1547b';rid=38003016098
h=lambda d:hashlib.sha256(d).hexdigest()
def binding(d,p):return {'path':str(p),'bytes':len(d),'sha256':h(d)}
def source(p):return subprocess.check_output(['git','show',sha+':'+p],cwd=repo)
def fields_equal(actual,paths):
 want=[binding(source(p),p) for p in paths];assert actual==want;return want
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==sha
run=json.loads((out/'run-original-api.json').read_bytes());jobs=json.loads((out/'jobs-original-api.json').read_bytes())['jobs'];artifacts=json.loads((out/'artifacts-original-api.json').read_bytes())['artifacts']
assert run['head_sha']==sha and run['head_branch']=='main' and run['event']=='workflow_dispatch' and run['run_attempt']==1 and run['conclusion']=='success' and run['status']=='completed' and run['path']=='.github/workflows/hrm-c12-operational-schema-inspection.yml'
assert run['head_commit']['tree_id']==subprocess.check_output(['git','show','-s','--format=%T',sha],cwd=repo,text=True).strip()=='0f8bb2e01e05499bf4c557eae848a66c0f299354'
byname={j['name']:j for j in jobs};assert len(jobs)==2 and set(byname)=={'source-validation','production-catalog'}
assert byname['source-validation']['id']==114065330601 and byname['production-catalog']['id']==114065561875
assert len(byname['source-validation']['steps'])==15 and len(byname['production-catalog']['steps'])==14
for j in jobs:assert j['head_sha']==sha and j['conclusion']=='success' and all(s['conclusion']=='success' for s in j['steps'])
assert len(artifacts)==2
archives={};artifactproof=[]
expected={'source':(11649473675,18219,'9ea333b1ba0fed1682cd7ea8c22e211a924aa34ff71f7d619cf1ba065b589f21'),'production':(11649348881,3332,'f2be7d576c848194092787a406259274e7a0e8b5f5d18c284bdd1b4eb499eb09')}
for kind in ['source','production']:
 data=(out/(kind+'-original-artifact.zip')).read_bytes();a=next(a for a in artifacts if a['id']==expected[kind][0]);assert (a['id'],len(data),h(data))==expected[kind] and a['size_in_bytes']==len(data) and a['digest']=='sha256:'+h(data) and not a['expired'] and a['workflow_run']['head_sha']==sha
 want=f'hrm-c12-schema-source-{sha}-{rid}-1' if kind=='source' else f'hrm-c12-schema-production-{rid}-1';assert a['name']==want
 z=zipfile.ZipFile(out/(kind+'-original-artifact.zip'));assert z.testzip() is None;archives[kind]=z
 names=z.namelist();assert len(names)==len(set(names))
 artifactproof.append({'kind':kind,'id':a['id'],'name':a['name'],'bytes':len(data),'sha256':h(data),'apiDigestMatched':True,'allCrcPassed':True,'members':[binding(z.read(i),i.filename)|{'crc32':f'{i.CRC:08x}'} for i in z.infolist()]})
sz=archives['source'];pz=archives['production']
assert set(sz.namelist())=={'c12-schema-contract.json','emitted-remote.mjs','initdb.log','initial-source.json','postgres-version.txt','postgres.log','schema-tests.tap','source-result.json','source-tests.tap'}
assert set(pz.namelist())=={'initial-production.json','sanitized-remote-result.json','result.json','transport-result.json'}
src=json.loads(sz.read('source-result.json'));schema=json.loads(sz.read('c12-schema-contract.json'));initialsrc=json.loads(sz.read('initial-source.json'));initialprod=json.loads(pz.read('initial-production.json'))
assert src['status']=='PASS_SOURCE_AND_ISOLATED_SCHEMA_ONLY' and schema['status']=='PASS_ISOLATED_SCHEMA_CONTRACT_ONLY'
for r in [src,schema,initialsrc]:assert r['sourceSha']==sha and r['productionObserved'] is False and r['historicalReplay'] is False
assert initialsrc['status']=='ERROR' and initialsrc['code']=='SOURCE_CHECKS_NOT_COMPLETED'
assert initialprod=={'version':1,'status':'ERROR','expectedArtifactSha':sha,'code':'EARLY_INSPECTION_NOT_COMPLETED','productionObserved':False,'historicalReplay':False}
sourcepaths=['scripts/hrm-migration-metadata-preflight.mjs','scripts/workforce-reconciliation-schema-contract.sql','scripts/workforce-reconciliation-schema-contract.mjs','scripts/hrm-c12-operational-schema-inspection.mjs','scripts/hrm-c12-operational-schema-inspection.test.mjs','.github/workflows/hrm-c12-operational-schema-inspection.yml']
schemapaths=['prisma/migrations/20261005193000_workforce_reconciliation_operations/migration.sql','scripts/workforce-reconciliation-schema-contract.sql','scripts/workforce-reconciliation-schema-contract.mjs','scripts/workforce-reconciliation-schema-contract.test.mjs','.github/workflows/workforce-reconciliation-schema-contract.yml']
bindings=fields_equal(src['sourceBindings'],sourcepaths);schemabindings=fields_equal(schema['sourceBindings'],schemapaths)
assert schema['failure'] is None and schema['factFingerprintsBefore']==schema['factFingerprintsAfter'] and len(schema['cases'])==37 and len({c['name'] for c in schema['cases']})==37
assert all(c['status']=='PASS' and c['businessFactsUnchanged'] is True for c in schema['cases'])
taps={};unique=[]
for name,total,key in [('source-tests.tap',14,'unitCounts'),('schema-tests.tap',42,'schemaCounts')]:
 text=sz.read(name).decode();counts={k:int(re.findall(r'^# '+k+r' (\d+)$',text,re.M)[0]) for k in ['tests','pass','fail','cancelled','skipped']}
 assert all(len(re.findall(r'^# '+k+r' (\d+)$',text,re.M))==1 for k in counts)
 assert counts=={'tests':total,'pass':total,'fail':0,'cancelled':0,'skipped':0} and {k:v for k,v in counts.items() if k!='cancelled'}==src[key]
 assert not re.search(r'^\s*not ok|^\s*(?:not )?ok[^\n]*#\s*(?:SKIP|TODO)',text,re.M|re.I)
 passed=re.findall(r'^\s*ok \d+ - (.+)$',text,re.M);assert len(passed)==len(set(passed))==total
 unique.extend(name+':'+n for n in passed);taps[name]={'counts':counts,'names':passed,'binding':binding(sz.read(name),name)}
assert len(unique)==len(set(unique))==56
pgversion=sz.read('postgres-version.txt').decode();assert pgversion=='postgres (PostgreSQL) 16.15 (Ubuntu 16.15-1.pgdg24.04+2)\n'
assert 'Success. You can now start the database server' in sz.read('initdb.log').decode()
assert 'ready to accept connections' in sz.read('postgres.log').decode() and 'listening on IPv4 address "127.0.0.1"' in sz.read('postgres.log').decode()
fields=['readOnly','repeatableRead','postgres16','ordinaryTable','columnShape','defaults','primaryKey','foreignKey','checks','rls','policy','indexes','noUserTriggers']
module=source(sourcepaths[3]).decode();footer=module.split('+ String.raw`',1)[1].split('`\n}',1)[0];assert '${' not in footer
compact=lambda v:json.dumps(v,separators=(',',':'),ensure_ascii=False)
program=source(sourcepaths[0]).decode()+'\nconst C12_INSPECTION_SQL='+compact(source(sourcepaths[1]).decode())+';\nconst C12_INSPECTION_SOURCE='+compact({'sourceSha':sha,'bindings':bindings})+';\nconst C12_INSPECTION_FIELDS='+compact(fields)+';\n'+footer
assert program.encode()==sz.read('emitted-remote.mjs')
assert source(sourcepaths[0]).__len__()==24904 and h(source(sourcepaths[0]))=='46b417da7bbe763960b8ede8fa0e9dbd98543d090d54f73979289504bfe35771'
assert h(source(sourcepaths[1]))=='9bb45ba8cc38afdba046e3bd761875c043731203de8dab18bfdce420c8aab49f'
assert h(source(sourcepaths[2]))=='8ffa59f87d927a8afc463988ba30ab6a9ec3f1a3ca253b5f9841fefddc1b0279'
sql=source(sourcepaths[1]).decode();assert sql.startswith('--') and "BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;" in sql and "SET LOCAL lock_timeout = '2s';" in sql and "SET LOCAL statement_timeout = '10s';" in sql and sql.rstrip().endswith('ROLLBACK;')
result=json.loads(pz.read('result.json'));sanitized=json.loads(pz.read('sanitized-remote-result.json'));transport=json.loads(pz.read('transport-result.json'))
assert pz.read('result.json')==pz.read('sanitized-remote-result.json') and transport=={'transportExit':0,'validationExit':0}
assert result['status']=='MATCHED_CATALOG_CONTRACT_ONLY' and result['version']==1 and result['failed']==[] and result['bindings']==bindings and result['productionObserved'] is True and result['historicalReplay'] is False
assert result['snapshot']==dict.fromkeys(fields,True) and all(type(v) is bool for v in result['snapshot'].values())
assert result['expectedArtifactSha']==result['productionArtifactShaBefore']==result['productionArtifactShaAfter']==sha
assert result['code'] is None and result['sqlState'] is None and result['envDetail'] is None
wiretext=result['originalRemoteWire'];wire=json.loads(wiretext)
assert len(wiretext.encode())<=8192 and compact(wire)==wiretext and list(wire)==['version','status','expectedArtifactSha','productionArtifactShaBefore','productionArtifactShaAfter','bindings','snapshot','code','sqlState','envDetail']
assert wire['status']=='READ_COMPLETE' and wire['version']==1 and wire['bindings']==bindings and wire['snapshot']==result['snapshot'] and wire['code'] is None and wire['sqlState'] is None and wire['envDetail'] is None
assert wire['expectedArtifactSha']==wire['productionArtifactShaBefore']==wire['productionArtifactShaAfter']==sha
# One bounded read-only validation of observed canonical wire using actual clean A1 committed CLI; no SQL or tests.
cmd=['/home/codex-alt/.local/bin/node','scripts/hrm-c12-operational-schema-inspection.mjs','--validate-output',sha,'0']
v=subprocess.run(cmd,input=wiretext.encode(),capture_output=True,timeout=15,cwd=repo)
(out/'peer-cli-revalidated-original-stdout.json').write_bytes(v.stdout);(out/'peer-cli-revalidated-original-stderr.txt').write_bytes(v.stderr)
assert v.returncode==0 and not v.stderr and json.loads(v.stdout)==result
with zipfile.ZipFile(out/'whole-run-original-logs.zip') as z:
 assert z.testzip() is None
 originalLogProof=[]
 for label in ['source-validation','production-catalog']:
  data=gzip.decompress((out/(label+'-whole-original.log.gz')).read_bytes());assert z.read(('1_' if label=='source-validation' else '2_')+label+'.txt')==data
  text=data.decode();actual=re.findall(r'git log -1 --format=%H\n[^\n]*Z ([0-9a-f]{40})\n',text);assert actual==[sha]
  originalLogProof.append(binding(data,label+'-whole-original.log')|{'standaloneCheckoutSha':actual[0]})
  if label=='source-validation':assert 'server started' in text and 'server stopped' in text and 'postgres (PostgreSQL) 16.15' in text
  else:
   assert 'GitHub production environment allows exactly the main branch' in text
   assert '-o StrictHostKeyChecking=yes' in text and 'timeout 70s ssh -T' in text and 'node --input-type=module -' in text
   assert 'git fetch --no-tags --depth=1 origin refs/heads/main' in text
   assert 'rm -f ~/.ssh/deploy_key ~/.ssh/known_hosts ~/.ssh/config' in text
fresh=subprocess.check_output(['gh','api','repos/rashadoni/leaddrive-v2/git/ref/heads/main']);(out/'main-after-inspection-original-api.json').write_bytes(fresh)
assert json.loads(fresh)['object']['sha']==json.loads((out/'main-before-inspection-original-api.json').read_bytes())['object']['sha']==sha
for p in sourcepaths:
 assert source(p)==subprocess.check_output(['git','show','c69500fcdee81dd62e818984f59e5902a790b3f7:'+p],cwd=repo)
report={'version':1,'status':'PASS_ACTUAL_PROTECTED_READONLY_CATALOG_OBSERVATION_ONLY','reviewer':'inspect_c12_metadata: source author independently reviewed hosted original API/artifact/whole logs; root independently reviewed source and actual CLI too','observedAtUtc':datetime.now(timezone.utc).isoformat(),'sourceMain':sha,'sourceTree':run['head_commit']['tree_id'],'runId':rid,'runAttempt':1,'event':'workflow_dispatch','url':run['html_url'],'runConclusion':'success','freshMainBeforeAndAfter':sha,'jobs':[{'id':j['id'],'name':j['name'],'url':j['html_url'],'conclusion':j['conclusion'],'steps':{s['name']:s['conclusion'] for s in j['steps']}} for j in jobs],'sourceTap':taps,'distinctTapPassedTotal':56,'sourceBindings':bindings,'schemaBindings':schemabindings,'nativePrivatePg':{'version':pgversion.strip(),'startupObserved':True,'readyObserved':True,'ownedClusterShutdownObserved':True},'schemaCaseCount':37,'businessFactFingerprintsUnchangedSyntheticOnly':True,'artifacts':artifactproof,'originalWholeLogs':originalLogProof,'emittedProgram':binding(sz.read('emitted-remote.mjs'),'emitted-remote.mjs')|{'completeExactCommittedSourceReconstructionMatched':True,'unchangedHelperAndSql':True},'actualCatalogResult':result,'originalValidatedRemoteWire':binding(wiretext.encode(),'originalRemoteWire'),'transport':transport,'peerActualCommittedCliRevalidation':{'command':cmd,'cwd':str(repo),'exit':v.returncode,'stderrBytes':len(v.stderr),'semanticExactMatchSanitizedOriginal':True,'heavyTestsOrQueryByPeer':False},'earlyFiniteReceiptsRetained':{'source':initialsrc,'production':initialprod,'classification':'initial not-completed receipts, not hidden prior failures'},'readOnlyMechanism':{'unchangedPsqlExecutor':'fixed args -X -qAt --no-password ON_ERROR_STOP and environment-only connection; no raw stderr','transaction':'REPEATABLE READ READ ONLY; lock_timeout2s statement_timeout10s; ROLLBACK','emission':'trusted committed exact SHA six bindings and fixed literal SQL, stdin in memory, strict SSH known hosts','credentials':'existing root-owned mode0600 migration.env; no credential values retained','deployedMarkerBeforeAndAfter':sha,'output':'exact13boolean snapshot, canonical10key original wire, no business rows/identifiers'},'findingsP0P1P2':[],'originalFiles':[binding(p.read_bytes(),p) for p in sorted(out.iterdir()) if p.is_file()],'productionObserved':True,'historicalReplay':False,'c12Accepted':False,'personnelDecisionsOrActivation':False,'repositoryOrProductionMutationByPeer':False,'limitations':['Only thirteen catalog prerequisites observed on exact deployed A1; source fixture is synthetic and not full restored historical replay.','Read-only productionObserved applies to catalog metadata only; no authenticated HR/UI, real cases, collector/device/load/pilot or historical business observations.','No migration, role, grant, access, secret, activation, business-row or Support changes.','Existing stricter migration metadata gate is unchanged and assessed separately; this result neither substitutes nor reclassifies its outcomes.','C12 remains PARTIAL:85/161 done,76 open,weighted61%; no criterion closed by this catalog receipt alone.','Source author performed this hosted receipt audit; root provided independent source review, avoiding a claim of separate authorship.']}
p=Path('/tmp/hrm-c12-catalog-actual-production-a1-peer-review.json');p.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'report':str(p),'bytes':p.stat().st_size,'sha256':h(p.read_bytes()),'source':sha,'actualCatalogStatus':result['status'],'flags':result['snapshot'],'TAP':56,'markersBeforeAfterMatch':True,'findings':[]}))
